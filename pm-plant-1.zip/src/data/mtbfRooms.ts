import { RoomConfig } from '../types/mtbf';

/**
 * โครงสร้างห้องและพื้นที่การผลิตใหม่ สอดคล้องกับทะเบียน 21 เครื่องจักรของโรงงาน
 * และประวัติเบรกดาวน์ล่าสุด (แทนที่ห้องเดิม 8 ห้องที่ถูกลบออก)
 */
export const OFFICIAL_MTBF_ROOMS: RoomConfig[] = [
  {
    id: 'room-1',
    name: 'ห้องเตรียมวัตถุดิบและผสมแป้ง',
    machines: [
      { id: 'FM1501A', name: 'เครื่องร่อนแป้ง', ranking: 'A', altIds: ['FM1501', 'SIFTER'] },
      { id: 'UK2601F', name: 'เครื่องแบ่งแป้ง', ranking: 'B', altIds: ['UK2601', 'DIVIDER'] },
      { id: 'SP1503D', name: 'เครื่องผสม Spiral 120 ลิตร', ranking: 'B', altIds: ['SP1503', 'SPIRAL'] },
      { id: 'SP1709D', name: 'เครื่อง SPIRAL 160 ลิตร', ranking: 'B', altIds: ['SP1709', 'SPIRAL-160'] },
      { id: 'MB1502O', name: 'เครื่องผสม Bear 60 ลิตร', ranking: 'B', altIds: ['MB1502', 'BEAR'] },
      { id: 'CO2103C', name: 'เครื่องหั่นหอม', ranking: 'C', altIds: ['CO2103', 'CUTTER'] },
      { id: 'TW1502H', name: 'เครื่องล้างถาดขนมปัง', ranking: 'B', altIds: ['TW1502', 'TRAY-WASHER'] }
    ]
  },
  {
    id: 'room-2',
    name: 'ห้องขึ้นรูปแป้งและเบเกอรี่',
    machines: [
      { id: 'FR1202P', name: 'โถฟีดโรล', ranking: 'B', altIds: ['FR1202', 'FEEDROLL'] },
      { id: 'RH1501F', name: 'เครื่องขึ้นรูป Rheon (เครื่อง 1)', ranking: 'A', altIds: ['RH1501', 'RH1501F-1', 'RHEON-1'] },
      { id: 'RH1501F-2', name: 'เครื่องขึ้นรูป Rheon (เครื่อง 2)', ranking: 'A', altIds: ['RH1502', 'RH1501-2', 'RHEON-2'] },
      { id: 'YJ1502F', name: 'YJL1500 ชุดก่อน Shutter', ranking: 'A', altIds: ['YJ1502', 'YJL1500', 'SHUTTER'] },
      { id: 'CS1501E', name: 'เครื่องขึ้นรูปครัวซอง Rondo', ranking: 'A', altIds: ['CS1501', 'RONDO'] },
      { id: 'CS2202E', name: 'ชุดม้วนครัวซอง', ranking: 'B', altIds: ['CS2202', 'CROISSANT-ROLL'] },
      { id: 'DS1504E', name: 'เครื่องรีดพาย', ranking: 'B', altIds: ['DS1504', 'SHEETER'] },
      { id: 'PD1501E', name: 'เครื่อง Press Dought', ranking: 'B', altIds: ['PD1501', 'PRESS-DOUGH'] },
      { id: 'ST1501F', name: 'เครื่อง Star line', ranking: 'A', altIds: ['ST1501', 'STARLINE'] }
    ]
  },
  {
    id: 'room-3',
    name: 'ห้องแต่งหน้าและจัดถาดอบ (Panning)',
    machines: [
      { id: 'PN1601F', name: 'เครื่อง Panning', ranking: 'A', altIds: ['PN1601', 'PANNING'] },
      { id: 'SE1501F', name: 'เครื่องพ่นไข่', ranking: 'B', altIds: ['SE1501', 'EGG-SPRAY'] },
      { id: 'CC1502P', name: 'เครื่องสไลด์โรล(มีดเดี่ยว)', ranking: 'A', altIds: ['CC1502', 'ROLL-SLICER'] }
    ]
  },
  {
    id: 'room-4',
    name: 'ห้องบรรจุภัณฑ์และหีบห่อ',
    machines: [
      { id: 'PK1502J', name: 'เครื่อง Pack Kawashima (เครื่อง 1)', ranking: 'A', altIds: ['PK1502', 'PK1502J-1', 'KAWASHIMA-1'] },
      { id: 'PK1502J-2', name: 'เครื่อง Pack Kawashima (เครื่อง 2)', ranking: 'A', altIds: ['PK1503', 'PK1502-2', 'KAWASHIMA-2'] },
      { id: 'PK1505J', name: 'เครื่อง Pack Kawashima (เครื่อง 5)', ranking: 'A', altIds: ['PK1505', 'KAWASHIMA-5'] },
      { id: 'PK1507P', name: 'เครื่อง Pack Kawashima (เครื่อง 7)', ranking: 'A', altIds: ['PK1507', 'KAWASHIMA-7'] },
      { id: 'PS1901J', name: 'เครื่อง Pack แซนวิช (เครื่อง 1)', ranking: 'A', altIds: ['PS1901', 'PS1901J-1', 'SANDWICH-1'] },
      { id: 'PS2302J', name: 'เครื่อง Pack แซนวิช (เครื่อง 2)', ranking: 'A', altIds: ['PS2302', 'PS2302J-2', 'SANDWICH-2'] },
      { id: 'RF1902F', name: 'เครื่องรัดฟิล์ม', ranking: 'B', altIds: ['RF1902', 'FILM-WRAP'] }
    ]
  },
  {
    id: 'room-5',
    name: 'ห้องทำความเย็นและแช่แข็ง Blast Chill',
    machines: [
      { id: 'BC2104C', name: 'Blast Chill (เครื่อง 1)', ranking: 'B', altIds: ['BC2104', 'BC2104C-1', 'BLAST-CHILL-1'] },
      { id: 'BC2104C-2', name: 'Blast Chill (เครื่อง 2)', ranking: 'B', altIds: ['BC2105', 'BC2104-2', 'BLAST-CHILL-2'] }
    ]
  }
];

// ค่าเริ่มต้น Production Time (ชั่วโมง) รายเดือน (เดือน 1-12) ประจำปี 2026 ตามสูตรเอกสาร Excel จริง
// คำนวณจาก: วันในเดือน x 18 ชม./วัน (ม.ค. 31 วัน x 18 = 558 ชม., ก.พ. 28 วัน x 18 = 504 ชม., เม.ย. 30 วัน x 18 = 540 ชม. รวมทั้งปี 6,570 ชม.)
export const DEFAULT_PRODUCTION_TIME_MONTHLY_2026 = [
  558, 504, 558, 540, 558, 540, 558, 558, 540, 558, 540, 558
];

// Baseline Data ย้อนหลังปี 2023 - 2025 สำหรับ 5 ห้องผลิตใหม่
export const DEFAULT_BASELINE_HISTORY = {
  2023: {
    breakdownMin: [210, 480, 85, 590, 220],
    count: [2, 4, 1, 5, 2],
    mtbf: [3285, 1642.5, 6570, 1314, 3285],
    mttr: [105, 120, 85, 118, 110]
  },
  2024: {
    breakdownMin: [160, 390, 60, 440, 150],
    count: [2, 3, 1, 4, 1],
    mtbf: [3285, 2190, 6570, 1642.5, 6570],
    mttr: [80, 130, 60, 110, 150]
  },
  2025: {
    breakdownMin: [90, 280, 45, 310, 95],
    count: [1, 2, 1, 3, 1],
    mtbf: [6570, 3285, 6570, 2190, 6570],
    mttr: [90, 140, 45, 103.3, 95]
  }
};

export const MONTH_NAMES_THAI = [
  'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
  'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'
];

export const MONTH_NAMES_ENG = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];
