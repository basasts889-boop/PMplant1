import React, { useState, useMemo } from 'react';
import { Trash2, AlertTriangle, X, Search, CheckSquare, Square, MinusSquare, Calendar, Filter, Clock } from 'lucide-react';
import { ScheduleItem, Machine, PMPlan, PMScheduleItem, OperationScheduleItem } from '../../types';

interface BulkDeleteScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  schedules: ScheduleItem[];
  onDeleteSchedules: (ids: string[]) => void;
  machines: Machine[];
  pmPlans: PMPlan[];
}

export const BulkDeleteScheduleModal: React.FC<BulkDeleteScheduleModalProps> = ({
  isOpen,
  onClose,
  schedules,
  onDeleteSchedules,
  machines,
  pmPlans,
}) => {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'PM' | 'Operation'>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'รอดำเนินการ' | 'กำลังทำ' | 'เสร็จสิ้น'>('ALL');
  const [monthFilter, setMonthFilter] = useState<string>('ALL');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Machine lookup map
  const machineMap = useMemo(() => {
    const map = new Map<string, Machine>();
    machines.forEach(m => map.set(m.id, m));
    return map;
  }, [machines]);

  // PM plan map
  const planMap = useMemo(() => {
    const map = new Map<string, PMPlan>();
    pmPlans.forEach(p => map.set(p.id, p));
    return map;
  }, [pmPlans]);

  // Distinct months in schedules
  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    schedules.forEach(s => {
      if (s.date && s.date.length >= 7) {
        set.add(s.date.substring(0, 7));
      }
    });
    return Array.from(set).sort().reverse();
  }, [schedules]);

  // Filtered schedules
  const filteredSchedules = useMemo(() => {
    return schedules.filter(s => {
      if (typeFilter !== 'ALL' && s.type !== typeFilter) return false;
      if (statusFilter !== 'ALL' && (s as PMScheduleItem).status !== statusFilter) return false;
      if (monthFilter !== 'ALL' && !s.date.startsWith(monthFilter)) return false;

      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const mach = (s as PMScheduleItem).machineId || '';
        const machName = machineMap.get(mach)?.name || '';
        const tech = s.technician || (s.technicians ? s.technicians.join(' ') : '');
        const plan = (s as PMScheduleItem).pmPlanId ? planMap.get((s as PMScheduleItem).pmPlanId)?.title || '' : '';
        const title = (s as PMScheduleItem).title || (s as OperationScheduleItem).line || '';

        const match = mach.toLowerCase().includes(q) ||
                      machName.toLowerCase().includes(q) ||
                      tech.toLowerCase().includes(q) ||
                      plan.toLowerCase().includes(q) ||
                      title.toLowerCase().includes(q) ||
                      s.date.includes(q);
        if (!match) return false;
      }

      return true;
    }).sort((a, b) => b.date.localeCompare(a.date));
  }, [schedules, typeFilter, statusFilter, monthFilter, searchTerm, machineMap, planMap]);

  const isAllFilteredSelected = useMemo(() => {
    if (filteredSchedules.length === 0) return false;
    return filteredSchedules.every(s => selectedIds.has(s.id));
  }, [filteredSchedules, selectedIds]);

  const isSomeFilteredSelected = useMemo(() => {
    if (filteredSchedules.length === 0) return false;
    return filteredSchedules.some(s => selectedIds.has(s.id)) && !isAllFilteredSelected;
  }, [filteredSchedules, selectedIds, isAllFilteredSelected]);

  const handleToggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSelectAllFiltered = () => {
    if (isAllFilteredSelected) {
      setSelectedIds(prev => {
        const next = new Set(prev);
        filteredSchedules.forEach(s => next.delete(s.id));
        return next;
      });
    } else {
      setSelectedIds(prev => {
        const next = new Set(prev);
        filteredSchedules.forEach(s => next.add(s.id));
        return next;
      });
    }
  };

  const handleSelectAllInSystem = () => {
    const all = schedules.map(s => s.id);
    setSelectedIds(new Set(all));
  };

  const handleClearSelection = () => {
    setSelectedIds(new Set());
  };

  const handleConfirmDelete = () => {
    if (selectedIds.size === 0) return;
    setIsSubmitting(true);
    try {
      onDeleteSchedules(Array.from(selectedIds));
      setSelectedIds(new Set());
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-6 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white flex items-center gap-2">
                <span>จัดการและลบงานในตารางแบบเลือกทั้งหมด</span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-500 text-slate-950">
                  {schedules.length} งานในระบบ
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                เลือกงาน PM หรืองานคุมกะในตารางเพื่อลบออกพร้อมกันอย่างปลอดภัย
              </p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Controls Bar */}
        <div className="p-4 bg-slate-950/60 border-b border-slate-800 space-y-3 shrink-0 text-xs">
          <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="ค้นหาตามรหัสเครื่อง, ช่าง, ชื่องาน, วันที่..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
              />
              {searchTerm && (
                <button onClick={() => setSearchTerm('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">✕</button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={monthFilter}
                onChange={(e) => setMonthFilter(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-300 text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">ทุกเดือน</option>
                {availableMonths.map(m => (
                  <option key={m} value={m}>เดือน {m}</option>
                ))}
              </select>

              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value as any)}
                className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-300 text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">ทุกประเภทงาน</option>
                <option value="PM">งาน PM</option>
                <option value="Operation">งานคุมไลน์</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-300 text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">ทุกสถานะ</option>
                <option value="รอดำเนินการ">รอดำเนินการ</option>
                <option value="กำลังทำ">กำลังทำ</option>
                <option value="เสร็จสิ้น">เสร็จสิ้น</option>
              </select>
            </div>
          </div>

          {/* Quick Selection Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-850">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleSelectAllFiltered}
                className={`px-3 py-1 text-xs font-semibold rounded-lg border flex items-center gap-1.5 transition cursor-pointer select-none ${
                  isAllFilteredSelected
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                {isAllFilteredSelected ? <CheckSquare size={13} /> : isSomeFilteredSelected ? <MinusSquare size={13} className="text-cyan-400" /> : <Square size={13} />}
                <span>{isAllFilteredSelected ? `ยกเลิกเลือกที่แสดง (${filteredSchedules.length})` : `เลือกที่แสดงทั้งหมด (${filteredSchedules.length})`}</span>
              </button>

              {schedules.length > filteredSchedules.length && (
                <button
                  type="button"
                  onClick={handleSelectAllInSystem}
                  className="px-2.5 py-1 text-xs font-semibold bg-indigo-900/40 hover:bg-indigo-800 text-indigo-200 border border-indigo-700/50 rounded-lg transition cursor-pointer"
                >
                  ☑️ เลือกทั้งหมดในระบบ ({schedules.length})
                </button>
              )}

              {selectedIds.size > 0 && (
                <button
                  type="button"
                  onClick={handleClearSelection}
                  className="px-2 py-1 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
                >
                  ล้างการเลือก
                </button>
              )}
            </div>

            <div className="text-[11px] text-slate-400">
              เลือกอยู่ <strong className="text-amber-300 font-mono">{selectedIds.size}</strong> จาก {filteredSchedules.length} งานที่แสดง
            </div>
          </div>
        </div>

        {/* Schedule Items Table / List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 text-xs divide-y divide-slate-800/80">
          {filteredSchedules.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Clock className="w-10 h-10 mx-auto text-slate-600" />
              <p className="font-semibold text-slate-400">ไม่พบงานในตารางที่ตรงกับตัวกรอง</p>
              <p className="text-[11px]">ลองเปลี่ยนคำค้นหา หรือเลือกตัวกรองเดือน/ประเภทงานใหม่</p>
            </div>
          ) : (
            filteredSchedules.map((s) => {
              const isSelected = selectedIds.has(s.id);
              const isPM = s.type === 'PM';
              const pm = isPM ? (s as PMScheduleItem) : null;
              const op = !isPM ? (s as OperationScheduleItem) : null;
              const mach = pm?.machineId ? machineMap.get(pm.machineId) : null;
              const plan = pm?.pmPlanId ? planMap.get(pm.pmPlanId) : null;
              const title = pm ? (plan?.title || pm.title || 'บำรุงรักษาเชิงป้องกัน') : `คุมไลน์ผลิต ${op?.line}`;

              return (
                <div
                  key={s.id}
                  onClick={() => handleToggleSelect(s.id)}
                  className={`pt-2 pb-2 px-3 rounded-xl transition cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-rose-950/30 border border-rose-500/40 text-white'
                      : 'hover:bg-slate-800/50 text-slate-300 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleSelect(s.id);
                      }}
                      className="text-slate-400 hover:text-white shrink-0"
                    >
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 text-rose-400 fill-rose-400/20" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-600" />
                      )}
                    </button>

                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[9.5px] font-bold px-1.5 py-0.2 rounded border ${
                          isPM ? 'bg-indigo-500/15 border-indigo-500/30 text-indigo-300' : 'bg-amber-500/15 border-amber-500/30 text-amber-300'
                        }`}>
                          {isPM ? 'PM' : 'Operation'}
                        </span>
                        {pm && (
                          <span className="font-mono font-bold text-cyan-400 text-[11px]">
                            {pm.machineId}
                          </span>
                        )}
                        <span className="font-bold text-slate-200 truncate text-xs">
                          {title}
                        </span>
                      </div>
                      <div className="text-[10.5px] text-slate-400 flex items-center gap-2 truncate">
                        <span>📅 {s.date}</span>
                        <span>•</span>
                        <span>👤 {s.technicians ? s.technicians.join(', ') : s.technician}</span>
                        {pm && (
                          <>
                            <span>•</span>
                            <span>⏱ {pm.duration} นาที</span>
                          </>
                        )}
                        {mach && (
                          <>
                            <span>•</span>
                            <span className="truncate">{mach.name}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0 text-right">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${
                      (s as PMScheduleItem).status === 'เสร็จสิ้น'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                        : (s as PMScheduleItem).status === 'กำลังทำ'
                        ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}>
                      {(s as PMScheduleItem).status || 'รอดำเนินการ'}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3 shrink-0 text-xs">
          <div className="text-slate-400">
            เลือกอยู่ <strong className="text-white font-mono">{selectedIds.size}</strong> งาน
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="button"
              onClick={handleConfirmDelete}
              disabled={isSubmitting || selectedIds.size === 0}
              className={`px-4 py-2 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-lg transition cursor-pointer ${
                selectedIds.size === 0
                  ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700'
                  : 'bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white shadow-rose-950/60'
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span>
                {isSubmitting ? 'กำลังลบ...' : `ยืนยันลบงานที่เลือก (${selectedIds.size} งาน)`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
