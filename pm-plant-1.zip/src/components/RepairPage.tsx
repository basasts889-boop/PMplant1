import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  RepairLog, 
  StoppageType, 
  STOPPAGE_TYPE_DEFINITIONS, 
  detectStoppageType, 
  getRepairStoppageType,
  SparePart,
  UsedPartItem,
  WorkOrder,
  RepairAttachmentItem,
  PDFFileAttachment,
  ImprovementProject
} from '../types';
import { 
  Plus, Search, SlidersHorizontal, Image as ImageIcon, 
  Trash2, AlertTriangle, CheckCircle, HelpCircle, ArrowUpDown,
  Edit, FileSpreadsheet, Upload, X, MessageSquare, Tag, Check, Sparkles,
  CheckCircle2, Clock, Wrench, Package, PenLine, PlusCircle, CheckSquare,
  FileText, BookOpen, ExternalLink, Paperclip, Eye, Download, UploadCloud
} from 'lucide-react';
import { notifyRepairOpened, notifyRepairClosed, sendLineNotification } from '../utils/lineNotify';
import { compressImageFile } from '../utils/imageUtils';
import { getTodayDateString } from '../utils/pmAlerts';
import * as XLSX from 'xlsx';
import { BreakdownImportModal } from './repair/BreakdownImportModal';
import { DateTimePicker24H } from './common/DateTimePicker24H';
import { WorkOrderDetailModal } from './workOrder/WorkOrderDetailModal';
import { PDFViewerModal } from './kaizen/PDFViewerModal';
import { ContextualKnowledgeAssistant } from './knowledge/ContextualKnowledgeAssistant';

export const RepairPage: React.FC = () => {
  const { 
    repairs, setRepairs, machines, technicians, spareParts, setSpareParts, settings, canEdit, canDelete,
    repairNavigationFilter, clearRepairNavigationFilter, setActivePage,
    workOrders, setWorkOrders, createEmergencyBreakdownWorkOrder,
    navigateToKaizen, improvements, setImprovements
  } = useApp();

  // Search/Filters states
  const [machineFilter, setMachineFilter] = useState('');
  const [techFilter, setTechFilter] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [mttrFilter, setMttrFilter] = useState<number>(0); // MTTR > X minutes
  const [stoppageFilter, setStoppageFilter] = useState<string>('ALL'); // 'ALL' | 'BREAKDOWN' | 'MINOR_STOPPAGE' | 'ADJUSTMENT_LOSS'
  const [sortBy, setSortBy] = useState<'date' | 'duration'>('date'); // default to date descending (newest first)

  // Machine Breakdown Import state
  const [showBreakdownImportModal, setShowBreakdownImportModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Add Repair Form visibility
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Excel Import states
  const [showImportModal, setShowImportModal] = useState(false);
  const [excelData, setExcelData] = useState<any[][]>([]);
  const [excelHeaders, setExcelHeaders] = useState<string[]>([]);
  const [fileName, setFileName] = useState<string>('');
  const [columnMap, setColumnMap] = useState<Record<string, string>>({
    machineId: '',
    symptoms: '',
    breakdownTime: '',
    repairDoneTime: '',
    correctiveAction: '',
    primaryTech: '',
    why1: '',
    why2: '',
    why3: '',
    why4: '',
    why5: '',
    otherCost: '',
    status: ''
  });
  const [importPreview, setImportPreview] = useState<RepairLog[]>([]);
  const [importError, setImportError] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);

  // View Details Modal state
  const [selectedRepairDetail, setSelectedRepairDetail] = useState<RepairLog | null>(null);

  // Custom Delete Confirm state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Bulk Selection and Bulk Delete states
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState<boolean>(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Auto-delete linked Work Order state when deleting repairs
  const [deleteLinkedWorkOrder, setDeleteLinkedWorkOrder] = useState<boolean>(true);

  // FA, OPL, Kaizen attachments states
  const [formAttachments, setFormAttachments] = useState<RepairAttachmentItem[]>([]);
  const [formSyncToKaizen, setFormSyncToKaizen] = useState<boolean>(true);
  const [activeAttachmentTab, setActiveAttachmentTab] = useState<'FA' | 'OPL' | 'WHY_WHY' | 'KAIZEN'>('FA');
  const [dragOverCategory, setDragOverCategory] = useState<string | null>(null);

  // Quick Attachment Modal for any repair directly from table/row/detail
  const [repairForQuickAttachment, setRepairForQuickAttachment] = useState<RepairLog | null>(null);

  // Preview modal for attachments (PDF, Excel)
  const [previewPDF, setPreviewPDF] = useState<PDFFileAttachment | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  // Form Inputs
  const [formMachine, setFormMachine] = useState(machines[0]?.id || '');
  const [formBreakdown, setFormBreakdown] = useState(() => `${getTodayDateString()}T09:00`);
  const [formDone, setFormDone] = useState(() => `${getTodayDateString()}T11:30`);
  const [formSymptoms, setFormSymptoms] = useState('');
  const [formTechnician, setFormTechnician] = useState(technicians[0] || 'ช่างอุ้ย');
  const [formTechnicians, setFormTechnicians] = useState<string[]>([]);
  const [formCorrection, setFormCorrection] = useState('');
  const [formStatus, setFormStatus] = useState<'กำลังซ่อม' | 'ปิดงาน'>('ปิดงาน');
  
  // CMMS Work Order Link states (No Work Order - No Work)
  const [formWorkOrderId, setFormWorkOrderId] = useState<string>('');
  const [formWorkOrderNo, setFormWorkOrderNo] = useState<string>('');
  const [selectedDetailWO, setSelectedDetailWO] = useState<WorkOrder | null>(null);
  const [isDetailWOModalOpen, setIsDetailWOModalOpen] = useState(false);
  
  // Spare parts in form state
  const [formUsedParts, setFormUsedParts] = useState<UsedPartItem[]>([]);
  const [partSourceMode, setPartSourceMode] = useState<'inventory' | 'custom'>('inventory');
  
  // Inventory selection state
  const [selectedPartId, setSelectedPartId] = useState('');
  const [partSearchQuery, setPartSearchQuery] = useState('');
  const [selectedPartQty, setSelectedPartQty] = useState<number>(1);
  const [selectedPartPrice, setSelectedPartPrice] = useState<number>(0);
  
  // Custom non-inventory spare part state
  const [customPartName, setCustomPartName] = useState('');
  const [customPartCode, setCustomPartCode] = useState('');
  const [customPartUnit, setCustomPartUnit] = useState('ชิ้น');
  const [customPartPrice, setCustomPartPrice] = useState<number>(0);
  const [customPartQty, setCustomPartQty] = useState<number>(1);
  const [saveCustomToMaster, setSaveCustomToMaster] = useState<boolean>(false);

  const [formOtherCost, setFormOtherCost] = useState<number>(0);

  // Stoppage Classification state (Breakdown / Minor stoppage / Adjustment loss)
  const [formStoppageType, setFormStoppageType] = useState<StoppageType>('BREAKDOWN');
  const [formHasPartsReplaced, setFormHasPartsReplaced] = useState<boolean>(false);
  const [isStoppageManual, setIsStoppageManual] = useState<boolean>(false);

  // Helper companion to add part from inventory to current list
  const handleAddPartToForm = () => {
    if (!selectedPartId) {
      alert("กรุณาเลือกอะไหล่ก่อน");
      return;
    }
    if (selectedPartQty <= 0) {
      alert("จำนวนอะไหล่ต้องมากกว่า 0");
      return;
    }
    const partObj = spareParts.find(p => p.id === selectedPartId);
    if (!partObj) return;

    // Check if part already in list
    const existingIndex = formUsedParts.findIndex(p => p.partId === selectedPartId);
    if (existingIndex >= 0) {
      setFormUsedParts(prev => prev.map((item, idx) => {
        if (idx === existingIndex) {
          const newQty = item.quantity + selectedPartQty;
          return {
            ...item,
            quantity: newQty,
            totalCost: newQty * item.pricePerUnit
          };
        }
        return item;
      }));
    } else {
      const price = selectedPartPrice > 0 ? selectedPartPrice : partObj.pricePerUnit;
      setFormUsedParts(prev => [...prev, {
        partId: selectedPartId,
        partName: partObj.name,
        quantity: selectedPartQty,
        pricePerUnit: price,
        totalCost: selectedPartQty * price,
        isCustom: false,
        unit: partObj.unit || 'ชิ้น'
      }]);
    }

    // Since parts are added, mark hasPartsReplaced as true and auto-recommend Breakdown
    setFormHasPartsReplaced(true);
    if (!isStoppageManual) {
      setFormStoppageType('BREAKDOWN');
    }

    // Reset part inputs
    setSelectedPartId('');
    setSelectedPartQty(1);
    setSelectedPartPrice(0);
  };

  // Helper companion to add custom non-inventory part
  const handleAddCustomPartToForm = () => {
    const trimmedName = customPartName.trim();
    if (!trimmedName) {
      alert("กรุณาระบุชื่อรายการอะไหล่");
      return;
    }
    if (customPartQty <= 0) {
      alert("จำนวนอะไหล่ต้องมากกว่า 0");
      return;
    }

    const qty = Number(customPartQty) || 1;
    const price = Math.max(0, Number(customPartPrice) || 0);
    const unit = customPartUnit.trim() || 'ชิ้น';
    const customId = customPartCode.trim() || `custom_${Date.now()}`;

    // Check if part already in list
    const existingIndex = formUsedParts.findIndex(p => 
      p.partId === customId || (p.isCustom && p.partName?.toLowerCase() === trimmedName.toLowerCase())
    );

    if (existingIndex >= 0) {
      setFormUsedParts(prev => prev.map((item, idx) => {
        if (idx === existingIndex) {
          const newQty = item.quantity + qty;
          return {
            ...item,
            quantity: newQty,
            totalCost: newQty * item.pricePerUnit
          };
        }
        return item;
      }));
    } else {
      setFormUsedParts(prev => [...prev, {
        partId: customId,
        partName: trimmedName,
        quantity: qty,
        pricePerUnit: price,
        totalCost: qty * price,
        isCustom: true,
        unit: unit
      }]);
    }

    // If user wants to also save this new part into Master Spare Parts inventory
    if (saveCustomToMaster) {
      const newMasterPart: SparePart = {
        id: customPartCode.trim() || `SP-EXT-${Date.now().toString().slice(-5)}`,
        name: trimmedName,
        category: 'จัดซื้อเร่งด่วน / นอกคลัง',
        machineIds: formMachine ? [formMachine] : [],
        quantity: 0,
        minRequired: 1,
        unit: unit,
        location: 'จัดซื้อเฉพาะกิจหน้างาน',
        pricePerUnit: price,
        lastRestockedDate: getTodayDateString()
      };
      if (!spareParts.some(sp => sp.id === newMasterPart.id)) {
        setSpareParts(prev => [...prev, newMasterPart]);
      }
    }

    // Since parts are added, mark hasPartsReplaced as true and auto-recommend Breakdown
    setFormHasPartsReplaced(true);
    if (!isStoppageManual) {
      setFormStoppageType('BREAKDOWN');
    }

    // Reset custom inputs
    setCustomPartName('');
    setCustomPartCode('');
    setCustomPartQty(1);
    setCustomPartPrice(0);
    setCustomPartUnit('ชิ้น');
    setSaveCustomToMaster(false);
  };

  const handleRemovePartFromForm = (partId: string) => {
    setFormUsedParts(prev => {
      const updated = prev.filter(p => p.partId !== partId);
      if (updated.length === 0 && !formHasPartsReplaced && !isStoppageManual) {
        // Recalculate based on live duration
        const duration = getLiveMttr();
        setFormStoppageType(duration < 15 ? 'MINOR_STOPPAGE' : 'ADJUSTMENT_LOSS');
      }
      return updated;
    });
  };
  
  // Why-Why Analysis inputs
  const [why1, setWhy1] = useState('');
  const [why2, setWhy2] = useState('');
  const [why3, setWhy3] = useState('');
  const [why4, setWhy4] = useState('');
  const [why5, setWhy5] = useState('');
  const [whyCount, setWhyCount] = useState(1); // Click to add Why levels up to 5

  // Photo
  const [photoBase64, setPhotoBase64] = useState<string>('');

  // Attached Excel File
  const [formExcelName, setFormExcelName] = useState<string>('');
  const [formExcelContent, setFormExcelContent] = useState<string>('');

  // Live MTTR calculation (minutes)
  const getLiveMttr = (): number => {
    if (!formBreakdown || !formDone) return 0;
    const startObj = new Date(formBreakdown);
    const endObj = new Date(formDone);
    const diff = endObj.getTime() - startObj.getTime();
    return diff > 0 ? Math.floor(diff / 60000) : 0;
  };

  const toggleTechnician = (techName: string) => {
    setFormTechnicians(prev => 
      prev.includes(techName) 
        ? prev.filter(t => t !== techName) 
        : [...prev, techName]
    );
  };

  // Image loading base64 helper
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const base64 = await compressImageFile(file);
        setPhotoBase64(base64);
      } catch (err) {
        console.error("Image compression failed:", err);
      }
    }
    e.target.value = '';
  };

  // Excel file attachment helper (also auto-links to Kaizen Why-Why)
  const handleExcelAttachmentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const content = reader.result as string;
        setFormExcelName(file.name);
        setFormExcelContent(content);

        // Auto-register as WHY_WHY attachment so it synchronizes directly to the Kaizen Why-Why tab
        const whyAtt: RepairAttachmentItem = {
          id: `att-why-${Date.now()}`,
          category: 'WHY_WHY',
          name: file.name,
          content,
          fileType: 'excel',
          size: `${(file.size / 1024).toFixed(1)} KB`,
          uploadedAt: new Date().toISOString()
        };
        setFormAttachments(prev => [...prev.filter(a => a.name !== file.name), whyAtt]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveRepair = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formMachine) {
      alert("กรุณาเลือกเครื่องจักร");
      return;
    }

    const calculatedDuration = getLiveMttr();
    if (calculatedDuration <= 0) {
      alert("กรุณาป้อนเวลาซ่อมเสร็จหลังจากเวลาชำรุดเครื่องจักร");
      return;
    }

    if (!formSymptoms.trim()) {
      alert("กรุณากรอกอาการเสียชำรุดหน้างาน");
      return;
    }

    if (formTechnicians.length === 0) {
      alert("กรุณาเลือกช่างผู้ปฏิบัติการอย่างน้อย 1 คน");
      return;
    }

    const primaryTech = formTechnicians[0] || formTechnician || (technicians[0] || 'ช่างอุ้ย');

    // Adjust inventory stock
    let tempSpareParts = [...spareParts];
    if (editingId) {
      const oldRepair = repairs.find(r => r.id === editingId);
      if (oldRepair && oldRepair.usedParts) {
        for (const op of oldRepair.usedParts) {
          tempSpareParts = tempSpareParts.map(sp => {
            if (sp.id === op.partId) {
              return { ...sp, quantity: sp.quantity + op.quantity };
            }
            return sp;
          });
        }
      }
    }
    // Deduct new parts
    for (const np of formUsedParts) {
      tempSpareParts = tempSpareParts.map(sp => {
        if (sp.id === np.partId) {
          return { ...sp, quantity: Math.max(0, sp.quantity - np.quantity) };
        }
        return sp;
      });
    }
    setSpareParts(tempSpareParts);

    const hasParts = (formUsedParts.length > 0) || formHasPartsReplaced;
    const finalStoppageType: StoppageType = isStoppageManual
      ? formStoppageType
      : detectStoppageType(hasParts, calculatedDuration);

    if (editingId) {
      const oldRepair = repairs.find(r => r.id === editingId);
      const isStatusChangedToClosed = oldRepair && oldRepair.status === 'กำลังซ่อม' && formStatus === 'ปิดงาน';

      const updatedRepair: RepairLog = {
        id: editingId,
        type: 'Repair',
        technician: primaryTech,
        technicians: formTechnicians,
        date: formBreakdown.split('T')[0],
        machineId: formMachine,
        breakdownTime: formBreakdown,
        repairDoneTime: formDone,
        symptoms: formSymptoms.trim(),
        stoppageType: finalStoppageType,
        hasPartsReplaced: hasParts,
        why1: why1.trim(),
        why2: why2.trim(),
        why3: why3.trim(),
        why4: why4.trim(),
        why5: why5.trim(),
        correctiveAction: formCorrection.trim() || 'ทำความสะอาดเครื่องและทดสอบเดินระบบ',
        photo: photoBase64 || undefined,
        duration: calculatedDuration,
        status: formStatus,
        usedParts: formUsedParts,
        otherCost: Number(formOtherCost) || 0,
        excelFile: formExcelName && formExcelContent ? { name: formExcelName, content: formExcelContent } : undefined,
        workOrderId: formWorkOrderId || undefined,
        workOrderNo: formWorkOrderNo || formWorkOrderId || undefined,
        faFile: formAttachments.find(a => a.category === 'FA'),
        oplFile: formAttachments.find(a => a.category === 'OPL'),
        whyWhyFile: formAttachments.find(a => a.category === 'WHY_WHY'),
        kaizenFile: formAttachments.find(a => a.category === 'KAIZEN'),
        repairAttachments: formAttachments
      };

      setRepairs(prev => prev.map(r => r.id === editingId ? updatedRepair : r));

      // Sync attachments to Kaizen improvements tab
      if (formSyncToKaizen && formAttachments.length > 0) {
        formAttachments.forEach(att => syncAttachmentToKaizen(att, updatedRepair));
      }

      if (isStatusChangedToClosed) {
        const machineObj = machines.find(m => m.id === formMachine);
        const prefix = formMachine.substring(0, 3);
        const stdMttr = settings.stdMttr?.[prefix] || 60;
        notifyRepairClosed(updatedRepair, machineObj?.name || '', stdMttr).catch(console.error);
      }
    } else {
      const newLogId = `rep-${Date.now()}`;
      const newLog: RepairLog = {
        id: newLogId,
        type: 'Repair',
        technician: primaryTech,
        technicians: formTechnicians,
        date: formBreakdown.split('T')[0],
        machineId: formMachine,
        breakdownTime: formBreakdown,
        repairDoneTime: formDone,
        symptoms: formSymptoms.trim(),
        stoppageType: finalStoppageType,
        hasPartsReplaced: hasParts,
        why1: why1.trim(),
        why2: why2.trim(),
        why3: why3.trim(),
        why4: why4.trim(),
        why5: why5.trim(),
        correctiveAction: formCorrection.trim() || 'ทำความสะอาดเครื่องและทดสอบเดินระบบ',
        photo: photoBase64 || undefined,
        duration: calculatedDuration,
        status: formStatus,
        usedParts: formUsedParts,
        otherCost: Number(formOtherCost) || 0,
        excelFile: formExcelName && formExcelContent ? { name: formExcelName, content: formExcelContent } : undefined,
        workOrderId: formWorkOrderId || undefined,
        workOrderNo: formWorkOrderNo || formWorkOrderId || undefined,
        faFile: formAttachments.find(a => a.category === 'FA'),
        oplFile: formAttachments.find(a => a.category === 'OPL'),
        whyWhyFile: formAttachments.find(a => a.category === 'WHY_WHY'),
        kaizenFile: formAttachments.find(a => a.category === 'KAIZEN'),
        repairAttachments: formAttachments
      };
      setRepairs(prev => [newLog, ...prev]);

      // Sync attachments to Kaizen improvements tab
      if (formSyncToKaizen && formAttachments.length > 0) {
        formAttachments.forEach(att => syncAttachmentToKaizen(att, newLog));
      }

      // Notify LINE if enabled
      const machineObj = machines.find(m => m.id === formMachine);
      if (formStatus === 'กำลังซ่อม') {
        notifyRepairOpened(newLog, machineObj?.name || '').catch(console.error);
      } else {
        const prefix = formMachine.substring(0, 3);
        const stdMttr = settings.stdMttr?.[prefix] || 60;
        notifyRepairClosed(newLog, machineObj?.name || '', stdMttr).catch(console.error);
      }
    }

    setShowFormModal(false);

    // Reset Form
    setEditingId(null);
    setFormSymptoms('');
    setFormCorrection('');
    setWhy1(''); setWhy2(''); setWhy3(''); setWhy4(''); setWhy5('');
    setWhyCount(1);
    photoBase64 && setPhotoBase64('');
    setFormExcelName('');
    setFormExcelContent('');
    setFormTechnicians([]);
    setFormStatus('ปิดงาน');
    setFormUsedParts([]);
    setFormOtherCost(0);
    setPartSourceMode('inventory');
    setSelectedPartId('');
    setPartSearchQuery('');
    setSelectedPartQty(1);
    setSelectedPartPrice(0);
    setCustomPartName('');
    setCustomPartCode('');
    setCustomPartQty(1);
    setCustomPartPrice(0);
    setCustomPartUnit('ชิ้น');
    setSaveCustomToMaster(false);
    setFormStoppageType('BREAKDOWN');
    setFormHasPartsReplaced(false);
    setIsStoppageManual(false);
    setFormWorkOrderId('');
    setFormWorkOrderNo('');
    setFormAttachments([]);
    setFormSyncToKaizen(true);
    setActiveAttachmentTab('FA');
  };

  // Helper to sync FA, OPL, or Kaizen attachment to Improvement projects in Kaizen tab
  const syncAttachmentToKaizen = (att: RepairAttachmentItem, repLog: RepairLog) => {
    const existingProj = att.kaizenProjectId ? improvements.find(i => i.id === att.kaizenProjectId) : null;
    const projId = existingProj?.id || `${att.category}-${repLog.machineId}-${Date.now().toString().slice(-5)}`;
    att.kaizenProjectId = projId;

    const newProj: ImprovementProject = {
      id: projId,
      type: 'Improvement',
      category: att.category,
      title: att.category === 'FA'
        ? `[FA] วิเคราะห์ความเสียหาย ${repLog.machineId}: ${repLog.symptoms.slice(0, 45)}`
        : att.category === 'OPL'
        ? `[OPL] บทเรียนจุดเดียว ${repLog.machineId}: ${repLog.correctiveAction ? repLog.correctiveAction.slice(0, 45) : repLog.symptoms.slice(0, 45)}`
        : att.category === 'WHY_WHY'
        ? `[Why-Why] วิเคราะห์รากเหง้า ${repLog.machineId}: ${repLog.symptoms.slice(0, 45)}`
        : `[Kaizen] ปรับปรุงลดการหยุดเครื่อง ${repLog.machineId}: ${repLog.symptoms.slice(0, 45)}`,
      description: `เอกสาร ${att.category} แนบประกอบจากบันทึกงานซ่อมเบรกดาวน์ #${repLog.id} (เครื่อง ${repLog.machineId}) วันที่ ${repLog.date}`,
      machineId: repLog.machineId,
      startDate: repLog.date,
      plannedEndDate: repLog.date,
      workLogs: [],
      status: 'เสร็จแล้ว',
      technician: repLog.technician || 'ช่างประจำกะ',
      photoBefore: repLog.photo,
      pdfFiles: [
        {
          id: `pdf-${att.id}`,
          name: att.name,
          content: att.content,
          fileType: att.fileType === 'excel' ? 'excel' : 'pdf',
          size: att.size,
          uploadedAt: att.uploadedAt
        },
        ...(repLog.excelFile && repLog.excelFile.name !== att.name ? [{
          id: `excel-${repLog.id}`,
          name: repLog.excelFile.name,
          content: repLog.excelFile.content,
          fileType: 'excel' as const,
          size: 'ไฟล์แนบ Excel',
          uploadedAt: repLog.date
        }] : []),
        ...(repLog.whyWhyFile && repLog.whyWhyFile.name !== att.name ? [{
          id: `why-${repLog.whyWhyFile.id}`,
          name: repLog.whyWhyFile.name,
          content: repLog.whyWhyFile.content,
          fileType: (repLog.whyWhyFile.fileType === 'excel' ? 'excel' : 'pdf') as 'excel' | 'pdf',
          size: repLog.whyWhyFile.size || 'เอกสาร Why-Why',
          uploadedAt: repLog.whyWhyFile.uploadedAt || repLog.date
        }] : [])
      ],
      faData: att.category === 'FA' ? {
        failurePartName: repLog.symptoms.slice(0, 40),
        failureMode: 'การแตกหัก (Fracture/Crack)',
        rootCauseCategory: 'การบำรุงรักษา (Maintenance)',
        mechanismDescription: repLog.why1 || 'ความเสียหายและการสึกหรอของชิ้นส่วน',
        immediateContainment: repLog.correctiveAction || 'แก้ไขและเปลี่ยนชิ้นส่วนหน้างาน',
        permanentAction: repLog.why5 || repLog.correctiveAction || 'กำหนดความถี่ตรวจสอบและเฝ้าระวัง'
      } : undefined,
      oplData: att.category === 'OPL' ? {
        category: 'การแก้ไขปัญหา (Troubleshooting)',
        purpose: `การป้องกันการชำรุดซ้ำ [${repLog.machineId}]`,
        keyPoints: [repLog.correctiveAction || repLog.why1 || 'ปฏิบัติตามมาตรฐานคู่มือและตรวจสอบก่อนเดินเครื่อง'],
        targetAudience: 'ทีมช่างซ่อมบำรุง และพนักงานเดินเครื่อง (Operator)'
      } : undefined,
      whyWhyData: att.category === 'WHY_WHY' ? {
        problemStatement: repLog.symptoms,
        phenomenon: repLog.symptoms,
        why1: repLog.why1 || '',
        why2: repLog.why2 || '',
        why3: repLog.why3 || '',
        why4: repLog.why4 || '',
        why5: repLog.why5 || '',
        rootCauseSummary: repLog.why5 || repLog.why4 || repLog.why3 || repLog.why2 || repLog.why1 || 'วิเคราะห์สาเหตุรากเหง้าตามลำดับ 5 Whys',
        countermeasure: repLog.correctiveAction || 'มาตรการแก้ไขและป้องกันการเกิดซ้ำ',
        standardizationRef: repLog.workOrderNo || repLog.workOrderId || `BD-REF-${repLog.id}`
      } : undefined
    };

    setImprovements(prev => {
      const exists = prev.some(p => p.id === projId);
      if (exists) {
        return prev.map(p => p.id === projId ? newProj : p);
      }
      return [newProj, ...prev];
    });
  };

  const handleAttachmentUpload = (file: File, category: 'FA' | 'OPL' | 'WHY_WHY' | 'KAIZEN', targetRepair?: RepairLog) => {
    const reader = new FileReader();
    const fileExt = file.name.split('.').pop()?.toLowerCase();
    let fileType: 'pdf' | 'excel' | 'image' | 'word' | 'other' = 'other';
    if (fileExt === 'pdf') fileType = 'pdf';
    else if (['xlsx', 'xls', 'csv'].includes(fileExt || '')) fileType = 'excel';
    else if (['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(fileExt || '')) fileType = 'image';
    else if (['doc', 'docx'].includes(fileExt || '')) fileType = 'word';

    // Auto-detect WHY_WHY if filename contains "why"
    let effectiveCategory = category;
    if (effectiveCategory !== 'WHY_WHY' && /why/i.test(file.name)) {
      effectiveCategory = 'WHY_WHY';
    }

    reader.onload = (e) => {
      const content = e.target?.result as string;
      const newAtt: RepairAttachmentItem = {
        id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        category: effectiveCategory,
        name: file.name,
        content,
        fileType,
        size: `${(file.size / 1024).toFixed(1)} KB`,
        uploadedAt: new Date().toISOString()
      };

      if (targetRepair) {
        // Quick attachment directly for targetRepair
        setRepairs(prevRepairs => {
          const currentTarget = prevRepairs.find(r => r.id === targetRepair.id) || targetRepair;
          const existingAtts = currentTarget.repairAttachments || [
            ...(currentTarget.faFile ? [currentTarget.faFile] : []),
            ...(currentTarget.oplFile ? [currentTarget.oplFile] : []),
            ...(currentTarget.whyWhyFile ? [currentTarget.whyWhyFile] : []),
            ...(currentTarget.kaizenFile ? [currentTarget.kaizenFile] : [])
          ];
          const updatedAtts = [...existingAtts.filter(a => a.id !== newAtt.id), newAtt];
          const updated: RepairLog = {
            ...currentTarget,
            faFile: effectiveCategory === 'FA' ? newAtt : currentTarget.faFile,
            oplFile: effectiveCategory === 'OPL' ? newAtt : currentTarget.oplFile,
            whyWhyFile: effectiveCategory === 'WHY_WHY' ? newAtt : currentTarget.whyWhyFile,
            kaizenFile: effectiveCategory === 'KAIZEN' ? newAtt : currentTarget.kaizenFile,
            repairAttachments: updatedAtts
          };
          syncAttachmentToKaizen(newAtt, updated);
          setRepairForQuickAttachment(updated);
          if (selectedRepairDetail?.id === targetRepair.id) {
            setSelectedRepairDetail(updated);
          }
          return prevRepairs.map(r => r.id === targetRepair.id ? updated : r);
        });
        showToast(`📎 แนบไฟล์ ${effectiveCategory}: ${file.name} และเชื่อมโยงไปแถบ Kaizen เรียบร้อย`);
      } else {
        // Inside Create / Edit Form
        setFormAttachments(prev => [...prev.filter(a => a.category !== effectiveCategory || a.name !== file.name), newAtt]);
        showToast(`📎 เพิ่มไฟล์ ${effectiveCategory}: ${file.name} เรียบร้อยแล้ว`);
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePasteEvent = (e: React.ClipboardEvent, category: 'FA' | 'OPL' | 'WHY_WHY' | 'KAIZEN', targetRepair?: RepairLog) => {
    if (e.clipboardData && e.clipboardData.files && e.clipboardData.files.length > 0) {
      e.preventDefault();
      const file = e.clipboardData.files[0];
      handleAttachmentUpload(file, category, targetRepair);
    }
  };

  const handleRemoveAttachment = (id: string, targetRepair?: RepairLog) => {
    if (targetRepair) {
      const existingAtts = targetRepair.repairAttachments || [
        ...(targetRepair.faFile ? [targetRepair.faFile] : []),
        ...(targetRepair.oplFile ? [targetRepair.oplFile] : []),
        ...(targetRepair.whyWhyFile ? [targetRepair.whyWhyFile] : []),
        ...(targetRepair.kaizenFile ? [targetRepair.kaizenFile] : [])
      ];
      const updatedAtts = existingAtts.filter(a => a.id !== id);
      const updated: RepairLog = {
        ...targetRepair,
        faFile: targetRepair.faFile?.id === id ? undefined : targetRepair.faFile,
        oplFile: targetRepair.oplFile?.id === id ? undefined : targetRepair.oplFile,
        whyWhyFile: targetRepair.whyWhyFile?.id === id ? undefined : targetRepair.whyWhyFile,
        kaizenFile: targetRepair.kaizenFile?.id === id ? undefined : targetRepair.kaizenFile,
        repairAttachments: updatedAtts
      };
      setRepairs(prev => prev.map(r => r.id === targetRepair.id ? updated : r));
      setRepairForQuickAttachment(updated);
      if (selectedRepairDetail?.id === targetRepair.id) {
        setSelectedRepairDetail(updated);
      }
      showToast('🗑️ ลบไฟล์แนบเรียบร้อย');
    } else {
      setFormAttachments(prev => prev.filter(a => a.id !== id));
      showToast('🗑️ นำไฟล์แนบออกจากรายการแล้ว');
    }
  };

  const handleNavigateToKaizenProject = (att: RepairAttachmentItem, machineId: string) => {
    navigateToKaizen({
      category: att.category,
      machineId,
      projectId: att.kaizenProjectId,
      searchQuery: att.name
    });
    setSelectedRepairDetail(null);
    setRepairForQuickAttachment(null);
  };

  const handleEditClick = (log: RepairLog) => {
    setEditingId(log.id);
    setFormMachine(log.machineId);
    setFormBreakdown(log.breakdownTime);
    setFormDone(log.repairDoneTime);
    setFormSymptoms(log.symptoms);
    setFormTechnician(log.technician);
    setFormTechnicians(log.technicians || (log.technician ? [log.technician] : []));
    setFormCorrection(log.correctiveAction);
    setFormStatus(log.status || 'ปิดงาน');
    setFormWorkOrderId(log.workOrderId || '');
    setFormWorkOrderNo(log.workOrderNo || log.workOrderId || '');
    setWhy1(log.why1 || '');
    setWhy2(log.why2 || '');
    setWhy3(log.why3 || '');
    setWhy4(log.why4 || '');
    setWhy5(log.why5 || '');
    
    // count active why levels
    let count = 1;
    if (log.why5) count = 5;
    else if (log.why4) count = 4;
    else if (log.why3) count = 3;
    else if (log.why2) count = 2;
    setWhyCount(count);

    const hasParts = Boolean(log.hasPartsReplaced || (log.usedParts && log.usedParts.length > 0));
    const detectedType = getRepairStoppageType(log);
    setFormStoppageType(log.stoppageType || detectedType);
    setFormHasPartsReplaced(hasParts);
    setIsStoppageManual(Boolean(log.stoppageType));

    setPhotoBase64(log.photo || '');
    setFormExcelName(log.excelFile?.name || '');
    setFormExcelContent(log.excelFile?.content || '');
    setFormUsedParts(log.usedParts || []);
    setFormOtherCost(log.otherCost || 0);
    setPartSourceMode('inventory');
    setSelectedPartId('');
    setPartSearchQuery('');
    setSelectedPartQty(1);
    setSelectedPartPrice(0);
    setCustomPartName('');
    setCustomPartCode('');
    setCustomPartQty(1);
    setCustomPartPrice(0);
    setCustomPartUnit('ชิ้น');
    setSaveCustomToMaster(false);

    // Initialize FA/OPL/Kaizen attachments from existing log
    const initialAtts = log.repairAttachments && log.repairAttachments.length > 0
      ? log.repairAttachments
      : [
          ...(log.faFile ? [log.faFile] : []),
          ...(log.oplFile ? [log.oplFile] : []),
          ...(log.whyWhyFile ? [log.whyWhyFile] : []),
          ...(log.kaizenFile ? [log.kaizenFile] : [])
        ];
    setFormAttachments(initialAtts);
    setFormSyncToKaizen(true);
    setActiveAttachmentTab(log.whyWhyFile ? 'WHY_WHY' : log.faFile ? 'FA' : log.oplFile ? 'OPL' : log.kaizenFile ? 'KAIZEN' : 'WHY_WHY');
    
    setShowFormModal(true);
  };

  const handleDeleteRepair = (id: string) => {
    setDeleteConfirmId(id);
  };

  // Detect breakdown repairs with deleted / orphaned work orders
  const orphanedDeletedRepairs = useMemo(() => {
    return repairs.filter(r => {
      const woRef = r.workOrderNo || r.workOrderId;
      if (!woRef) return false;
      const exists = workOrders.some(w => 
        w.id === woRef || 
        (w.workOrderNo && w.workOrderNo === woRef) ||
        (r.workOrderId && (w.id === r.workOrderId || w.workOrderNo === r.workOrderId))
      );
      return !exists;
    });
  }, [repairs, workOrders]);

  const handleBatchCleanOrphanedWOs = () => {
    const orphanedIds = new Set(orphanedDeletedRepairs.map(r => r.id));
    setRepairs(prev => prev.map(r => {
      if (orphanedIds.has(r.id)) {
        return { ...r, workOrderId: undefined, workOrderNo: undefined };
      }
      return r;
    }));
    showToast(`🧹 ล้างการเชื่อมโยงใบงาน WO ที่โดนลบไปแล้ว ${orphanedIds.size} รายการ เรียบร้อยแล้ว`);
  };

  const handleBatchRecreateOrphanedWOs = () => {
    let createdCount = 0;
    const updatedMap = new Map<string, string>();

    orphanedDeletedRepairs.forEach(r => {
      const created = createEmergencyBreakdownWorkOrder({
        machineId: r.machineId,
        title: `ซ่อมฉุกเฉิน ${r.machineId}: ${r.symptoms.slice(0, 35)}`,
        symptoms: r.symptoms,
        leadTech: r.technician || (r.technicians && r.technicians[0]) || 'ช่างประจำกะ',
        targetDurationMins: r.duration || 60
      });
      updatedMap.set(r.id, created.id);
      createdCount++;
    });

    setRepairs(prev => prev.map(r => {
      const newWOId = updatedMap.get(r.id);
      if (newWOId) {
        return { ...r, workOrderId: newWOId, workOrderNo: newWOId };
      }
      return r;
    }));

    showToast(`⚡ ออกใบสั่งงานฉุกเฉินใหม่ครบทั้ง ${createdCount} รายการ เรียบร้อยแล้ว`);
  };

  // Get machine standard MTTR by prefix or fallback
  const getStandardMttr = (mId: string): number => {
    // Find matching prefix in machine id like "RIM", "VAC", "FFS"
    const prefix = mId.slice(0, 3).toUpperCase();
    const defaults: Record<string, number> = {
      "RIM": 60, "TOC": 45, "VAC": 90, "FFS": 60, "ATS": 60, 
      "MTD": 30, "XRA": 45, "RFD": 45, "BAN": 45, "BCF": 120, 
      "CDU": 120, "TLP": 30, "INK": 30, "STK": 45, "OFR": 90, 
      "RJT": 30, "PAC": 60, "BCH": 90, "LSE": 45, "CLM": 60, 
      "SEH": 60, "CUC": 30, "RST": 90, "RSW": 90, "CUF": 60, 
      "RPT": 60, "WDV": 30, "WDR": 30, "TTB": 30, "FDJ": 30, 
      "FMC": 30
    };
    return defaults[prefix] || 60; // 60 mins fallback standard
  };

  // Export All Filtered Repairs to Excel/CSV with dynamic Thai BOM support
  const handleExportAllToExcel = () => {
    const headers = [
      'รหัสใบงาน',
      'รหัสเครื่องจักร',
      'ชื่อเครื่องจักร',
      'กลุ่มระบบสายผลิต',
      'ประเภทความสูญเสีย (Loss Classification)',
      'นิยามความสูญเสีย',
      'หน่วยนับ',
      'การเปลี่ยนอะไหล่',
      'อาการเสียชำรุด',
      'เวลารายงานเสีย',
      'เวลาซ่อมเสร็จ',
      'ระยะเวลา MTTR (นาที)',
      'เกณฑ์มาตรฐาน (MTTR)',
      'ช่างเทคนิคปฏิบัติการ',
      'มาตรการแก้และป้องกันถาวร',
      'Why 1',
      'Why 2',
      'Why 3',
      'Why 4',
      'Why 5',
      'สถานะใบงาน'
    ];

    const csvRows = [headers.map(h => `"${h.replace(/"/g, '""')}"`).join(',')];

    filteredRepairs.forEach(r => {
      const machDetail = machines.find(m => m.id === r.machineId);
      const machName = machDetail ? machDetail.name : 'เครื่องจักรทั่วไป';
      const dept = machDetail ? machDetail.lineGroup : '-';
      const techsStr = r.technicians && r.technicians.length > 0 ? r.technicians.join(' / ') : r.technician;
      const sType = getRepairStoppageType(r);
      const sDef = STOPPAGE_TYPE_DEFINITIONS[sType];
      const hasParts = (r.usedParts && r.usedParts.length > 0) || r.hasPartsReplaced;
      const partsText = hasParts ? `มีการเปลี่ยนอะไหล่ (${r.usedParts?.length || 1} รายการ)` : 'ไม่มีการเปลี่ยนอะไหล่';
      
      const row = [
        r.id,
        r.machineId,
        machName,
        dept,
        sDef.name,
        sDef.definition,
        sDef.unit,
        partsText,
        r.symptoms,
        r.breakdownTime || r.date,
        r.repairDoneTime || '-',
        r.duration,
        `${getStandardMttr(r.machineId)} นาที`,
        techsStr,
        r.correctiveAction,
        r.why1 || '',
        r.why2 || '',
        r.why3 || '',
        r.why4 || '',
        r.why5 || '',
        r.status
      ];
      
      csvRows.push(row.map(val => {
        const str = String(val === null || val === undefined ? '' : val);
        return `"${str.replace(/"/g, '""')}"`;
      }).join(','));
    });

    const csvContent = '\uFEFF' + csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `MTTR_Repair_History_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export single selected repair detail report to Excel/CSV with dynamic Thai BOM support
  const handleExportSingleToExcel = (r: RepairLog) => {
    const machDetail = machines.find(m => m.id === r.machineId);
    const machName = machDetail ? machDetail.name : 'เครื่องจักรทั่วไป';
    const dept = machDetail ? machDetail.lineGroup : '-';
    const sType = getRepairStoppageType(r);
    const sDef = STOPPAGE_TYPE_DEFINITIONS[sType];
    const hasParts = (r.usedParts && r.usedParts.length > 0) || r.hasPartsReplaced;
    const partsText = hasParts ? `มีการเปลี่ยนอะไหล่ (${r.usedParts?.length || 1} รายการ)` : 'ไม่มีการเปลี่ยนอะไหล่';
    
    const rows = [
      ['รายงานผลวิเคราะห์การชำรุดและการหยุดงานเครื่องจักร (Breakdown Analysis File)'],
      [],
      ['รหัสเอกสารการซ่อม', r.id],
      ['สถานะของใบงาน', r.status === 'กำลังซ่อม' ? 'อยู่ระหว่างดำเนินการซ่อมบำรุง' : 'ปิดประวัติซ่อมสมบูรณ์'],
      [],
      ['จำแนกประเภทความสูญเสีย (Loss & Failure Classification)'],
      ['ประเภทความสูญเสีย', sDef.name],
      ['คำนิยามตามมาตรฐาน', sDef.definition],
      ['หน่วยนับ', sDef.unit],
      ['บันทึกเวลา MTTR', `${r.duration} นาที`],
      ['สถานะการเปลี่ยนอะไหล่', partsText],
      [],
      ['รายละเอียดหน่วยขัดข้องเครื่องจักร'],
      ['รหัสเครื่องจักร (Machine ID)', r.machineId],
      ['ชื่อเครื่องจักรผู้ประสบเหตุ', machName],
      ['แผนก/สายการผลิต (Classification)', dept],
      [],
      ['แดชบอร์ดช่วงเวลาและกระทบขัดข้อง (MTTR Metrics)'],
      ['เวลาเกิดสัญญาณเสียขัดข้อง', r.breakdownTime ? r.breakdownTime.replace('T', ' ') : r.date],
      ['เวลาวิชาการซ่อมแล้วเสร็จคืนผลิต', r.repairDoneTime ? r.repairDoneTime.replace('T', ' ') : '-'],
      ['รวมระยะเวลารวบหยุดเครื่องปฏิบัติซ่อมจริง (นาที)', r.duration],
      ['อัตราตรวจซ่อมตามมาตรฐาน (Target MTTR)', `${getStandardMttr(r.machineId)} นาที`],
      [],
      ['รายละเอียดอาการแจ้งขัดข้องจริง', r.symptoms],
      ['มาตรการแก้ไขและป้องกันเชิงรับถาวร (Action Taken)', r.correctiveAction],
      [],
      ['การวิเคราะห์หาสาเหตุขีดสุดรากเหง้า (Why-Why Analysis)'],
      ['ทำไมชั้นที่ 1 (Why 1)', r.why1 || '-'],
      ['ทำไมชั้นที่ 2 (Why 2)', r.why2 || '-'],
      ['ทำไมชั้นที่ 3 (Why 3)', r.why3 || '-'],
      ['ทำไมชั้นที่ 4 (Why 4)', r.why4 || '-'],
      ['ทำไมชั้นที่ 5 (Why 5)', r.why5 || '-'],
      [],
      ['พนักงานรักษาการ/ทีมช่างเทคนิคผู้ดูแลคุมซ่อม', (r.technicians && r.technicians.length > 0 ? r.technicians.join(', ') : r.technician)]
    ];

    const csvContent = '\uFEFF' + rows.map(row => row.map(val => {
      const str = String(val === null || val === undefined ? '' : val);
      return `"${str.replace(/"/g, '""')}"`;
    }).join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Why_Why_Analysis_Report_${r.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- EXCEL IMPORT LOGIC ---

  // Generate preview items when excelData or columnMap changes
  useEffect(() => {
    if (excelData.length === 0) {
      setImportPreview([]);
      return;
    }

    const headers = excelHeaders;
    const rows = excelData.slice(1);

    const parsedLogs: RepairLog[] = rows.map((row, rowIdx) => {
      const rowObj: Record<string, any> = {};
      headers.forEach((h, colIdx) => {
        rowObj[h] = row[colIdx];
      });

      const getVal = (key: string) => {
        const colName = columnMap[key];
        if (!colName) return '';
        const v = rowObj[colName];
        return v !== undefined && v !== null ? String(v).trim() : '';
      };

      const machineIdInput = getVal('machineId');
      const symptomsInput = getVal('symptoms') || 'แจ้งซ่อมบำรุงผ่านการนำเข้าไฟล์';
      const breakdownTimeInput = getVal('breakdownTime');
      const repairDoneTimeInput = getVal('repairDoneTime');
      const correctiveInput = getVal('correctiveAction') || 'ทำความสะอาดเครื่องและตรวจสอบเดินระบบ';
      const primaryTechInput = getVal('primaryTech') || technicians[0] || 'ช่างทั่วไป';
      
      const why1Val = getVal('why1');
      const why2Val = getVal('why2');
      const why3Val = getVal('why3');
      const why4Val = getVal('why4');
      const why5Val = getVal('why5');
      const otherCostVal = Number(getVal('otherCost')) || 0;
      const statusInput = getVal('status');

      // Standardize status: defaults to 'ปิดงาน' unless specified as 'กำลังซ่อม'
      let status: 'กำลังซ่อม' | 'ปิดงาน' = 'ปิดงาน';
      if (statusInput.includes('ซ่อม') || statusInput.toLowerCase().includes('pending') || statusInput.toLowerCase().includes('repair')) {
        status = 'กำลังซ่อม';
      }

      // Handle times
      let breakdownTime = breakdownTimeInput;
      if (!breakdownTime) {
        breakdownTime = new Date().toISOString().slice(0, 16);
      } else {
        breakdownTime = breakdownTime.replace(' ', 'T');
      }

      let repairDoneTime = repairDoneTimeInput;
      if (repairDoneTime) {
        repairDoneTime = repairDoneTime.replace(' ', 'T');
      } else {
        repairDoneTime = '';
      }

      // Calculate duration
      let duration = 60;
      if (breakdownTime && repairDoneTime && status === 'ปิดงาน') {
        const t1 = new Date(breakdownTime).getTime();
        const t2 = new Date(repairDoneTime).getTime();
        if (!isNaN(t1) && !isNaN(t2) && t2 > t1) {
          duration = Math.round((t2 - t1) / 1000 / 60);
        }
      }

      return {
        id: `rep-${Date.now()}-${rowIdx}`,
        type: 'Repair',
        technician: primaryTechInput,
        technicians: [primaryTechInput],
        date: breakdownTime.split('T')[0] || new Date().toISOString().slice(0, 10),
        machineId: machineIdInput || 'UNKNOWN',
        breakdownTime,
        repairDoneTime: status === 'ปิดงาน' ? repairDoneTime : '',
        symptoms: symptomsInput,
        why1: why1Val,
        why2: why2Val,
        why3: why3Val,
        why4: why4Val,
        why5: why5Val,
        correctiveAction: correctiveInput,
        duration,
        status,
        usedParts: [],
        otherCost: otherCostVal
      };
    });

    setImportPreview(parsedLogs);
  }, [excelData, columnMap, technicians]);

  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement> | React.DragEvent<HTMLDivElement>, isDrop: boolean = false) => {
    if (isDrop) {
      e.preventDefault();
    }
    
    let files: FileList | null = null;
    if (isDrop) {
      const de = e as React.DragEvent<HTMLDivElement>;
      files = de.dataTransfer.files;
    } else {
      const ce = e as React.ChangeEvent<HTMLInputElement>;
      files = ce.target.files;
    }

    if (!files || files.length === 0) return;
    const file = files[0];
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
        
        if (data.length === 0) {
          alert('ไม่พบข้อมูลแถวใดๆ ในไฟล์ Excel ที่เลือก');
          return;
        }

        const headers = (data[0] as any[]).map(h => String(h || '').trim());
        setExcelHeaders(headers);
        setExcelData(data as any[][]);

        // Smart map guesser
        const map: Record<string, string> = {
          machineId: '',
          symptoms: '',
          breakdownTime: '',
          repairDoneTime: '',
          correctiveAction: '',
          primaryTech: '',
          why1: '',
          why2: '',
          why3: '',
          why4: '',
          why5: '',
          otherCost: '',
          status: ''
        };

        headers.forEach((h: string) => {
          const hLower = h.toLowerCase().trim();
          
          if (hLower.includes('machine') || hLower.includes('เครื่องจักร') || hLower.includes('รหัสเครื่อง') || hLower.includes('เครื่อง')) {
            map.machineId = h;
          }
          else if (hLower.includes('symptom') || hLower.includes('อาการ') || hLower.includes('ชำรุด') || hLower.includes('ปัญหา')) {
            map.symptoms = h;
          }
          else if (hLower.includes('breakdown') || hLower.includes('เวลารายงาน') || hLower.includes('เวลาเสีย') || hLower.includes('แจ้งซ่อม')) {
            map.breakdownTime = h;
          }
          else if (hLower.includes('done') || hLower.includes('เสร็จ') || hLower.includes('เวลาคืนผลิต') || hLower.includes('เวลาซ่อมเสร็จ')) {
            map.repairDoneTime = h;
          }
          else if (hLower.includes('action') || hLower.includes('corrective') || hLower.includes('แก้ไข') || hLower.includes('มาตรการ')) {
            map.correctiveAction = h;
          }
          else if (hLower.includes('tech') || hLower.includes('ช่าง') || hLower.includes('ผู้ซ่อม')) {
            map.primaryTech = h;
          }
          else if (hLower.includes('why 1') || hLower.includes('why1') || hLower.includes('ทำไม 1') || hLower.includes('ทำไมที่ 1') || hLower.includes('ทำไมชั้นที่ 1')) {
            map.why1 = h;
          }
          else if (hLower.includes('why 2') || hLower.includes('why2') || hLower.includes('ทำไม 2') || hLower.includes('ทำไมที่ 2') || hLower.includes('ทำไมชั้นที่ 2')) {
            map.why2 = h;
          }
          else if (hLower.includes('why 3') || hLower.includes('why3') || hLower.includes('ทำไม 3') || hLower.includes('ทำไมที่ 3') || hLower.includes('ทำไมชั้นที่ 3')) {
            map.why3 = h;
          }
          else if (hLower.includes('why 4') || hLower.includes('why4') || hLower.includes('ทำไม 4') || hLower.includes('ทำไมที่ 4') || hLower.includes('ทำไมชั้นที่ 4')) {
            map.why4 = h;
          }
          else if (hLower.includes('why 5') || hLower.includes('why5') || hLower.includes('ทำไม 5') || hLower.includes('ทำไมที่ 5') || hLower.includes('ทำไมชั้นที่ 5')) {
            map.why5 = h;
          }
          else if (hLower.includes('cost') || hLower.includes('ค่าแรง') || hLower.includes('ค่าใช้จ่าย') || hLower.includes('บาท')) {
            map.otherCost = h;
          }
          else if (hLower.includes('status') || hLower.includes('สถานะ') || hLower.includes('สเตตัส')) {
            map.status = h;
          }
        });

        setColumnMap(map);
        setImportError('');
      } catch (err) {
        console.error(err);
        alert('เกิดข้อผิดพลาดในการอ่านไฟล์: ' + (err as Error).message);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleImportSubmit = () => {
    if (importPreview.length === 0) {
      alert('ไม่มีข้อมูลสำหรับนำเข้า กรุณาเลือกไฟล์และตรวจสอบแมปคอลัมน์');
      return;
    }

    const finalRepairs = importPreview.map(rep => {
      const exists = machines.some(m => m.id.toLowerCase() === rep.machineId.toLowerCase());
      if (!exists) {
        const found = machines.find(m => m.id.toLowerCase().trim() === rep.machineId.toLowerCase().trim());
        if (found) {
          rep.machineId = found.id;
        } else {
          rep.machineId = machines[0]?.id || 'RIM01';
        }
      }
      return rep;
    });

    setRepairs(prev => [...finalRepairs, ...prev]);

    alert(`นำเข้าประวัติงานซ่อมด่วนจากไฟล์ Excel สำเร็จจำนวน ${finalRepairs.length} รายการ!`);
    
    if (finalRepairs.length > 0) {
      const activeSummary = `📥 [นำเข้าประวัติซ่อมบำรุง]
📊 นำเข้าสำเร็จ: ${finalRepairs.length} รายการ
🛠️ ช่างนำเข้าข้อมูล: ${finalRepairs[0]?.technician || 'ระบบ'}
📅 วันที่ทำรายการ: ${new Date().toLocaleDateString('th-TH')}
⏰ อัพเดทเข้าระบบเรียบร้อยแล้ว`;
      sendLineNotification(activeSummary).catch(console.error);
    }

    setExcelData([]);
    setExcelHeaders([]);
    setFileName('');
    setImportPreview([]);
    setShowImportModal(false);
  };

  const downloadImportTemplate = () => {
    const headers = [
      'รหัสเครื่องจักร *',
      'อาการเสียชำรุด *',
      'เวลารายงานเสีย (YYYY-MM-DD HH:MM) *',
      'เวลาซ่อมเสร็จ (YYYY-MM-DD HH:MM)',
      'มาตรการแก้ไขและป้องกันเชิงรับถาวร',
      'ช่างผู้รับผิดชอบหลัก *',
      'ทำไมชั้นที่ 1 (Why 1)',
      'ทำไมชั้นที่ 2 (Why 2)',
      'ทำไมชั้นที่ 3 (Why 3)',
      'ทำไมชั้นที่ 4 (Why 4)',
      'ทำไมชั้นที่ 5 (Why 5)',
      'ค่าใช้จ่ายอื่นๆ (บาท)',
      'สถานะ (กำลังซ่อม/ปิดงาน)'
    ];
    const sampleData = [
      [
        'RIM01',
        'มีกลิ่นไหม้และควันออกจากตู้คุมมอเตอร์',
        '2026-06-10 09:00',
        '2026-06-10 11:30',
        'ทำความสะอาดหน้าสัมผัสคอนแทคเตอร์และปรับปรุงระบบระบายอากาศ',
        'ช่างอุ้ย',
        'คอนแทคเตอร์ทำงานเกินพิกัด',
        'กระแสไฟฟ้าเกินเนื่องจากมอเตอร์ติดขัด',
        'ตลับลูกปืนมอเตอร์ชำรุด',
        'ขาดการอัดจารบีตามระยะเวลาบำรุงรักษา',
        'ไม่มีระบบแจ้งเตือนรอบการอัดจารบีบำรุงรักษาเชิงป้องกัน',
        '0',
        'ปิดงาน'
      ],
      [
        'FFS01',
        'กระบอกลมซีลไม่ทำงาน',
        '2026-06-12 14:15',
        '',
        '',
        'ช่างโอเว่น',
        'ลมรั่วที่โซลินอยด์วาล์ว',
        'ซีลยางด้านในเสื่อมสภาพ',
        'ใช้งานเกินอายุงานสัญญา',
        '',
        '',
        '500',
        'กำลังซ่อม'
      ]
    ];
    const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "RepairTemplate");
    XLSX.writeFile(wb, "maintenance_repair_import_template.xlsx");
  };

  // Summary counts and MTTR metrics for loss categories
  const totalCount = repairs.length;
  const totalDuration = repairs.reduce((sum, r) => sum + (r.duration || 0), 0);

  const breakdownLogs = repairs.filter(r => getRepairStoppageType(r) === 'BREAKDOWN');
  const breakdownCount = breakdownLogs.length;
  const breakdownDuration = breakdownLogs.reduce((sum, r) => sum + (r.duration || 0), 0);

  const minorLogs = repairs.filter(r => getRepairStoppageType(r) === 'MINOR_STOPPAGE');
  const minorCount = minorLogs.length;
  const minorDuration = minorLogs.reduce((sum, r) => sum + (r.duration || 0), 0);

  const adjustmentLogs = repairs.filter(r => getRepairStoppageType(r) === 'ADJUSTMENT_LOSS');
  const adjustmentCount = adjustmentLogs.length;
  const adjustmentDuration = adjustmentLogs.reduce((sum, r) => sum + (r.duration || 0), 0);

  // Filter & Sort core logs
  const filteredRepairs = repairs
    .filter(r => {
      if (repairNavigationFilter?.targetRepairIds) {
        if (repairNavigationFilter.targetRepairIds.length === 0) return false;
        return repairNavigationFilter.targetRepairIds.includes(r.id);
      }
      const matchMachine = machineFilter ? r.machineId.toLowerCase().includes(machineFilter.toLowerCase()) : true;
      const matchTech = techFilter 
        ? (r.technicians ? r.technicians.includes(techFilter) : r.technician === techFilter) 
        : true;
      const matchMonth = monthFilter ? r.date.startsWith(monthFilter) : true;
      const matchMttr = mttrFilter ? r.duration > mttrFilter : true;
      const matchStoppage = stoppageFilter === 'ALL'
        ? true
        : getRepairStoppageType(r) === stoppageFilter;
      return matchMachine && matchTech && matchMonth && matchMttr && matchStoppage;
    })
    .sort((a, b) => {
      if (sortBy === 'date') {
        const timeA = new Date(a.breakdownTime || a.date).getTime();
        const timeB = new Date(b.breakdownTime || b.date).getTime();
        return timeB - timeA; // Newest first
      } else {
        return b.duration - a.duration; // MTTR Descending
      }
    }); // Default sorted by Date Desc (ล่าสุดก่อน) or MTTR Desc

  // Multi-selection handlers for bulk deletion (ฟังก์ชันลบประวัติซ่อมแบบเลือกทั้งหมด)
  const handleSelectAllFiltered = () => {
    if (filteredRepairs.length === 0) return;
    const allFilteredSelected = filteredRepairs.every((r) => selectedIds.has(r.id));
    const next = new Set(selectedIds);
    if (allFilteredSelected) {
      filteredRepairs.forEach((r) => next.delete(r.id));
    } else {
      filteredRepairs.forEach((r) => next.add(r.id));
    }
    setSelectedIds(next);
  };

  const handleSelectAllTotal = () => {
    if (repairs.length === 0) return;
    const allTotalSelected = repairs.length > 0 && selectedIds.size === repairs.length;
    if (allTotalSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(repairs.map(r => r.id)));
    }
  };

  const handleClearSelection = () => {
    setSelectedIds(new Set());
  };

  const handleToggleRowSelection = (id: string, e?: React.MouseEvent | React.ChangeEvent) => {
    if (e) e.stopPropagation();
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const handleConfirmBulkDelete = () => {
    if (selectedIds.size === 0) return;
    const count = selectedIds.size;
    const targetLogs = repairs.filter(r => selectedIds.has(r.id));

    // Return spare parts if used in any of the deleted repairs
    let tempSpareParts = [...spareParts];
    let partsRestored = 0;
    for (const log of targetLogs) {
      if (log.usedParts && log.usedParts.length > 0) {
        for (const op of log.usedParts) {
          tempSpareParts = tempSpareParts.map(sp => {
            if (sp.id === op.partId) {
              partsRestored += op.quantity;
              return { ...sp, quantity: sp.quantity + op.quantity };
            }
            return sp;
          });
        }
      }
    }
    if (partsRestored > 0) {
      setSpareParts(tempSpareParts);
    }

    // Clean up linked Work Orders if requested
    if (deleteLinkedWorkOrder) {
      const linkedWoIds = new Set<string>();
      targetLogs.forEach(r => {
        if (r.workOrderId) linkedWoIds.add(r.workOrderId);
        if (r.workOrderNo) linkedWoIds.add(r.workOrderNo);
      });
      setWorkOrders(prev => prev.filter(w => {
        if (w.sourceRefId && selectedIds.has(w.sourceRefId)) return false;
        if (linkedWoIds.has(w.id) || (w.workOrderNo && linkedWoIds.has(w.workOrderNo))) return false;
        return true;
      }));
    }

    // Remove selected repair records
    setRepairs(prev => prev.filter(r => !selectedIds.has(r.id)));
    setSelectedIds(new Set());
    setIsBulkDeleteModalOpen(false);

    showToast(`🗑️ ลบประวัติงานซ่อมจำนวน ${count} รายการเรียบร้อยแล้ว${partsRestored > 0 ? ` (คืนอะไหล่เข้าคลัง ${partsRestored} ชิ้น)` : ''}${deleteLinkedWorkOrder ? ' (พร้อมลบใบงาน WO ที่เกี่ยวข้อง)' : ''}`);
  };

  return (
    <div className="space-y-6" id="repair-page-root">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 border border-orange-500/50 text-orange-200 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 size={18} className="text-orange-400 shrink-0" />
          <span className="text-sm font-medium">{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white ml-2 cursor-pointer">
            <X size={14} />
          </button>
        </div>
      )}
      
      {/* MTBF Dashboard Navigation Filter Banner */}
      {repairNavigationFilter && (
        <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-blue-950 border-2 border-cyan-500/60 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xl animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400 shrink-0">
              <Wrench className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-2 flex-wrap">
                <span>แสดงประวัติงานซ่อมที่เชื่อมโยงจาก:</span>
                <span className="text-cyan-300 font-mono bg-cyan-900/80 px-2.5 py-0.5 rounded-lg border border-cyan-500/50 shadow-sm">
                  {repairNavigationFilter.filterTitle || 'ตาราง Breakdown สะสม'}
                </span>
                <span className="text-emerald-400 text-xs font-semibold bg-emerald-950/80 border border-emerald-500/40 px-2 py-0.5 rounded-md">
                  {filteredRepairs.length} รายการ
                </span>
              </div>
              {repairNavigationFilter.isBaseline ? (
                <p className="text-[11px] text-amber-300/90 mt-1 font-medium bg-amber-950/40 border border-amber-500/30 px-2 py-0.5 rounded inline-block">
                  📊 สถิติสะสม Baseline ย้อนหลังปี {repairNavigationFilter.baselineYear} (Breakdown รวม {repairNavigationFilter.baselineBDMin?.toLocaleString()} นาที / {repairNavigationFilter.baselineCount} ครั้ง) นำเข้าจากข้อมูลสรุปย้อนหลังของฝ่ายวิศวกรรม
                </p>
              ) : filteredRepairs.length === 0 ? (
                <p className="text-[11px] text-emerald-300/90 mt-1 font-medium">
                  ✅ ช่วงเวลานี้ไม่มีเวลาเครื่องหยุด Breakdown (เครื่องจักรทำงานสมบูรณ์)
                </p>
              ) : (
                <p className="text-[11px] text-slate-300 mt-0.5">
                  กรองเฉพาะงาน Breakdown ตามช่วงเวลาและห้อง/เครื่องจักรที่เลือกไว้
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            <button
              type="button"
              onClick={() => setActivePage(repairNavigationFilter.sourcePage || 16)}
              className="px-3.5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition cursor-pointer"
            >
              <span>← กลับแดชบอร์ด Breakdown สะสม</span>
            </button>
            <button
              type="button"
              onClick={clearRepairNavigationFilter}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold border border-slate-700 transition cursor-pointer"
              title="ยกเลิกตัวกรองและแสดงประวัติงานซ่อมทั้งหมด"
            >
              ✕ แสดงทั้งหมด
            </button>
          </div>
        </div>
      )}

      {/* Header action */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-cyan-400 tracking-tight flex items-center gap-2">
            🔧 บันทึกประวัติและวิเคราะห์งานซ่อมด่วน (Breakdown Logs)
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            ลงด่วนรายงานการทำงานซ่อมบำรุง วิเคราะห์หาปัจจัยรากเหง้า Why-Why อนุมัติบันทึกเข้าตารางปฏิบัติงาน
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 self-stretch sm:self-auto shrink-0">
          {/* Machine Breakdown Import from File */}
          {canEdit && (
            <button
              type="button"
              id="btn-import-breakdowns"
              onClick={() => setShowBreakdownImportModal(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 hover:from-orange-400 hover:via-amber-400 hover:to-yellow-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl transition-all shadow-lg focus:outline-none text-xs cursor-pointer shadow-orange-500/20"
              title="นำเข้าบันทึกประวัติเบรกดาวน์เครื่องจักร (Breakdown Logs) จากไฟล์ Excel, CSV, JSON หรือไฟล์ประวัติ"
            >
              <UploadCloud size={16} />
              นำเข้าเบรกดาวน์เครื่องจักร
            </button>
          )}

          {canDelete && repairs.length > 0 && (
            <button
              type="button"
              id="btn-quick-select-all-repairs"
              onClick={handleSelectAllFiltered}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-lg transition-all border text-xs font-bold shadow-md cursor-pointer select-none ${
                filteredRepairs.length > 0 && filteredRepairs.every((r) => selectedIds.has(r.id))
                  ? 'bg-rose-950/80 text-rose-300 border-rose-500/50 hover:bg-rose-900/80 ring-1 ring-rose-500/40'
                  : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border-slate-700 hover:border-slate-650'
              }`}
              title="คลิกเพื่อเลือกรายการประวัติงานซ่อมทั้งหมดในตารางสำหรับลบแบบกลุ่ม"
            >
              <CheckSquare size={16} className={filteredRepairs.length > 0 && filteredRepairs.every((r) => selectedIds.has(r.id)) ? 'text-rose-400' : 'text-cyan-400'} />
              <span>
                {filteredRepairs.length > 0 && filteredRepairs.every((r) => selectedIds.has(r.id))
                  ? 'ยกเลิกเลือกทั้งหมด'
                  : `เลือกทั้งหมดเพื่อลบ (${filteredRepairs.length})`}
              </span>
            </button>
          )}

          {canEdit ? (
            <button
              id="btn-add-repair"
              onClick={() => {
                setEditingId(null);
                setPartSearchQuery('');
                setFormMachine(machines[0]?.id || '');
                setFormBreakdown(`${getTodayDateString()}T09:00`);
                setFormDone(`${getTodayDateString()}T11:30`);
                setFormSymptoms('');
                setFormTechnician(technicians[0] || 'ช่างอุ้ย');
                setFormTechnicians([technicians[0] || 'ช่างอุ้ย']);
                setFormCorrection('');
                setWhy1(''); setWhy2(''); setWhy3(''); setWhy4(''); setWhy5('');
                setWhyCount(1);
                setPhotoBase64('');
                setFormStoppageType('BREAKDOWN');
                setFormHasPartsReplaced(false);
                setIsStoppageManual(false);
                setShowFormModal(true);
              }}
              className="flex items-center gap-2 bg-gradient-to-r from-rose-500 to-red-650 hover:from-rose-400 hover:to-red-500 text-white font-bold px-4 py-2.5 rounded-lg transition-all shadow-md focus:outline-none text-xs cursor-pointer"
            >
              <Plus size={18} />
              บันทึกแจ้งซ่อมด่วน
            </button>
          ) : (
            <div className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-400 text-xs flex items-center gap-1.5 border border-slate-700">
              <span>🔒 สิทธิ์ดูอย่างเดียว (Viewer)</span>
            </div>
          )}
        </div>
      </div>

      {/* LOSS CLASSIFICATION SUMMARY CARDS & QUICK SELECTOR */}
      <div className="space-y-2.5" id="stoppage-classification-dashboard">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-1.5">
              <Tag size={15} className="text-cyan-400" />
              การจำแนกข้อมูลงานซ่อมตามนิยามความสูญเสีย (Failure & Loss Classification)
            </span>
            <span className="text-[11px] text-slate-400 hidden lg:inline">
              • คลิกการ์ดหมวดหมู่เพื่อกรองดูข้อมูลที่แยกประเภทได้ทันที
            </span>
          </div>
          {stoppageFilter !== 'ALL' && (
            <button
              type="button"
              onClick={() => setStoppageFilter('ALL')}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1.5 self-start sm:self-auto bg-slate-800 hover:bg-slate-750 px-2.5 py-1 rounded-lg border border-slate-700 transition"
            >
              ✕ ล้างตัวกรองหมวดหมู่ (แสดงทั้งหมด {totalCount} ครั้ง)
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Card 1: ALL */}
          <button
            type="button"
            id="filter-card-all"
            onClick={() => setStoppageFilter('ALL')}
            className={`text-left p-4 rounded-xl border transition-all relative overflow-hidden flex flex-col justify-between ${
              stoppageFilter === 'ALL'
                ? 'bg-slate-800 border-cyan-500 ring-2 ring-cyan-500/25 shadow-lg shadow-cyan-950/40'
                : 'bg-slate-850/80 border-slate-750 hover:bg-slate-800 hover:border-slate-650'
            }`}
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-bold text-slate-200">ทั้งหมด (All Records)</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  stoppageFilter === 'ALL' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-slate-750 text-slate-400'
                }`}>
                  {stoppageFilter === 'ALL' ? '✓ กำลังดูอยู่' : 'รวมทุกประเภท'}
                </span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black font-mono text-slate-100">{totalCount}</span>
                <span className="text-xs text-slate-400">ครั้ง</span>
                <span className="text-xs text-slate-600">|</span>
                <span className="text-xs font-mono font-bold text-cyan-400">{totalDuration.toLocaleString()} นาที</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 mt-3 border-t border-slate-750/70 pt-2 line-clamp-2">
              รวมข้อมูลประวัติงานซ่อมบำรุงและเครื่องเสียทุกกรณีในโรงงาน
            </p>
          </button>

          {/* Card 2: BREAKDOWN */}
          <button
            type="button"
            id="filter-card-breakdown"
            onClick={() => setStoppageFilter('BREAKDOWN')}
            className={`text-left p-4 rounded-xl border transition-all relative overflow-hidden flex flex-col justify-between ${
              stoppageFilter === 'BREAKDOWN'
                ? 'bg-rose-950/30 border-rose-500 ring-2 ring-rose-500/30 shadow-lg shadow-rose-950/40'
                : 'bg-slate-850/80 border-slate-750 hover:bg-slate-800 hover:border-rose-500/50'
            }`}
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50"></span>
                  <span className="text-xs font-bold text-rose-300">Breakdown</span>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  stoppageFilter === 'BREAKDOWN' ? 'bg-rose-500/25 text-rose-200 border border-rose-500/40' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                }`}>
                  {stoppageFilter === 'BREAKDOWN' ? '✓ กำลังเลือกดู' : 'เครื่องเสีย'}
                </span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black font-mono text-rose-300">{breakdownCount}</span>
                <span className="text-xs text-rose-400">ครั้ง</span>
                <span className="text-xs text-slate-600">|</span>
                <span className="text-xs font-mono font-bold text-rose-400">{breakdownDuration.toLocaleString()} นาที</span>
              </div>
            </div>
            <p className="text-[10.5px] text-slate-300 mt-2.5 leading-relaxed bg-slate-900/70 p-2 rounded-lg border border-slate-750/80">
              <strong>นิยาม:</strong> เครื่องเสียที่ไม่ทราบล่วงหน้า มีการเปลี่ยนอะไหล่ หน่วยเป็นครั้ง แต่เก็บเวลาด้วย
            </p>
          </button>

          {/* Card 3: MINOR STOPPAGE */}
          <button
            type="button"
            id="filter-card-minor"
            onClick={() => setStoppageFilter('MINOR_STOPPAGE')}
            className={`text-left p-4 rounded-xl border transition-all relative overflow-hidden flex flex-col justify-between ${
              stoppageFilter === 'MINOR_STOPPAGE'
                ? 'bg-amber-950/30 border-amber-500 ring-2 ring-amber-500/30 shadow-lg shadow-amber-950/40'
                : 'bg-slate-850/80 border-slate-750 hover:bg-slate-800 hover:border-amber-500/50'
            }`}
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-sm shadow-amber-400/50"></span>
                  <span className="text-xs font-bold text-amber-300">Minor stoppage</span>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  stoppageFilter === 'MINOR_STOPPAGE' ? 'bg-amber-500/25 text-amber-200 border border-amber-500/40' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                }`}>
                  {stoppageFilter === 'MINOR_STOPPAGE' ? '✓ กำลังเลือกดู' : '&lt; 15 นาที'}
                </span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black font-mono text-amber-300">{minorCount}</span>
                <span className="text-xs text-amber-400">ครั้ง</span>
                <span className="text-xs text-slate-600">|</span>
                <span className="text-xs font-mono font-bold text-amber-400">{minorDuration.toLocaleString()} นาที</span>
              </div>
            </div>
            <p className="text-[10.5px] text-slate-300 mt-2.5 leading-relaxed bg-slate-900/70 p-2 rounded-lg border border-slate-750/80">
              <strong>นิยาม:</strong> เครื่องเสียที่ไม่ทราบล่วงหน้า ไม่มีการเปลี่ยนอะไหล่ น้อยกว่า 15 นาที หน่วยเป็นครั้ง
            </p>
          </button>

          {/* Card 4: ADJUSTMENT LOSS */}
          <button
            type="button"
            id="filter-card-adjustment"
            onClick={() => setStoppageFilter('ADJUSTMENT_LOSS')}
            className={`text-left p-4 rounded-xl border transition-all relative overflow-hidden flex flex-col justify-between ${
              stoppageFilter === 'ADJUSTMENT_LOSS'
                ? 'bg-orange-950/30 border-orange-500 ring-2 ring-orange-500/30 shadow-lg shadow-orange-950/40'
                : 'bg-slate-850/80 border-slate-750 hover:bg-slate-800 hover:border-orange-500/50'
            }`}
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-orange-400 shadow-sm shadow-orange-400/50"></span>
                  <span className="text-xs font-bold text-orange-300">Adjustment loss</span>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  stoppageFilter === 'ADJUSTMENT_LOSS' ? 'bg-orange-500/25 text-orange-200 border border-orange-500/40' : 'bg-orange-500/10 text-orange-400 border border-orange-500/20'
                }`}>
                  {stoppageFilter === 'ADJUSTMENT_LOSS' ? '✓ กำลังเลือกดู' : '&gt; 15 นาที'}
                </span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black font-mono text-orange-300">{adjustmentCount}</span>
                <span className="text-xs text-orange-400">ครั้ง</span>
                <span className="text-xs text-slate-600">|</span>
                <span className="text-xs font-mono font-bold text-orange-400">{adjustmentDuration.toLocaleString()} นาที</span>
              </div>
            </div>
            <p className="text-[10.5px] text-slate-300 mt-2.5 leading-relaxed bg-slate-900/70 p-2 rounded-lg border border-slate-750/80">
              <strong>นิยาม:</strong> เครื่องเสียที่ไม่ทราบล่วงหน้า ไม่มีการเปลี่ยนอะไหล่ มากกว่า 15 นาที หน่วยเป็นครั้ง
            </p>
          </button>
        </div>
      </div>

      {/* SEARCH FILTERS BLOCK */}
      <div id="repair-filter-container" className="bg-slate-800 border border-slate-700/80 rounded-xl p-5 space-y-4">
        <h3 className="text-xs font-bold uppercase text-slate-400 flex items-center gap-1.5 mb-2">
          <SlidersHorizontal size={14} className="text-cyan-400" />
          ตัวกรองตรวจสอบประวัติละเอียด
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-400">ค้นหารหัสเครื่องจักร</label>
            <input
              id="filter-rep-machine"
              type="text"
              placeholder="เช่น RIM01, FFS..."
              value={machineFilter}
              onChange={(e) => setMachineFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-400">ประเภทความสูญเสีย</label>
            <select
              id="filter-rep-stoppage"
              value={stoppageFilter}
              onChange={(e) => setStoppageFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-sans"
            >
              <option value="ALL">-- ทุกประเภทความสูญเสีย --</option>
              <option value="BREAKDOWN">🔴 Breakdown (มีเปลี่ยนอะไหล่)</option>
              <option value="MINOR_STOPPAGE">🟡 Minor stoppage (&lt; 15 นาที)</option>
              <option value="ADJUSTMENT_LOSS">🟠 Adjustment loss (&gt; 15 นาที)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-400">ช่างผู้รับผิดชอบ</label>
            <select
              id="filter-rep-tech"
              value={techFilter}
              onChange={(e) => setTechFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-[#dee2e6] focus:outline-none focus:border-cyan-500"
            >
              <option value="">-- ทั้งหมด --</option>
              {technicians.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-400">ประจำเดือนปี</label>
            <input
              id="filter-rep-month"
              type="month"
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-400">MTTR นานกว่า (นาที)</label>
            <select
              id="filter-rep-mttr"
              value={mttrFilter}
              onChange={(e) => setMttrFilter(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value={0}>-- ตารางทั้งหมด --</option>
              <option value={30}>&gt; 30 นาที</option>
              <option value={60}>&gt; 60 นาที (1 ชม.)</option>
              <option value={120}>&gt; 120 นาที (2 ชม.)</option>
              <option value={240}>&gt; 240 นาที (4 ชม.)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-cyan-400">เรียงตาม (Sort by)</label>
            <select
              id="filter-rep-sort"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'date' | 'duration')}
              className="w-full bg-slate-900 border border-slate-750/90 rounded-lg px-3 py-1.5 text-xs text-cyan-300 font-bold focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="date">📅 วันที่เสียล่าสุดก่อน</option>
              <option value="duration">⏱ เวลากระทบเสียนานสุด (MTTR)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Informational double-click guide */}
      <div className="bg-cyan-950/40 border border-cyan-800/30 rounded-xl p-3.5 flex items-center justify-between text-xs text-cyan-300">
        <div className="flex items-center gap-2.5">
          <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-pulse"></span>
          <span>💡 <strong>คำแนะนำการใช้งาน:</strong> สามารถ <strong>ดับเบิ้ลคลิก (Double-click)</strong> แถวรายการซ่อมบำรุงในตารางด้านล่าง เพื่อเรียกดูหน้าต่างรายละเอียดเชิงลึก วิเคราะห์ Why-Why พร้อมรูปถ่าย หรือเลือก ลบ/แก้ไขข้อมูล ได้ทันที</span>
        </div>
      </div>

      {/* Orphaned Deleted WO Notification & 1-Click Action Bar */}
      {orphanedDeletedRepairs.length > 0 && (
        <div 
          id="banner-orphaned-wo-cleanup"
          className="bg-amber-950/50 border border-amber-500/50 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-amber-200 shadow-lg shadow-amber-950/40 animate-in fade-in"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-white text-sm flex items-center gap-2">
                <span>ตรวจพบงานซ่อมที่ใบสั่งงาน WO โดนลบไปแล้ว</span>
                <span className="px-2 py-0.5 rounded-full bg-rose-950 text-rose-300 text-xs font-mono font-bold border border-rose-800/50">
                  {orphanedDeletedRepairs.length} รายการ
                </span>
              </div>
              <p className="text-[11px] text-amber-300/80 mt-0.5 leading-relaxed">
                เนื่องจากใบสั่งงานถูกลบออกจากระบบ CMMS ตารางจะแสดงสถานะ <span className="text-rose-300 font-mono">(WO เดิมถูกลบ)</span> ท่านสามารถกดล้างการเชื่อมโยงเดิม หรือออก Fast-Track Emergency WO ใหม่ทันที
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0 self-end md:self-auto">
            <button
              type="button"
              id="btn-clean-all-orphaned-wos"
              onClick={handleBatchCleanOrphanedWOs}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-600 text-xs font-semibold cursor-pointer transition active:scale-95 shadow-sm"
              title="ล้างเลข WO เดิมที่ถูกลบไปแล้วทั้งหมด ให้กลับเป็นปุ่ม + ออก WO ทั่วไป"
            >
              🧹 ล้างการเชื่อมโยง ({orphanedDeletedRepairs.length})
            </button>
            <button
              type="button"
              id="btn-recreate-all-orphaned-wos"
              onClick={handleBatchRecreateOrphanedWOs}
              className="px-4 py-1.5 bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 text-slate-950 font-black rounded-xl text-xs cursor-pointer shadow-md shadow-rose-950/50 transition active:scale-95"
              title="ออก Fast-Track Emergency Work Order ใหม่สำหรับทุกงานซ่อมที่ WO เดิมโดนลบ"
            >
              ⚡ ออก WO ใหม่ทั้งหมด ({orphanedDeletedRepairs.length})
            </button>
          </div>
        </div>
      )}

      {/* BULK ACTION TOOLBAR (เมื่อเลือกรายการประวัติซ่อมอย่างน้อย 1 รายการ) */}
      {selectedIds.size > 0 && (
        <div 
          id="repair-bulk-action-bar"
          className="bg-gradient-to-r from-slate-900 via-rose-950/70 to-slate-900 text-white p-3.5 sm:p-4 rounded-2xl shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-3 border border-rose-500/40 animate-in fade-in slide-in-from-top-2"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-400/30 flex items-center justify-center text-rose-300 shrink-0">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                <span>เลือกประวัติงานซ่อมอยู่: <strong className="text-amber-300 font-mono text-sm sm:text-base">{selectedIds.size}</strong> รายการ</span>
                <span className="text-slate-400 text-xs font-normal">
                  (จากในตาราง {filteredRepairs.length} งาน / ทั้งหมด {repairs.length} งาน)
                </span>
              </div>
              <div className="text-[11px] text-slate-300">
                สามารถกดเลือกทั้งหมดในตาราง, เลือกทั้งหมดในระบบ หรือลบประวัติซ่อมที่เลือกพร้อมกันได้ทันที
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              id="btn-bulk-toggle-select-filtered"
              onClick={handleSelectAllFiltered}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition border border-slate-700 cursor-pointer flex items-center gap-1.5"
            >
              <CheckSquare size={13} className="text-cyan-400" />
              <span>
                {filteredRepairs.length > 0 && filteredRepairs.every((r) => selectedIds.has(r.id))
                  ? 'ยกเลิกเลือกในตาราง'
                  : `เลือกทั้งหมดในตาราง (${filteredRepairs.length})`}
              </span>
            </button>

            {repairs.length > filteredRepairs.length && (
              <button
                type="button"
                id="btn-bulk-select-all-global"
                onClick={handleSelectAllTotal}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold rounded-xl transition border border-amber-600/30 cursor-pointer flex items-center gap-1.5"
                title="เลือกประวัติงานซ่อมทั้งหมดในระบบโดยไม่สนตัวกรอง"
              >
                <span>เลือกทั้งหมดในระบบ ({repairs.length})</span>
              </button>
            )}

            <button
              type="button"
              id="btn-bulk-clear-selection"
              onClick={handleClearSelection}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition border border-slate-700 cursor-pointer"
            >
              ล้างการเลือก
            </button>

            <div className="h-5 w-px bg-slate-700 mx-1 hidden sm:block" />

            {canDelete ? (
              <button
                type="button"
                id="btn-bulk-delete-repairs"
                onClick={() => setIsBulkDeleteModalOpen(true)}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-lg shadow-rose-600/30 cursor-pointer"
                title="ลบรายการประวัติซ่อมที่เลือกทั้งหมด"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>ลบประวัติซ่อมที่เลือก ({selectedIds.size})</span>
              </button>
            ) : (
              <div 
                className="px-3.5 py-1.5 bg-slate-800/80 text-slate-400 text-xs rounded-xl border border-slate-700 flex items-center gap-1.5"
                title="เฉพาะสิทธิ์ Admin เท่านั้นที่สามารถลบได้"
              >
                <span>🔒 สิทธิ์ Admin เท่านั้นที่ลบได้</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* REPAIR HISTORICAL LOGS TABLE */}
      <div id="repair-table-container" className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs" id="repairs-history-table">
            <thead>
              <tr className="bg-slate-800/90 border-b border-slate-700 text-slate-300 font-medium tracking-wide uppercase py-4">
                <th className="py-4 px-3 w-12 text-center">
                  <div className="flex items-center justify-center">
                    <input
                      type="checkbox"
                      id="th-select-all-repairs"
                      checked={filteredRepairs.length > 0 && filteredRepairs.every((r) => selectedIds.has(r.id))}
                      onChange={handleSelectAllFiltered}
                      className="w-4 h-4 rounded border-slate-600 bg-slate-900 text-rose-500 focus:ring-rose-500 focus:ring-offset-slate-900 cursor-pointer accent-rose-500"
                      title={filteredRepairs.length > 0 && filteredRepairs.every((r) => selectedIds.has(r.id)) ? 'ยกเลิกการเลือกทั้งหมด' : 'เลือกทั้งหมดในตาราง'}
                    />
                  </div>
                </th>
                <th className="py-4 px-4 w-28">วันที่เสีย</th>
                <th className="py-4 px-3 w-28 font-mono">เครื่อง (ID)</th>
                <th className="py-4 px-4">ชื่อเครื่องจักร</th>
                <th className="py-4 px-3 text-center w-36">ประเภทความสูญเสีย</th>
                <th className="py-4 px-3 text-center w-28">ใบสั่งงาน (WO)</th>
                <th className="py-4 px-3 text-center">MTTR (นาที)</th>
                <th className="py-4 px-3 text-center">Std. MTTR</th>
                <th className="py-4 px-4">อาการเสียชำรุด</th>
                <th className="py-4 px-4">Why 1 (วิเคราะห์แรกพบ)</th>
                <th className="py-4 px-3 text-right">ค่าซ่อมทั้งหมด</th>
                <th className="py-4 px-3 text-center">ช่างซ่อม</th>
                <th className="py-4 px-3 text-center w-24 font-semibold text-slate-350">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {filteredRepairs.length === 0 ? (
                <tr>
                  <td colSpan={13} className="py-12 text-center text-slate-500 bg-slate-900/10">
                    ไม่พบข้อมูลแจ้งซ่อมสำหรับตัวกรองที่เลือก
                  </td>
                </tr>
              ) : (
                filteredRepairs.map((r) => {
                  const std = getStandardMttr(r.machineId);
                  const mach = machines.find(m => m.id === r.machineId);
                  const isExceed120Percent = r.duration > std * 1.2;
                  const isRedRow = r.duration > 120; // Row highlight red if MTTR > 120 นาที
                  const isSelected = selectedIds.has(r.id);

                  return (
                    <tr 
                      key={r.id}
                      id={`repair-row-${r.id}`}
                      className={`hover:bg-slate-750/90 transition-colors cursor-pointer select-none ${
                        isSelected 
                          ? 'bg-rose-950/30 border-l-4 border-l-rose-500' 
                          : isRedRow 
                          ? 'bg-red-500/10 border-l-4 border-l-red-500' 
                          : ''
                      }`}
                      onDoubleClick={() => setSelectedRepairDetail(r)}
                      title="ดับเบิ้ลคลิก (Double-click) เพื่อดูรายละเอียด Why-Why เชิงลึก"
                    >
                      <td className="py-4 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-center">
                          <input
                            type="checkbox"
                            id={`checkbox-rep-${r.id}`}
                            checked={isSelected}
                            onChange={(e) => handleToggleRowSelection(r.id, e)}
                            className="w-4 h-4 rounded border-slate-600 bg-slate-900 text-rose-500 focus:ring-rose-500 focus:ring-offset-slate-900 cursor-pointer accent-rose-500"
                            title={`เลือกรายการซ่อม ${r.machineId}`}
                          />
                        </div>
                      </td>
                      <td className="py-4 px-4 text-slate-400 font-mono">
                        <div className="flex flex-col gap-1">
                          <span>{r.date}</span>
                          {r.status === 'กำลังซ่อม' ? (
                            <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1 py-0.5 rounded text-[9px] font-bold text-center animate-pulse">
                              กำลังซ่อม
                            </span>
                          ) : (
                            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1 py-0.5 rounded text-[9px] font-bold text-center">
                              ปิดสำเร็จ
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-3 font-mono font-bold text-red-400">
                        {r.machineId}
                      </td>
                      <td className="py-4 px-4 font-medium text-slate-200">
                        {mach?.name || 'เครื่องจักรทั่วไป'}
                      </td>
                      <td className="py-4 px-3 text-center">
                        {(() => {
                          const sType = getRepairStoppageType(r);
                          const hasParts = (r.usedParts && r.usedParts.length > 0) || r.hasPartsReplaced;
                          if (sType === 'BREAKDOWN') {
                            return (
                              <div className="flex flex-col items-center gap-0.5">
                                <span className="inline-flex items-center gap-1 bg-rose-500/15 text-rose-300 border border-rose-500/30 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-xs">
                                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                                  Breakdown
                                </span>
                                <span className="text-[9.5px] text-slate-400 font-mono">
                                  1 ครั้ง {hasParts ? '• เปลี่ยนอะไหล่' : ''}
                                </span>
                              </div>
                            );
                          } else if (sType === 'MINOR_STOPPAGE') {
                            return (
                              <div className="flex flex-col items-center gap-0.5">
                                <span className="inline-flex items-center gap-1 bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-xs">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                                  Minor stoppage
                                </span>
                                <span className="text-[9.5px] text-slate-400 font-mono">
                                  1 ครั้ง • ไม่เปลี่ยนอะไหล่ (&lt;15น.)
                                </span>
                              </div>
                            );
                          } else {
                            return (
                              <div className="flex flex-col items-center gap-0.5">
                                <span className="inline-flex items-center gap-1 bg-orange-500/15 text-orange-300 border border-orange-500/30 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-xs">
                                  <span className="w-1.5 h-1.5 rounded-full bg-orange-400"></span>
                                  Adjustment loss
                                </span>
                                <span className="text-[9.5px] text-slate-400 font-mono">
                                  1 ครั้ง • ไม่เปลี่ยนอะไหล่ (&gt;15น.)
                                </span>
                              </div>
                            );
                          }
                        })()}
                      </td>

                      {/* Work Order Column (No Work Order - No Work) */}
                      <td className="py-4 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        {(() => {
                          const activeWO = workOrders.find(w => 
                            w.id === r.workOrderId || 
                            w.id === r.workOrderNo || 
                            (w.workOrderNo && (w.workOrderNo === r.workOrderNo || w.workOrderNo === r.workOrderId))
                          );

                          if (activeWO) {
                            return (
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedDetailWO(activeWO);
                                  setIsDetailWOModalOpen(true);
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-900 transition shadow-xs cursor-pointer"
                                title={`คลิกดูใบสั่งงาน Work Order #${activeWO.workOrderNo || activeWO.id} (${activeWO.status})`}
                              >
                                <span>🎯 {activeWO.workOrderNo || activeWO.id}</span>
                              </button>
                            );
                          }

                          // If the repair references a workOrder that was DELETED from system
                          const hadDeletedWO = Boolean(r.workOrderNo || r.workOrderId);
                          const deletedId = r.workOrderNo || r.workOrderId;

                          return (
                            <div className="inline-flex flex-col items-center justify-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  const created = createEmergencyBreakdownWorkOrder({
                                    machineId: r.machineId,
                                    title: `ซ่อมฉุกเฉิน ${r.machineId}: ${r.symptoms.slice(0, 35)}`,
                                    symptoms: r.symptoms,
                                    leadTech: r.technician || (r.technicians && r.technicians[0]) || 'ช่างประจำกะ',
                                    targetDurationMins: r.duration || 60
                                  });
                                  setRepairs(prev => prev.map(rep => rep.id === r.id ? { ...rep, workOrderId: created.id, workOrderNo: created.id } : rep));
                                  showToast(`⚡ ออกใบสั่งงานฉุกเฉินใหม่ ${created.id} สำหรับเครื่อง [${r.machineId}] เรียบร้อยแล้ว`);
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[9.5px] font-bold bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-600/40 transition cursor-pointer shadow-xs active:scale-95"
                                title={hadDeletedWO ? `ใบงานเดิม (${deletedId}) โดนลบไปแล้ว คลิกเพื่อออก Fast-Track Emergency WO ใหม่ทันที` : "กดเพื่อออก Fast-Track Emergency WO ทันทีให้ถูกต้องตามวินัย CMMS"}
                              >
                                <span>+ ออก WO</span>
                              </button>
                              {hadDeletedWO && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setRepairs(prev => prev.map(rep => rep.id === r.id ? { ...rep, workOrderId: undefined, workOrderNo: undefined } : rep));
                                    showToast(`🧹 ล้างการเชื่อมโยงใบสั่งงานที่โดนลบ (${deletedId}) เรียบร้อยแล้ว`);
                                  }}
                                  className="text-[9px] font-mono text-rose-400 hover:text-rose-300 hover:underline flex items-center gap-1 cursor-pointer transition"
                                  title={`ใบสั่งงาน ${deletedId} ถูกลบออกจากระบบแล้ว คลิกเพื่อล้างเลขเดิม`}
                                >
                                  <span className="line-through">{deletedId}</span>
                                  <span className="text-[8px] bg-rose-950/80 px-1 py-0.2 rounded border border-rose-800/40 text-rose-300 font-sans">ลบแล้ว</span>
                                </button>
                              )}
                            </div>
                          );
                        })()}
                      </td>
                      <td className="py-4 px-3 text-center font-mono font-bold">
                        <span className={isExceed120Percent ? "text-rose-400 font-extrabold" : "text-slate-300"}>
                          {r.duration} นาที
                        </span>
                      </td>
                      <td className="py-4 px-3 text-center font-mono text-slate-450 text-[11px]">
                        {std} นาที
                      </td>
                      <td className="py-4 px-4 max-w-[160px]" title={r.symptoms}>
                        <div className="flex flex-col gap-1">
                          <span className="truncate">{r.symptoms}</span>
                          {r.excelFile && (
                            <span className="inline-flex items-center gap-1 text-[9px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded font-medium self-start font-sans">
                              <FileSpreadsheet size={11} />
                              แนบไฟล์ Excel
                            </span>
                          )}
                          {/* FA / OPL / Why-Why / Kaizen Badges with link to Kaizen */}
                          {(() => {
                            const atts = r.repairAttachments || [
                              ...(r.faFile ? [r.faFile] : []),
                              ...(r.oplFile ? [r.oplFile] : []),
                              ...(r.whyWhyFile ? [r.whyWhyFile] : []),
                              ...(r.kaizenFile ? [r.kaizenFile] : [])
                            ];
                            if (!atts || atts.length === 0) return null;
                            return (
                              <div className="flex flex-wrap gap-1 mt-0.5">
                                {atts.map((att) => (
                                  <button
                                    key={att.id}
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleNavigateToKaizenProject(att, r.machineId);
                                    }}
                                    className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[8.5px] font-bold font-mono transition cursor-pointer border ${
                                      att.category === 'FA'
                                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
                                        : att.category === 'OPL'
                                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                                        : att.category === 'WHY_WHY'
                                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                                        : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 hover:bg-indigo-500/30'
                                    }`}
                                    title={`คลิกเพื่อเปิดในหน้า Kaizen (${att.name})`}
                                  >
                                    <ExternalLink size={8} />
                                    <span>{att.category === 'WHY_WHY' ? 'Why-Why' : att.category}</span>
                                  </button>
                                ))}
                              </div>
                            );
                          })()}
                        </div>
                      </td>
                      <td className="py-4 px-4 max-w-[180px] text-slate-350 italic" title={r.why1}>
                        <div className="flex flex-col gap-1">
                          <span className="truncate">{r.why1 || "-"}</span>
                          {(r.whyWhyFile || r.repairAttachments?.some(a => a.category === 'WHY_WHY') || r.excelFile || (r.why1 && r.why1.trim().length > 0)) && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigateToKaizen({
                                  category: 'WHY_WHY',
                                  machineId: r.machineId,
                                  searchQuery: r.symptoms,
                                  sourceRepairId: r.id
                                });
                              }}
                              className="inline-flex items-center gap-1 text-[9px] text-amber-300 bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 rounded font-bold font-sans hover:bg-amber-500/25 transition cursor-pointer self-start"
                              title="คลิกเพื่อเปิดในหน้า Kaizen (Why-Why Analysis)"
                            >
                              <HelpCircle size={10} />
                              <span>ไฟล์ Why-Why → Kaizen</span>
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-3 text-right font-mono font-semibold text-cyan-400 whitespace-nowrap">
                        {((r.usedParts?.reduce((sum, item) => sum + item.totalCost, 0) || 0) + (r.otherCost || 0)).toLocaleString()} ฿
                      </td>
                      <td className="py-4 px-3 text-center">
                        <div className="flex flex-wrap gap-1 justify-center max-w-[140px] mx-auto">
                          {(r.technicians && r.technicians.length > 0 ? r.technicians : [r.technician]).map(tech => (
                            <span key={tech} className="bg-slate-900 text-slate-300 px-2 py-0.5 rounded border border-slate-750 text-[10.5px] whitespace-nowrap">
                              {tech}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-4 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Quick Attach FA / OPL / Kaizen Button */}
                          <button
                            type="button"
                            id={`btn-attach-rep-${r.id}`}
                            onClick={() => setRepairForQuickAttachment(r)}
                            className="text-slate-400 hover:text-indigo-400 p-1 rounded-md transition hover:bg-slate-900 relative"
                            title="📎 แนบ / จัดการไฟล์ FA, OPL, Kaizen และเชื่อมต่อไปยังแถบ Kaizen"
                          >
                            <Paperclip size={14} />
                            {(r.repairAttachments?.length || (r.faFile ? 1 : 0) + (r.oplFile ? 1 : 0) + (r.kaizenFile ? 1 : 0)) > 0 && (
                              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                            )}
                          </button>
                          {canEdit && (
                            <button
                              id={`btn-edit-rep-${r.id}`}
                              onClick={() => handleEditClick(r)}
                              className="text-slate-500 hover:text-cyan-400 p-1 rounded-md transition hover:bg-slate-900"
                              title="แก้ไขประวัติงานซ่อม"
                            >
                              <Edit size={14} />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              id={`btn-delete-rep-${r.id}`}
                              onClick={() => handleDeleteRepair(r.id)}
                              className="text-slate-500 hover:text-rose-400 p-1 rounded-md transition hover:bg-slate-900"
                              title="ลบประวัติงานซ่อม (เฉพาะ Admin)"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                          {!canEdit && !canDelete && (
                            <span className="text-[10px] text-slate-500 italic">ดูอย่างเดียว</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* [+ บันทึกงานซ่อม] FORM MODAL DIALOG */}
      {showFormModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div id="repair-form-modal" className="bg-slate-800 border border-slate-700 rounded-2xl max-w-xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-155">
            {/* Header info */}
            <div className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700/85 p-5 shrink-0 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-semibold text-rose-400 flex items-center gap-1.5">
                  {editingId ? "✏️ แก้ไขประวัติงานซ่อมด่วนและการวิเคราะห์หน้างาน" : "🚨 บันทึกซ่อมด่วนและการวิเคราะห์หน้างาน"}
                </h3>
                <p className="text-slate-450 text-[11px] mt-0.5">
                  {editingId ? "ปรับปรุงข้อมูลรายงานการทำงานซ่อมบำรุงและวิเคราะห์รากเหง้าแฝง" : "กรอกข้อมูลให้ประณีตเพื่อการคำนวณและวิเคราะห์ที่ถูกต้อง"}
                </p>
              </div>

              {/* Live MTTR badge */}
              <div className="bg-slate-950 border border-slate-700 px-3.5 py-1.5 rounded-lg text-right h-12 flex flex-col justify-center shrink-0">
                <span className="text-[8px] text-slate-400 uppercase tracking-widest font-bold">LIVE MTTR:</span>
                <span className="text-sm font-mono font-bold text-rose-450">{getLiveMttr()} นาที</span>
              </div>
            </div>

            {/* Scrollable Form Body */}
            <form onSubmit={handleSaveRepair} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
              
              {/* Row 1: Machine Select */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300">เลือกเครื่องจักร*</label>
                <select
                  id="frm-rep-machine"
                  required
                  value={formMachine}
                  onChange={(e) => setFormMachine(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                >
                  {machines.map(m => (
                    <option key={m.id} value={m.id}>{m.id} : {m.name}</option>
                  ))}
                </select>
              </div>

              {/* Row 1.1: CMMS Work Order Selection & Fast-Track Button */}
              <div className="bg-slate-900/90 border border-cyan-500/40 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded bg-cyan-500/20 text-cyan-400">
                      <Wrench size={13} />
                    </span>
                    <label className="text-[11px] font-bold text-cyan-300">
                      ใบสั่งงาน Work Order (ตามหลัก No Work Order - No Work)
                    </label>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (!formMachine) {
                        alert("กรุณาเลือกเครื่องจักรก่อน");
                        return;
                      }
                      const symp = formSymptoms.trim() || 'แจ้งซ่อมเครื่องจักรขัดข้องด่วน';
                      const created = createEmergencyBreakdownWorkOrder({
                        machineId: formMachine,
                        title: `ฉุกเฉิน ${formMachine}: ${symp.slice(0, 35)}`,
                        symptoms: symp,
                        leadTech: formTechnician || technicians[0] || 'ช่างประจำกะ',
                        targetDurationMins: getLiveMttr() || 60
                      });
                      setFormWorkOrderId(created.id);
                      setFormWorkOrderNo(created.id);
                      showToast(`⚡ ออกใบสั่งงานฉุกเฉิน ${created.id} และผูกกับงานซ่อมนี้แล้ว`);
                    }}
                    className="px-2.5 py-1 bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-slate-950 font-black rounded-lg text-[10px] flex items-center gap-1 cursor-pointer shadow-sm transition"
                    title="ออก Emergency Fast-Track WO ทันทีใน 10 วินาที"
                  >
                    <span>⚡ ออก Fast-Track WO ทันที</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={formWorkOrderId}
                    onChange={(e) => {
                      const selectedId = e.target.value;
                      setFormWorkOrderId(selectedId);
                      setFormWorkOrderNo(selectedId);
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    <option value="">-- เลือกใบสั่งงานที่เปิดไว้ (หรือกดปุ่มออก WO ทันทีด้านขวา) --</option>
                    {workOrders
                      .filter(w => !formMachine || w.machineId === formMachine)
                      .map(w => (
                        <option key={w.id} value={w.id}>
                          [{w.id}] {w.title} ({w.sourceType} - {w.status})
                        </option>
                      ))}
                  </select>
                </div>

                {formWorkOrderId ? (
                  (() => {
                    const exists = workOrders.some(w => w.id === formWorkOrderId || w.workOrderNo === formWorkOrderId);
                    if (exists) {
                      return (
                        <div className="flex items-center gap-2 text-[11px] text-emerald-400">
                          <CheckCircle2 size={13} />
                          <span>เชื่อมโยงใบสั่งงาน <strong>{formWorkOrderId}</strong> สำเร็จ (ผ่านเกณฑ์ No WO - No Work)</span>
                        </div>
                      );
                    }
                    return (
                      <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-rose-950/40 border border-rose-500/30 text-[11px] text-rose-300">
                        <div className="flex items-center gap-1.5">
                          <AlertTriangle size={13} className="text-rose-400 shrink-0" />
                          <span>ใบสั่งงาน <strong>{formWorkOrderId}</strong> ถูกลบออกจากระบบแล้ว</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setFormWorkOrderId('');
                            setFormWorkOrderNo('');
                          }}
                          className="px-2 py-0.5 rounded bg-rose-900/60 hover:bg-rose-800 text-rose-200 text-[10px] font-bold cursor-pointer transition"
                        >
                          ล้างค่า
                        </button>
                      </div>
                    );
                  })()
                ) : (
                  <p className="text-[10px] text-amber-300/80">
                    💡 แนะนำ: กดปุ่ม "ออก Fast-Track WO ทันที" เพื่อให้งานซ่อมมีใบสั่งงาน CMMS ครบ 100%
                  </p>
                )}
              </div>

              {/* Row 1.5: Multi-Technician Select Checkboxes */}
              <div className="space-y-1.5 bg-slate-900/40 p-3 rounded-xl border border-slate-700">
                <div className="flex justify-between items-center text-[11px] font-semibold">
                  <span className="text-slate-300">ช่างเทคนิคผู้รับผิดชอบงานซ่อม (รับผิดชอบงานได้หลายคน)*</span>
                  <span className="text-cyan-400 font-bold font-mono">เลือกแล้ว: {formTechnicians.length} คน</span>
                </div>
                
                {/* Scrollable grid area */}
                <div className="mt-1.5 max-h-[140px] overflow-y-auto border border-slate-750 bg-slate-950 rounded-lg p-2.5 grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {technicians.map(t => {
                    const isChecked = formTechnicians.includes(t);
                    return (
                      <label 
                        key={t} 
                        className={`flex items-center gap-1.5 p-1.5 rounded-md border cursor-pointer select-none transition-all ${
                          isChecked 
                            ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300 font-bold' 
                            : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:text-slate-300 hover:border-slate-750'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleTechnician(t)}
                          className="w-3.5 h-3.5 rounded accent-cyan-500 cursor-pointer"
                        />
                        <span className="text-[11px] truncate">{t}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Row 2: Breakdown time -> Done time (Strict 24-Hour System) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <DateTimePicker24H
                  id="frm-rep-breakdown"
                  label="วันเวลาที่เกิดแจ้งเสีย (Breakdown Time)*"
                  required
                  value={formBreakdown}
                  onChange={(val) => {
                    setFormBreakdown(val);
                    if (!isStoppageManual && formUsedParts.length === 0 && !formHasPartsReplaced) {
                      const start = new Date(val).getTime();
                      const end = new Date(formDone).getTime();
                      const diffMin = end > start ? Math.floor((end - start) / 60000) : 0;
                      setFormStoppageType(diffMin < 15 ? 'MINOR_STOPPAGE' : 'ADJUSTMENT_LOSS');
                    }
                  }}
                />

                <DateTimePicker24H
                  id="frm-rep-done"
                  label="วันเวลาที่ซ่อมเสร็จเดินเครื่องได้ (Done)*"
                  required
                  value={formDone}
                  onChange={(val) => {
                    setFormDone(val);
                    if (!isStoppageManual && formUsedParts.length === 0 && !formHasPartsReplaced) {
                      const start = new Date(formBreakdown).getTime();
                      const end = new Date(val).getTime();
                      const diffMin = end > start ? Math.floor((end - start) / 60000) : 0;
                      setFormStoppageType(diffMin < 15 ? 'MINOR_STOPPAGE' : 'ADJUSTMENT_LOSS');
                    }
                  }}
                />
              </div>

              {/* Row 2.5: Stoppage & Loss Classification Definition Block */}
              <div className="bg-slate-900/60 p-4 border border-slate-700/80 rounded-xl space-y-3.5" id="form-stoppage-classification-block">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wide flex items-center gap-1.5">
                      <Tag size={13} />
                      การจำแนกประเภทความสูญเสีย (Failure Classification ตามนิยาม)
                    </span>
                    <span className="text-[10px] text-slate-400">
                      • หน่วยบันทึก: <strong>ครั้ง</strong> (เก็บบันทึกเวลา MTTR ควบคู่)
                    </span>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-auto">
                    <span className="text-[11px] text-slate-400">เวลาซ่อม (MTTR):</span>
                    <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-slate-800 border border-slate-700 text-cyan-300">
                      ⏱ {getLiveMttr()} นาที
                    </span>
                  </div>
                </div>

                {/* 3 Selectable classification cards according to exact user definition */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                  {/* Option 1: Breakdown */}
                  <label
                    className={`p-3 rounded-lg border cursor-pointer transition-all flex flex-col justify-between select-none ${
                      formStoppageType === 'BREAKDOWN'
                        ? 'bg-rose-950/40 border-rose-500/80 ring-1 ring-rose-500/40'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/40'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="radio"
                            name="formStoppageRadio"
                            value="BREAKDOWN"
                            checked={formStoppageType === 'BREAKDOWN'}
                            onChange={() => {
                              setFormStoppageType('BREAKDOWN');
                              setFormHasPartsReplaced(true);
                              setIsStoppageManual(true);
                            }}
                            className="accent-rose-500"
                          />
                          <span className="text-xs font-bold text-rose-300">Breakdown</span>
                        </div>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300">
                          หน่วย: ครั้ง
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-300 leading-relaxed">
                        เครื่องเสียที่ไม่ทราบล่วงหน้า <strong>มีการเปลี่ยนอะไหล่</strong> หน่วยเป็นครั้ง แต่เก็บเวลาด้วย
                      </p>
                    </div>
                  </label>

                  {/* Option 2: Minor stoppage */}
                  <label
                    className={`p-3 rounded-lg border cursor-pointer transition-all flex flex-col justify-between select-none ${
                      formStoppageType === 'MINOR_STOPPAGE'
                        ? 'bg-amber-950/40 border-amber-500/80 ring-1 ring-amber-500/40'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/40'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="radio"
                            name="formStoppageRadio"
                            value="MINOR_STOPPAGE"
                            checked={formStoppageType === 'MINOR_STOPPAGE'}
                            onChange={() => {
                              setFormStoppageType('MINOR_STOPPAGE');
                              setFormHasPartsReplaced(false);
                              setIsStoppageManual(true);
                            }}
                            className="accent-amber-500"
                          />
                          <span className="text-xs font-bold text-amber-300">Minor stoppage</span>
                        </div>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                          &lt; 15 นาที
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-300 leading-relaxed">
                        เครื่องเสียที่ไม่ทราบล่วงหน้า <strong>ไม่มีการเปลี่ยนอะไหล่ น้อยกว่า 15 นาที</strong> หน่วยเป็นครั้ง
                      </p>
                    </div>
                  </label>

                  {/* Option 3: Adjustment loss */}
                  <label
                    className={`p-3 rounded-lg border cursor-pointer transition-all flex flex-col justify-between select-none ${
                      formStoppageType === 'ADJUSTMENT_LOSS'
                        ? 'bg-orange-950/40 border-orange-500/80 ring-1 ring-orange-500/40'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/40'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="radio"
                            name="formStoppageRadio"
                            value="ADJUSTMENT_LOSS"
                            checked={formStoppageType === 'ADJUSTMENT_LOSS'}
                            onChange={() => {
                              setFormStoppageType('ADJUSTMENT_LOSS');
                              setFormHasPartsReplaced(false);
                              setIsStoppageManual(true);
                            }}
                            className="accent-orange-500"
                          />
                          <span className="text-xs font-bold text-orange-300">Adjustment loss</span>
                        </div>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-300">
                          &gt; 15 นาที
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-300 leading-relaxed">
                        เครื่องเสียที่ไม่ทราบล่วงหน้า <strong>ไม่มีการเปลี่ยนอะไหล่ มากกว่า 15 นาที</strong> หน่วยเป็นครั้ง
                      </p>
                    </div>
                  </label>
                </div>

                {/* Parts replaced checkbox & auto-detection recommendation status */}
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 pt-2 border-t border-slate-800/80 text-[11px]">
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      id="frm-has-parts-replaced"
                      checked={formHasPartsReplaced || formUsedParts.length > 0}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setFormHasPartsReplaced(checked);
                        setIsStoppageManual(true);
                        if (checked) {
                          setFormStoppageType('BREAKDOWN');
                        } else {
                          setFormStoppageType(getLiveMttr() < 15 ? 'MINOR_STOPPAGE' : 'ADJUSTMENT_LOSS');
                        }
                      }}
                      className="w-4 h-4 rounded accent-rose-500 cursor-pointer"
                    />
                    <span className="font-semibold text-slate-200">
                      🔧 มีการเปลี่ยนอะไหล่จริงในงานนี้ (Has Parts Replaced)
                    </span>
                    {formUsedParts.length > 0 && (
                      <span className="text-[10px] text-cyan-400 font-mono">
                        (มีรายการในตารางอะไหล่ {formUsedParts.length} รายการ)
                      </span>
                    )}
                  </label>

                  <button
                    type="button"
                    onClick={() => {
                      setIsStoppageManual(false);
                      const hasParts = formUsedParts.length > 0 || formHasPartsReplaced;
                      const detected = detectStoppageType(hasParts, getLiveMttr());
                      setFormStoppageType(detected);
                    }}
                    className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 underline self-start sm:self-auto cursor-pointer"
                    title="ให้ระบบคำนวณหมวดหมู่ตามเวลาซ่อมและการใช้อะไหล่อัตโนมัติ"
                  >
                    🤖 คำนวณตามสูตรอัตโนมัติ (Auto-detect)
                  </button>
                </div>
              </div>

              {/* Row 3: Symptoms */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300">รายละเอียดอาการเสียที่พบ*</label>
                <input
                  id="frm-rep-symptoms"
                  type="text"
                  required
                  placeholder="เช่น ลูกปืนพัดลมฝืดจัดและหน้าจอละลายควันขึ้น"
                  value={formSymptoms}
                  onChange={(e) => setFormSymptoms(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-slate-200 focus:outline-none"
                />
              </div>

              {/* Row 4: Why-Why analysis 1-5 (Cascading dynamic display) */}
              <div className="bg-slate-900/40 p-4 border border-slate-700 rounded-xl space-y-3">
                <div className="flex justify-between items-center select-none pb-1.5 border-b border-slate-700/50">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">
                    ❓ วิเคราะห์ Why-Why หาปัจจัยรากเหง้าแฝง
                  </span>
                  <button
                    type="button"
                    onClick={() => setWhyCount(prev => Math.min(5, prev + 1))}
                    disabled={whyCount === 5}
                    className="text-[10px] font-bold bg-cyan-500/10 hover:bg-cyan-550 border border-cyan-550/20 text-cyan-400 hover:text-slate-950 px-2.5 py-1 rounded transition disabled:opacity-40"
                  >
                    + เพิ่มคำถาม Why ({whyCount}/5)
                  </button>
                </div>

                <div className="space-y-2 pt-1" id="why-cascading-inputs">
                  {whyCount >= 1 && (
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-red-400 w-12 shrink-0">Why 1 :</span>
                      <input
                        type="text"
                        placeholder="ทำไมจึงแจ้งเสีย? (เช่น ตัวเซ็นเซอร์ไม่ตัดรอบแกนลูกถ้วย)"
                        value={why1}
                        onChange={(e) => setWhy1(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 focus:outline-none"
                      />
                    </div>
                  )}
                  {whyCount >= 2 && (
                    <div className="flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
                      <span className="text-[10px] font-bold text-red-400 w-12 shrink-0">Why 2 :</span>
                      <input
                        type="text"
                        placeholder="ทำไมไม่ตัดรอบ? (เช่น คราบจาระบีเกาะแห้งหนาก็เลยบังลำแสง)"
                        value={why2}
                        onChange={(e) => setWhy2(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 focus:outline-none"
                      />
                    </div>
                  )}
                  {whyCount >= 3 && (
                    <div className="flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
                      <span className="text-[10px] font-bold text-red-400 w-12 shrink-0">Why 3 :</span>
                      <input
                        type="text"
                        placeholder="ทำไมมีคราบบังแสง? (เช่น ฝาครอบเซ็นเซอร์บิดตัวเปิดกว้างออก)"
                        value={why3}
                        onChange={(e) => setWhy3(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 focus:outline-none"
                      />
                    </div>
                  )}
                  {whyCount >= 4 && (
                    <div className="flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
                      <span className="text-[10px] font-bold text-red-400 w-12 shrink-0">Why 4 :</span>
                      <input
                        type="text"
                        placeholder="ทำไมฝาบิดตัว? (เช่น ช่างซ่อมคนก่อนยึดสลักเกลียวแค่ตัวเดียวเวลาขันเกลียว)"
                        value={why4}
                        onChange={(e) => setWhy4(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 focus:outline-none"
                      />
                    </div>
                  )}
                  {whyCount >= 5 && (
                    <div className="flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
                      <span className="text-[10px] font-bold text-red-400 w-12 shrink-0">Why 5 :</span>
                      <input
                        type="text"
                        placeholder="ทำไมช่างไม่ตรวจ? (เช่น ขอบเขตการยึดน็อตเซ็นเซอร์ไม่มีระบุในขั้นตอนมาตรฐาน)"
                        value={why5}
                        onChange={(e) => setWhy5(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-300 focus:outline-none"
                      />
                    </div>
                  )}
                </div>

                {/* Dedicated Why-Why file uploader & Kaizen Sync indicator */}
                <div className="pt-2.5 mt-2 border-t border-slate-750/70 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-amber-400 flex items-center gap-1.5">
                      <HelpCircle size={12} />
                      แนบไฟล์การวิเคราะห์ Why-Why (Excel / PDF / Word / รูปภาพ)
                    </span>
                    <span className="text-[9.5px] text-amber-300/80 font-mono">
                      🚀 เชื่อมโยงไป Why-Why แถบ Kaizen อัตโนมัติ
                    </span>
                  </div>

                  {/* Dropzone for Why-Why file */}
                  <div
                    onDragOver={(e) => { e.preventDefault(); setDragOverCategory('WHY_WHY'); }}
                    onDragLeave={() => setDragOverCategory(null)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setDragOverCategory(null);
                      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                        Array.from<File>(e.dataTransfer.files).forEach((file: File) => {
                          handleAttachmentUpload(file, 'WHY_WHY');
                        });
                      }
                    }}
                    onPaste={(e) => handlePasteEvent(e, 'WHY_WHY')}
                    tabIndex={0}
                    className={`border border-dashed p-2.5 rounded-xl text-center relative group transition cursor-pointer outline-none ${
                      dragOverCategory === 'WHY_WHY'
                        ? 'border-amber-400 bg-amber-950/40 ring-1 ring-amber-500/50'
                        : 'border-slate-700/80 hover:border-amber-500/60 bg-slate-950/60'
                    }`}
                  >
                    <input
                      type="file"
                      multiple
                      accept=".pdf, .xlsx, .xls, .csv, .doc, .docx, image/*"
                      onChange={(e) => {
                        if (e.target.files) {
                          Array.from<File>(e.target.files).forEach((file: File) => {
                            handleAttachmentUpload(file, 'WHY_WHY');
                          });
                          e.target.value = '';
                        }
                      }}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <div className="flex items-center justify-center gap-2 pointer-events-none">
                      <Upload size={14} className="text-amber-400" />
                      <span className="text-[11px] font-medium text-slate-300">
                        คลิก หรือ ลากวางไฟล์ Why-Why เพื่อแนบประกอบ (หรือกด Ctrl+V)
                      </span>
                    </div>
                  </div>

                  {/* Attached Why-Why files preview list */}
                  {formAttachments.filter(a => a.category === 'WHY_WHY').length > 0 && (
                    <div className="space-y-1.5 pt-1">
                      {formAttachments.filter(a => a.category === 'WHY_WHY').map(att => (
                        <div
                          key={att.id}
                          className="bg-amber-950/20 border border-amber-900/40 p-2 rounded-lg flex items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            {att.fileType === 'excel' ? (
                              <FileSpreadsheet size={15} className="text-emerald-400 shrink-0" />
                            ) : (
                              <FileText size={15} className="text-amber-400 shrink-0" />
                            )}
                            <div className="min-w-0">
                              <p className="text-amber-200 text-xs font-semibold truncate" title={att.name}>
                                {att.name}
                              </p>
                              <span className="text-[9.5px] text-slate-400 font-mono">
                                {att.size || 'ไฟล์แนบ'} • ซิงค์เข้า Why-Why แถบ Kaizen
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {(att.fileType === 'pdf' || att.fileType === 'excel') && (
                              <button
                                type="button"
                                onClick={() => setPreviewPDF({
                                  id: att.id,
                                  name: att.name,
                                  content: att.content,
                                  fileType: att.fileType === 'excel' ? 'excel' : 'pdf',
                                  size: att.size,
                                  uploadedAt: att.uploadedAt
                                })}
                                className="p-1 text-slate-400 hover:text-cyan-400 hover:bg-slate-900 rounded transition cursor-pointer"
                                title="เปิดดูตัวอย่างไฟล์"
                              >
                                <Eye size={13} />
                              </button>
                            )}
                            <a
                              href={att.content}
                              download={att.name}
                              className="p-1 text-slate-400 hover:text-emerald-400 hover:bg-slate-900 rounded transition cursor-pointer"
                              title="ดาวน์โหลดไฟล์"
                            >
                              <Download size={13} />
                            </a>
                            <button
                              type="button"
                              onClick={() => handleRemoveAttachment(att.id)}
                              className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-900 rounded transition cursor-pointer"
                              title="ลบไฟล์แนบ"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Row 5: Corrective action */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300">มาตรการแก้ไขแนวทางป้องกันถาวร*</label>
                <textarea
                  id="frm-rep-correction"
                  required
                  rows={2}
                  placeholder="เช่น ทำความสะอาดหัวจิกและซีลขั้วด้วยเทปยืดพิเศษ พร้อมบันทึกแผนขันสลักให้ครบ 2 ตัวลงใบ PM สากล"
                  value={formCorrection}
                  onChange={(e) => setFormCorrection(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-slate-205 focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Row 5.5: Status of Ticket */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300">สถานะใบงานซ่อมบำรุง*</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as 'กำลังซ่อม' | 'ปิดงาน')}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-xs text-slate-250 focus:outline-none focus:border-cyan-500"
                >
                  <option value="ปิดงาน">ปิดสำเร็จ (การดำเนินการเสร็จสิ้นเรียบร้อย)</option>
                  <option value="กำลังซ่อม">กำลังซ่อม (อยู่ระหว่างซ่อม/งานยังค้างอยู่)</option>
                </select>
              </div>

              {/* SPARE PARTS AND REPAIR COSTS SECTION */}
              <div className="bg-slate-900/50 p-4 border border-slate-700/80 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                  <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wide flex items-center gap-1.5 select-none">
                    <Wrench className="w-3.5 h-3.5" /> อะไหล่ที่ใช้และค่าใช้จ่าย (Spare Parts & Costs)
                  </span>

                  {/* Mode switcher tabs */}
                  <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[10.5px]">
                    <button
                      type="button"
                      onClick={() => setPartSourceMode('inventory')}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded font-medium transition cursor-pointer ${
                        partSourceMode === 'inventory'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Package className="w-3 h-3" /> เลือกจากคลังอะไหล่
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPartSourceMode('custom');
                        if (partSearchQuery.trim() && !customPartName) {
                          setCustomPartName(partSearchQuery.trim());
                        }
                      }}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded font-medium transition cursor-pointer ${
                        partSourceMode === 'custom'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <PenLine className="w-3 h-3" /> พิมพ์ระบุอะไหล่เอง (นอกคลัง)
                    </button>
                  </div>
                </div>
                
                {/* 1. INVENTORY MODE */}
                {partSourceMode === 'inventory' && (
                  <div className="space-y-2 pt-0.5">
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                      <div className="sm:col-span-7 space-y-1">
                        <label className="text-[10px] text-slate-400 font-bold flex justify-between items-center">
                          <span>ค้นหาและเลือกอะไหล่ในคลัง</span>
                          {partSearchQuery && (
                            <button 
                              type="button" 
                              onClick={() => setPartSearchQuery('')} 
                              className="text-[9px] text-cyan-400 hover:underline"
                            >
                              ล้างค้นหา ✕
                            </button>
                          )}
                        </label>
                        <div className="space-y-1">
                          <input
                            type="text"
                            placeholder="🔍 พิมพ์ค้นหาอะไหล่ (ชื่อ หรือ รหัส)..."
                            value={partSearchQuery}
                            onChange={(e) => setPartSearchQuery(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-[10.5px] text-slate-200 focus:outline-none focus:border-cyan-500 placeholder-slate-500 font-sans"
                          />
                          <select
                            value={selectedPartId}
                            onChange={(e) => {
                              const pid = e.target.value;
                              setSelectedPartId(pid);
                              const found = spareParts.find(p => p.id === pid);
                              if (found) {
                                setSelectedPartPrice(found.pricePerUnit);
                              } else {
                                setSelectedPartPrice(0);
                              }
                            }}
                            className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-cyan-500 font-sans"
                          >
                            <option value="">
                              {partSearchQuery ? `-- อะไหล่ที่ตรงค้นหา (${spareParts.filter(sp => sp.name.toLowerCase().includes(partSearchQuery.toLowerCase()) || sp.id.toLowerCase().includes(partSearchQuery.toLowerCase())).length} รายการ) --` : "-- เลือกอะไหล่ในคลัง --"}
                            </option>
                            {spareParts
                              .filter(sp => {
                                if (!partSearchQuery) return true;
                                const q = partSearchQuery.toLowerCase();
                                return sp.name.toLowerCase().includes(q) || sp.id.toLowerCase().includes(q);
                              })
                              .map(sp => {
                                const isMatch = sp.machineIds?.includes(formMachine);
                                return (
                                  <option key={sp.id} value={sp.id}>
                                    {isMatch ? "⭐ " : ""}{sp.name} [{sp.id}] - {sp.pricePerUnit.toLocaleString()} บาท/หน่วย (คงเหลือ: {sp.quantity} {sp.unit})
                                  </option>
                                );
                              })}
                          </select>
                        </div>
                      </div>

                      <div className="sm:col-span-3 space-y-1">
                        <label className="text-[10px] text-slate-400 text-center block">จำนวน</label>
                        <input
                          type="number"
                          min="1"
                          value={selectedPartQty}
                          onChange={(e) => setSelectedPartQty(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-cyan-500 text-center font-mono"
                        />
                      </div>

                      <div className="sm:col-span-2 space-y-1 flex flex-col justify-end">
                        <button
                          type="button"
                          onClick={handleAddPartToForm}
                          className="w-full bg-cyan-500/20 hover:bg-cyan-500 border border-cyan-500/30 hover:text-slate-950 text-cyan-300 hover:font-bold text-[11px] py-1.5 rounded transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" /> เพิ่ม
                        </button>
                      </div>
                    </div>

                    {/* Quick suggestion banner to jump to custom part */}
                    {partSearchQuery.trim() && (
                      <div className="flex items-center justify-between gap-2 p-2 bg-amber-500/10 border border-amber-500/25 rounded-lg text-[10px] text-amber-300">
                        <span className="truncate">
                          💡 ไม่พบในคลัง หรือต้องการระบุ <b>"{partSearchQuery.trim()}"</b> เป็นอะไหล่นอกคลัง?
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setPartSourceMode('custom');
                            setCustomPartName(partSearchQuery.trim());
                          }}
                          className="shrink-0 px-2 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[9.5px] transition cursor-pointer flex items-center gap-1"
                        >
                          <PenLine className="w-2.5 h-2.5" /> พิมพ์เพิ่มเป็นอะไหล่นอกคลัง
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. CUSTOM NON-INVENTORY PART MODE */}
                {partSourceMode === 'custom' && (
                  <div className="bg-slate-950/60 p-3 rounded-lg border border-amber-500/30 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-amber-300 flex items-center gap-1">
                        ✏️ พิมพ์ระบุอะไหล่นอกคลัง (จัดซื้อเร่งด่วน / สั่งทำพิเศษ / ซื้อหน้างาน)
                      </span>
                      <button
                        type="button"
                        onClick={() => setPartSourceMode('inventory')}
                        className="text-[9.5px] text-slate-400 hover:text-cyan-400 hover:underline cursor-pointer"
                      >
                        ← กลับไปเลือกจากคลัง
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                      <div className="sm:col-span-7 space-y-1">
                        <label className="text-[10px] text-slate-300 font-semibold">
                          ชื่อรายการอะไหล่ <span className="text-rose-400">*</span>
                        </label>
                        <input
                          type="text"
                          placeholder="เช่น ปลั๊ก 3 ขา ทนความร้อน, สายพานร่องวี B-42..."
                          value={customPartName}
                          onChange={(e) => setCustomPartName(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-[11px] text-slate-100 focus:outline-none focus:border-amber-400 font-sans"
                        />
                      </div>

                      <div className="sm:col-span-5 space-y-1">
                        <label className="text-[10px] text-slate-400">
                          รหัส / ยี่ห้อ / สเปกอ้างอิง (ถ้ามี)
                        </label>
                        <input
                          type="text"
                          placeholder="เช่น PLUG-3P-HT หรือ ยี่ห้อ Omron"
                          value={customPartCode}
                          onChange={(e) => setCustomPartCode(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-amber-400 font-sans"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-12 gap-2">
                      <div className="sm:col-span-3 space-y-1">
                        <label className="text-[10px] text-slate-300 font-semibold">
                          จำนวน <span className="text-rose-400">*</span>
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={customPartQty}
                          onChange={(e) => setCustomPartQty(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-[11px] text-slate-100 focus:outline-none focus:border-amber-400 text-center font-mono"
                        />
                      </div>

                      <div className="sm:col-span-3 space-y-1">
                        <label className="text-[10px] text-slate-300 font-semibold">หน่วยนับ</label>
                        <input
                          type="text"
                          placeholder="ชิ้น"
                          value={customPartUnit}
                          onChange={(e) => setCustomPartUnit(e.target.value)}
                          list="custom-part-unit-suggestions"
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-[11px] text-slate-100 focus:outline-none focus:border-amber-400 text-center"
                        />
                        <datalist id="custom-part-unit-suggestions">
                          <option value="ชิ้น" />
                          <option value="ตัว" />
                          <option value="เส้น" />
                          <option value="ชุด" />
                          <option value="เมตร" />
                          <option value="ม้วน" />
                          <option value="อัน" />
                          <option value="กล่อง" />
                        </datalist>
                      </div>

                      <div className="sm:col-span-3 space-y-1">
                        <label className="text-[10px] text-slate-300 font-semibold">ราคาต่อหน่วย (บาท)</label>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          value={customPartPrice || ''}
                          onChange={(e) => setCustomPartPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                          placeholder="0"
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-[11px] text-slate-100 focus:outline-none focus:border-amber-400 text-right font-mono"
                        />
                      </div>

                      <div className="col-span-2 sm:col-span-3 space-y-1 flex flex-col justify-end">
                        <button
                          type="button"
                          onClick={handleAddCustomPartToForm}
                          className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] py-1.5 rounded transition flex items-center justify-center gap-1 shadow-sm cursor-pointer"
                        >
                          <PlusCircle className="w-3.5 h-3.5" /> + เพิ่มอะไหล่นอกคลัง
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1 border-t border-slate-800">
                      <label className="flex items-center gap-1.5 text-[10px] text-slate-300 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={saveCustomToMaster}
                          onChange={(e) => setSaveCustomToMaster(e.target.checked)}
                          className="rounded border-slate-700 text-amber-500 focus:ring-0 cursor-pointer"
                        />
                        <span>บันทึกอะไหล่นี้เข้าฐานข้อมูลคลังพัสดุหลักด้วย (Master Inventory)</span>
                      </label>
                    </div>
                  </div>
                )}

                {/* Used spare parts list */}
                {formUsedParts.length > 0 ? (
                  <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-950">
                    <table className="w-full text-left text-[10px] text-slate-350">
                      <thead className="bg-slate-900 text-slate-400 text-[9px] uppercase border-b border-slate-800 select-none">
                        <tr>
                          <th className="p-2 pl-3">รายการอะไหล่</th>
                          <th className="p-2 text-center w-16">จำนวน</th>
                          <th className="p-2 text-right w-20">หน่วยละ</th>
                          <th className="p-2 text-right w-20">ราคารวม</th>
                          <th className="p-2 text-center w-10">ลบ</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850">
                        {formUsedParts.map(item => {
                          const originalPart = spareParts.find(p => p.id === item.partId);
                          const displayName = item.partName || originalPart?.name || item.partId;
                          const displayUnit = item.unit || originalPart?.unit || 'ชิ้น';
                          const isCustom = item.isCustom || !originalPart;

                          return (
                            <tr key={item.partId} className="hover:bg-slate-900/50">
                              <td className="p-2 pl-3">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <p className="font-semibold text-slate-200">{displayName}</p>
                                  {isCustom && (
                                    <span className="px-1.5 py-0.2 rounded text-[8px] bg-amber-500/15 text-amber-300 border border-amber-500/30 font-sans">
                                      อะไหล่นอกคลัง
                                    </span>
                                  )}
                                </div>
                                <p className="text-[8px] text-slate-500 font-mono">
                                  {item.isCustom ? (item.partId.startsWith('custom_') ? 'กำหนดเอง' : item.partId) : item.partId}
                                </p>
                              </td>
                              <td className="p-2 text-center font-mono text-slate-300">{item.quantity} {displayUnit}</td>
                              <td className="p-2 text-right font-mono text-slate-350">{item.pricePerUnit.toLocaleString()} ฿</td>
                              <td className="p-2 text-right font-mono text-cyan-400 font-semibold">{item.totalCost.toLocaleString()} ฿</td>
                              <td className="p-2 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleRemovePartFromForm(item.partId)}
                                  className="text-slate-500 hover:text-rose-400 p-0.5 rounded hover:bg-slate-900 cursor-pointer"
                                >
                                  ✕
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-[10px] text-slate-500 italic text-center py-2 bg-slate-950/30 rounded border border-slate-850/60 select-none">
                    ยังไม่มีการใช้อะไหล่ในใบงานนี้
                  </p>
                )}

                {/* Other costs like labor, contractor */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800/60">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-300 font-semibold">ค่าแรง/ค่าบริการอื่นๆ (บาท)</label>
                    <input
                      type="number"
                      min="0"
                      value={formOtherCost || ""}
                      onChange={(e) => setFormOtherCost(Math.max(0, parseFloat(e.target.value) || 0))}
                      placeholder="เช่น 0"
                      className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>

                  <div className="flex flex-col justify-center items-end pr-2">
                    <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">รวมค่าซ่อมทั้งสิ้น</span>
                    <span className="text-sm font-black font-mono text-cyan-400 mt-1">
                      {(formUsedParts.reduce((sum, item) => sum + item.totalCost, 0) + Number(formOtherCost || 0)).toLocaleString()} บาท
                    </span>
                  </div>
                </div>
              </div>

              {/* Row 6: Photo Attachment base64 */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300">แนบรูปภาพรายงานชำรุดเครื่องจักร (ถ้าต้องการ)</label>
                <div className="border border-dashed border-slate-700/60 hover:border-cyan-500/50 p-4 rounded-xl flex items-center justify-center bg-slate-900/10 cursor-pointer text-center relative group">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                  
                  {photoBase64 ? (
                    <div className="flex flex-col items-center space-y-2">
                      <img 
                      src={photoBase64} 
                      alt="breakdown attachment" 
                      className="w-24 h-24 object-cover rounded border border-slate-700" 
                      referrerPolicy="no-referrer"
                      />
                      <span className="text-[10px] text-emerald-400 font-bold">✓ อัปโหลดสำเร็จแล้ว (รูปภาพบันทึกเรียบร้อย)</span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center space-y-1 text-slate-400 group-hover:text-slate-300">
                      <ImageIcon size={22} className="text-slate-500" />
                      <p className="font-sans font-medium text-[11px]">คลิก หรือ ลากวางเพื่อแนบรูปภาพหน้างานจริง</p>
                      <p className="text-[9px] text-slate-500">รองรับระบบประจักษ์หลักฐานซ่อม JPG, PNG (.base64)</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Row 6.5: Excel Attachment */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                  <FileSpreadsheet size={15} className="text-emerald-400" />
                  แนบไฟล์ตาราง Excel / เอกสารประกอบใบงาน (ถ้าต้องการ)
                </label>
                <div className="border border-dashed border-slate-700/60 hover:border-emerald-500/50 p-4 rounded-xl flex items-center justify-center bg-slate-900/10 cursor-pointer text-center relative group">
                  <input
                    type="file"
                    accept=".xlsx, .xls, .csv, .pdf, .doc, .docx"
                    onChange={handleExcelAttachmentUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                  
                  {formExcelName ? (
                    <div className="flex flex-col items-center space-y-2">
                      <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs p-2.5 rounded-lg flex items-center gap-2 font-mono">
                        <FileSpreadsheet size={16} />
                        <span>{formExcelName}</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-bold">✓ แนบไฟล์สำเร็จแล้ว</span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center space-y-1 text-slate-400 group-hover:text-slate-300">
                      <Upload size={22} className="text-slate-500" />
                      <p className="font-sans font-medium text-[11px]">คลิก หรือ ลากวางเพื่อแนบไฟล์ Excel (.xlsx, .xls, .csv)</p>
                      <p className="text-[9px] text-slate-500">รองรับไฟล์ตารางคำนวณหรือแผนงานเพื่อแนบเข้าบันทึกซ่อม</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Row 7: FA, OPL, Kaizen Attachments & Link to Kaizen Tab */}
              <div className="space-y-3 bg-gradient-to-br from-slate-900/90 via-slate-900/60 to-indigo-950/40 p-4 rounded-xl border border-indigo-500/30 shadow-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shrink-0">
                      <Paperclip size={16} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-100 flex items-center gap-2">
                        <span>แนบเอกสาร FA / OPL / Why-Why / Kaizen & เชื่อมโยงไปยังแถบ Kaizen</span>
                        {formAttachments.length > 0 && (
                          <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.2 rounded-full font-mono font-bold">
                            {formAttachments.length} ไฟล์
                          </span>
                        )}
                      </h4>
                      <p className="text-[10.5px] text-slate-400">
                        วางไฟล์ PDF, Excel, Word หรือรูปภาพ เพื่อวิเคราะห์สาเหตุและสร้างบทเรียนส่งต่อฝ่ายผลิต
                      </p>
                    </div>
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer bg-slate-950/70 border border-slate-800 hover:border-indigo-500/50 px-2.5 py-1.5 rounded-lg text-[11px] text-slate-300 transition shrink-0 select-none">
                    <input
                      type="checkbox"
                      checked={formSyncToKaizen}
                      onChange={(e) => setFormSyncToKaizen(e.target.checked)}
                      className="rounded border-slate-700 text-indigo-500 focus:ring-0 cursor-pointer accent-indigo-500 w-3.5 h-3.5"
                    />
                    <span className="font-semibold text-indigo-300">ซิงค์ไปยังแถบ Kaizen อัตโนมัติ</span>
                  </label>
                </div>

                {/* Category Selection Tabs */}
                <div className="flex gap-2 p-1 bg-slate-950/90 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setActiveAttachmentTab('FA')}
                    className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeAttachmentTab === 'FA'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                    }`}
                  >
                    <span>🔍 FA (Failure Analysis)</span>
                    {formAttachments.filter(a => a.category === 'FA').length > 0 && (
                      <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] flex items-center justify-center font-mono">
                        {formAttachments.filter(a => a.category === 'FA').length}
                      </span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveAttachmentTab('OPL')}
                    className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeAttachmentTab === 'OPL'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                    }`}
                  >
                    <span>💡 OPL (One Point Lesson)</span>
                    {formAttachments.filter(a => a.category === 'OPL').length > 0 && (
                      <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[9px] flex items-center justify-center font-mono font-bold">
                        {formAttachments.filter(a => a.category === 'OPL').length}
                      </span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveAttachmentTab('WHY_WHY')}
                    className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeAttachmentTab === 'WHY_WHY'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                    }`}
                  >
                    <span>❓ Why-Why Analysis</span>
                    {formAttachments.filter(a => a.category === 'WHY_WHY').length > 0 && (
                      <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[9px] flex items-center justify-center font-mono font-bold">
                        {formAttachments.filter(a => a.category === 'WHY_WHY').length}
                      </span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveAttachmentTab('KAIZEN')}
                    className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeAttachmentTab === 'KAIZEN'
                        ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                    }`}
                  >
                    <span>🚀 Kaizen (โครงการปรับปรุง)</span>
                    {formAttachments.filter(a => a.category === 'KAIZEN').length > 0 && (
                      <span className="w-4 h-4 rounded-full bg-indigo-500 text-white text-[9px] flex items-center justify-center font-mono font-bold">
                        {formAttachments.filter(a => a.category === 'KAIZEN').length}
                      </span>
                    )}
                  </button>
                </div>

                {/* Upload & Dropzone & Clipboard Paste Area */}
                <div
                  onDragOver={(e) => { e.preventDefault(); setDragOverCategory(activeAttachmentTab); }}
                  onDragLeave={() => setDragOverCategory(null)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDragOverCategory(null);
                    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                      Array.from(e.dataTransfer.files).forEach((file: File) => {
                        handleAttachmentUpload(file, activeAttachmentTab);
                      });
                    }
                  }}
                  onPaste={(e) => handlePasteEvent(e, activeAttachmentTab)}
                  tabIndex={0}
                  className={`border-2 border-dashed p-4 rounded-xl text-center relative group transition cursor-pointer outline-none ${
                    dragOverCategory === activeAttachmentTab
                      ? 'border-indigo-400 bg-indigo-950/50 ring-2 ring-indigo-500/50'
                      : 'border-slate-700/80 hover:border-indigo-500/60 bg-slate-950/60 hover:bg-slate-950/90'
                  }`}
                >
                  <input
                    type="file"
                    multiple
                    accept=".pdf, .xlsx, .xls, .csv, .doc, .docx, image/*"
                    onChange={(e) => {
                      if (e.target.files) {
                        Array.from(e.target.files).forEach((file: File) => {
                          handleAttachmentUpload(file, activeAttachmentTab);
                        });
                        e.target.value = '';
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                  <div className="flex flex-col items-center justify-center gap-1.5 pointer-events-none">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-750 flex items-center justify-center text-slate-300 group-hover:text-indigo-400 group-hover:border-indigo-500/40 transition">
                      <Upload size={20} />
                    </div>
                    <p className="text-xs font-semibold text-slate-200">
                      คลิก หรือ ลากวางไฟล์สำหรับ <strong className="text-indigo-300 underline underline-offset-2">{activeAttachmentTab === 'FA' ? 'FA (วิเคราะห์ความเสียหาย)' : activeAttachmentTab === 'OPL' ? 'OPL (บทเรียนจุดเดียว)' : 'Kaizen (โครงการปรับปรุง)'}</strong>
                    </p>
                    <p className="text-[10px] text-slate-400 flex items-center gap-1.5 flex-wrap justify-center">
                      <span>รองรับ PDF, Excel, Word, ภาพถ่าย</span>
                      <span>•</span>
                      <span className="text-amber-400 font-medium">📋 วางไฟล์/รูปจาก Clipboard (Ctrl+V) ได้ทันที</span>
                    </p>
                  </div>
                </div>

                {/* List of Attached Documents */}
                {formAttachments.length > 0 && (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-300">
                      <span>รายการไฟล์แนบ ({formAttachments.length} ไฟล์):</span>
                      <span className="text-[10px] text-slate-400 font-normal">กดปุ่ม "ไป Kaizen" เพื่อเปิดในหน้า Kaizen</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                      {formAttachments.map((att) => (
                        <div
                          key={att.id}
                          className="bg-slate-950/90 border border-slate-800 hover:border-slate-700 p-2.5 rounded-xl flex items-center justify-between gap-2 text-xs transition"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span className={`px-2 py-0.5 rounded text-[9.5px] font-bold font-mono shrink-0 border ${
                              att.category === 'FA'
                                ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                                : att.category === 'OPL'
                                ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                                : 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30'
                            }`}>
                              {att.category}
                            </span>
                            <div className="min-w-0">
                              <p className="text-slate-200 font-medium truncate text-[11px]" title={att.name}>
                                {att.name}
                              </p>
                              <p className="text-[9.5px] text-slate-400 font-mono">
                                {att.fileType.toUpperCase()} • {att.size || ''}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {(att.fileType === 'pdf' || att.fileType === 'excel') && (
                              <button
                                type="button"
                                onClick={() => setPreviewPDF({
                                  id: att.id,
                                  name: att.name,
                                  content: att.content,
                                  fileType: att.fileType === 'excel' ? 'excel' : 'pdf',
                                  size: att.size,
                                  uploadedAt: att.uploadedAt
                                })}
                                className="p-1 text-slate-400 hover:text-cyan-400 hover:bg-slate-900 rounded transition cursor-pointer"
                                title="เปิดดูตัวอย่างไฟล์"
                              >
                                <Eye size={13} />
                              </button>
                            )}
                            <a
                              href={att.content}
                              download={att.name}
                              className="p-1 text-slate-400 hover:text-emerald-400 hover:bg-slate-900 rounded transition cursor-pointer"
                              title="ดาวน์โหลดไฟล์"
                            >
                              <Download size={13} />
                            </a>
                            <button
                              type="button"
                              onClick={() => handleNavigateToKaizenProject(att, formMachine)}
                              className="px-2 py-0.5 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 hover:text-indigo-200 border border-indigo-500/40 rounded text-[10px] font-bold flex items-center gap-1 transition cursor-pointer"
                              title="เชื่อมโยงและเปิดดูในแถบ Kaizen"
                            >
                              <ExternalLink size={10} />
                              <span>ไป Kaizen</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveAttachment(att.id)}
                              className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-900 rounded transition cursor-pointer"
                              title="ลบไฟล์แนบนี้"
                            >
                              <X size={13} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Controls */}
              <div className="pt-4 border-t border-slate-700 flex items-center justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowFormModal(false)}
                  className="border border-slate-700 hover:bg-slate-700/80 text-slate-300 text-xs px-4 py-2.5 rounded-lg transition"
                >
                  ยกเลิก
                </button>
                <button
                  id="frm-btn-save-repair"
                  type="submit"
                  className="bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs px-5 py-2.5 rounded-lg transition shadow-md"
                >
                  {editingId ? "บันทึกการแก้ไข" : "อนุมัติรายงานวิเคราะห์ซ่อม"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Details modal */}
      {selectedRepairDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div id="repair-detail-modal" className="bg-slate-800 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150">
            {/* Header */}
            <div className="bg-gradient-to-r from-slate-900 to-slate-850 border-b border-slate-700 p-5 shrink-0 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <span className="p-1 px-2.5 bg-rose-500/10 border border-rose-500/20 rounded-full text-[10px] font-extrabold text-rose-400 font-mono">
                  BREAKDOWN LOG DETAILS
                </span>
                <span className="text-slate-400 text-xs">| รหัสใบงาน: {selectedRepairDetail.id}</span>
              </div>
              <button 
                onClick={() => setSelectedRepairDetail(null)}
                className="text-slate-400 hover:text-slate-200 bg-slate-900 hover:bg-slate-700/60 w-7 h-7 flex items-center justify-center rounded-lg transition"
              >
                ✕
              </button>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-6 overflow-y-auto flex-1 text-slate-200 text-xs">
              
              {/* Machine & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-900/50 p-4 rounded-xl border border-slate-750">
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">เครื่องจักรที่เกิดอาการเสีย</p>
                  <p className="text-sm font-bold text-cyan-450 mt-1 font-mono">
                    {selectedRepairDetail.machineId} : {machines.find(m => m.id === selectedRepairDetail.machineId)?.name || 'เครื่องจักรทั่วไป'}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    แผนก/กลุ่มสายผลิต: {machines.find(m => m.id === selectedRepairDetail.machineId)?.lineGroup || '-'}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">สถานะใบงานซ่อม</p>
                  <div className="mt-1">
                    {selectedRepairDetail.status === 'กำลังซ่อม' ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full font-bold">
                        <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping"></span>
                        อยู่ระหว่างดำเนินการซ่อม
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full font-bold">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                        ปิดประวัติซ่อมสำเร็จแล้ว
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Time Indicators */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-900/30 p-4 rounded-xl border border-slate-755 text-center">
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold">เวลาที่เกิดแจ้งเสีย (Breakdown)</p>
                  <p className="text-xs font-mono font-bold text-rose-400 mt-1">
                    {selectedRepairDetail.breakdownTime ? selectedRepairDetail.breakdownTime.replace('T', ' ') : selectedRepairDetail.date}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold">เวลาซ่อมเดินเครื่องได้ (Done)</p>
                  <p className="text-xs font-mono font-bold text-emerald-400 mt-1">
                    {selectedRepairDetail.repairDoneTime ? selectedRepairDetail.repairDoneTime.replace('T', ' ') : '-'}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-bold">รวมเวลายึดเครื่อง (MTTR)</p>
                  <p className="text-xs font-mono font-bold text-slate-100 mt-1">
                    <span className="text-rose-450 font-extrabold">{selectedRepairDetail.duration} นาที</span>
                    <span className="text-slate-450 font-normal"> (เป้าหมาย: {getStandardMttr(selectedRepairDetail.machineId)} นาที)</span>
                  </p>
                </div>
              </div>

              {/* Stoppage Classification in Detail View */}
              {(() => {
                const sType = getRepairStoppageType(selectedRepairDetail);
                const info = STOPPAGE_TYPE_DEFINITIONS[sType];
                const hasParts = (selectedRepairDetail.usedParts && selectedRepairDetail.usedParts.length > 0) || selectedRepairDetail.hasPartsReplaced;
                
                return (
                  <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-750 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
                          <Tag size={13} className="text-cyan-400" />
                          การจำแนกประเภทความสูญเสีย (Loss Classification)
                        </span>
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-xs border ${
                          sType === 'BREAKDOWN'
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                            : sType === 'MINOR_STOPPAGE'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                        }`}>
                          {info.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] font-mono">
                        <span className="text-slate-400">หน่วยนับ:</span>
                        <span className="text-slate-200 font-bold">1 ครั้ง</span>
                        <span className="text-slate-500">|</span>
                        <span className="text-slate-400">เก็บเวลา MTTR:</span>
                        <span className="text-cyan-400 font-bold">{selectedRepairDetail.duration} นาที</span>
                      </div>
                    </div>

                    <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 space-y-1">
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        <strong className="text-cyan-400 font-semibold">นิยาม:</strong> {info.definition}
                      </p>
                      <div className="flex flex-wrap items-center gap-3 text-[10.5px] text-slate-400 pt-1 border-t border-slate-850">
                        <span>สถานะอะไหล่: {hasParts ? '🛠 มีการเปลี่ยนอะไหล่' : '✓ ไม่มีการเปลี่ยนอะไหล่'}</span>
                        <span>•</span>
                        <span>เกณฑ์เวลา: {info.condition}</span>
                        <span>•</span>
                        <span>หน่วย: {info.unit}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Problem Symptoms & Corrective Action */}
              <div className="space-y-4">
                <div className="bg-slate-900/20 p-4 rounded-xl border border-slate-750">
                  <h4 className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5 mb-2">
                    🚨 อาการเสียชำรุดที่พบหน้างานจริง
                  </h4>
                  <p className="text-slate-200 leading-relaxed pl-4 border-l-2 border-red-500 bg-slate-950/40 p-2.5 rounded-r-lg">{selectedRepairDetail.symptoms}</p>
                </div>

                <div className="bg-slate-900/20 p-4 rounded-xl border border-slate-750">
                  <h4 className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5 mb-2">
                    🛠 มาตรการซ่อมแซมและป้องกันถาวร (Action Taken)
                  </h4>
                  <p className="text-slate-200 leading-relaxed pl-4 border-l-2 border-cyan-500 bg-slate-950/40 p-2.5 rounded-r-lg">{selectedRepairDetail.correctiveAction}</p>
                </div>
              </div>

              {/* Why Why Analysis */}
              <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-750 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2 flex-wrap gap-2">
                  <h4 className="text-[11px] font-bold text-slate-300 tracking-wide uppercase flex items-center gap-1.5">
                    ❓ ลำดับการวิเคราะห์หาสาเหตุรากเหง้าแฝง (Why-Why Analysis)
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      navigateToKaizen({
                        category: 'WHY_WHY',
                        machineId: selectedRepairDetail.machineId,
                        searchQuery: selectedRepairDetail.symptoms,
                        sourceRepairId: selectedRepairDetail.id
                      });
                      setSelectedRepairDetail(null);
                    }}
                    className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-extrabold text-[10.5px] px-3 py-1.5 rounded-lg transition shadow-md cursor-pointer active:scale-95"
                    title="เปิดข้อมูลวิเคราะห์ Why-Why นี้ในแถบ Why-Why Analysis ของหน้า Kaizen"
                  >
                    <ExternalLink size={12} />
                    <span>🚀 เปิดใน Why-Why (แถบ Kaizen)</span>
                  </button>
                </div>
                
                <div className="space-y-2.5 pl-2 font-mono">
                  {selectedRepairDetail.why1 ? (
                    <div className="flex items-start gap-2.5">
                      <span className="text-[11px] font-bold text-red-400 shrink-0 w-14">Why 1 :</span>
                      <p className="text-slate-300 italic">{selectedRepairDetail.why1}</p>
                    </div>
                  ) : (
                    <p className="text-slate-500 italic text-[11px]">ไม่ได้บันทึกข้อมูลวิเคราะห์ Why 1</p>
                  )}

                  {selectedRepairDetail.why2 && (
                    <div className="flex items-start gap-2.5 border-t border-slate-800/65 pt-2">
                      <span className="text-[11px] font-bold text-red-400 shrink-0 w-14">Why 2 :</span>
                      <p className="text-slate-300 italic">{selectedRepairDetail.why2}</p>
                    </div>
                  )}

                  {selectedRepairDetail.why3 && (
                    <div className="flex items-start gap-2.5 border-t border-slate-800/65 pt-2">
                      <span className="text-[11px] font-bold text-red-400 shrink-0 w-14">Why 3 :</span>
                      <p className="text-slate-300 italic">{selectedRepairDetail.why3}</p>
                    </div>
                  )}

                  {selectedRepairDetail.why4 && (
                    <div className="flex items-start gap-2.5 border-t border-slate-800/65 pt-2">
                      <span className="text-[11px] font-bold text-red-400 shrink-0 w-14">Why 4 :</span>
                      <p className="text-slate-300 italic">{selectedRepairDetail.why4}</p>
                    </div>
                  )}

                  {selectedRepairDetail.why5 && (
                    <div className="flex items-start gap-2.5 border-t border-slate-800/65 pt-2">
                      <span className="text-[11px] font-bold text-red-400 shrink-0 w-14">Why 5 :</span>
                      <p className="text-slate-300 italic">{selectedRepairDetail.why5}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Used Spare Parts & Cost breakdown in Detail Modal */}
              <div className="bg-slate-900/30 border border-slate-750 p-4 rounded-xl space-y-3">
                <h4 className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5 border-b border-slate-800 pb-2 select-none">
                  🛠️ รายการอะไหล่ที่เปลี่ยนและมูลค่าซ่อมบำรุง
                </h4>
                
                {selectedRepairDetail.usedParts && selectedRepairDetail.usedParts.length > 0 ? (
                  <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-950/80">
                    <table className="w-full text-left text-[11px]">
                      <thead className="bg-slate-900/80 text-slate-400 text-[10px] uppercase border-b border-slate-800 select-none">
                        <tr>
                          <th className="p-2.5 pl-3">ชื่ออะไหล่ / SKU</th>
                          <th className="p-2.5 text-center w-20">จำนวน</th>
                          <th className="p-2.5 text-right w-24">หน่วยละ</th>
                          <th className="p-2.5 text-right w-24">ราคารวม</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850">
                        {selectedRepairDetail.usedParts.map(item => {
                          const partInfo = spareParts.find(p => p.id === item.partId);
                          const displayName = item.partName || partInfo?.name || item.partId;
                          const displayUnit = item.unit || partInfo?.unit || 'ชิ้น';
                          const isCustom = item.isCustom || !partInfo;

                          return (
                            <tr key={item.partId} className="hover:bg-slate-900/40 text-slate-300">
                              <td className="p-2.5 pl-3">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <p className="font-semibold">{displayName}</p>
                                  {isCustom && (
                                    <span className="px-1.5 py-0.2 rounded text-[8.5px] bg-amber-500/15 text-amber-300 border border-amber-500/30">
                                      ระบุเองนอกคลัง
                                    </span>
                                  )}
                                </div>
                                <p className="text-[9px] text-slate-500 font-mono">
                                  {item.isCustom ? (item.partId.startsWith('custom_') ? 'กำหนดเอง' : item.partId) : item.partId}
                                </p>
                              </td>
                              <td className="p-2.5 text-center font-mono">{item.quantity} {displayUnit}</td>
                              <td className="p-2.5 text-right font-mono">{item.pricePerUnit.toLocaleString()} ฿</td>
                              <td className="p-2.5 text-right font-mono text-cyan-400 font-bold">{item.totalCost.toLocaleString()} ฿</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 italic text-center py-2 bg-slate-950/20 rounded border border-slate-850 select-none">
                    ไม่มีรายงานการเบิกเปลี่ยนอะไหล่สำหรับประวัติซ่อมนี้
                  </p>
                )}

                <div className="grid grid-cols-2 gap-4 pt-1.5 text-xs">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-400 font-bold">ค่าแรง / ค่าซ่อมบำรุงอื่นๆ</span>
                    <span className="font-mono text-slate-200 mt-0.5 font-bold">
                      {(selectedRepairDetail.otherCost || 0).toLocaleString()} บาท
                    </span>
                  </div>
                  <div className="flex flex-col items-end pr-2">
                    <span className="text-[10px] text-slate-400 font-bold">รวมค่าใช้จ่ายทั้งสิ้น</span>
                    <span className="text-sm font-black text-cyan-400 font-mono mt-0.5">
                      {((selectedRepairDetail.usedParts?.reduce((sum, i) => sum + i.totalCost, 0) || 0) + (selectedRepairDetail.otherCost || 0)).toLocaleString()} บาท
                    </span>
                  </div>
                </div>
              </div>

              {/* Technicians & Image attachment */}
              <div className="flex flex-col sm:flex-row gap-5 bg-slate-900/20 p-4 rounded-xl border border-slate-750">
                <div className="flex-1">
                  <p className="text-slate-400 text-[10px] uppercase font-bold mb-2">👥 ทีมช่างเทคนิคผู้เข้าปฏิบัติการณ์</p>
                  <div className="flex flex-wrap gap-2">
                    {(selectedRepairDetail.technicians && selectedRepairDetail.technicians.length > 0 
                      ? selectedRepairDetail.technicians 
                      : [selectedRepairDetail.technician]
                    ).map(t => (
                      <span key={t} className="bg-slate-950 border border-slate-750 text-slate-300 px-3 py-1.5 rounded-lg font-semibold text-xs">
                        🔧 {t}
                      </span>
                    ))}
                  </div>
                </div>

                {selectedRepairDetail.photo && (
                  <div className="shrink-0 flex flex-col items-center">
                    <p className="text-slate-400 text-[10px] uppercase font-bold mb-2 text-center">หลักฐานแนบการซ่อม</p>
                    <img 
                      src={selectedRepairDetail.photo} 
                      alt="breakdown" 
                      className="w-24 h-24 object-cover rounded-lg border border-slate-700 hover:scale-[1.05] transition cursor-zoom-in" 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}
              </div>

              {selectedRepairDetail.excelFile && (
                <div className="bg-emerald-950/20 border border-emerald-900/40 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FileSpreadsheet className="text-emerald-400 shrink-0" size={24} />
                    <div className="text-left min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-[11px] font-bold text-emerald-300">ไฟล์แนบประกอบใบงาน</p>
                        {/why/i.test(selectedRepairDetail.excelFile.name) && (
                          <span className="px-2 py-0.5 rounded text-[9.5px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                            ❓ Why-Why Analysis
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 font-mono truncate max-w-[280px]" title={selectedRepairDetail.excelFile.name}>
                        {selectedRepairDetail.excelFile.name}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap shrink-0">
                    <button
                      type="button"
                      onClick={() => setPreviewPDF({
                        id: `preview-excel-${selectedRepairDetail.id}`,
                        name: selectedRepairDetail.excelFile!.name,
                        content: selectedRepairDetail.excelFile!.content,
                        fileType: 'excel',
                        size: 'ไฟล์แนบ Excel',
                        uploadedAt: selectedRepairDetail.date
                      })}
                      className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-[11px] px-3 py-2 rounded-lg transition border border-cyan-500/30 cursor-pointer"
                      title="ดูตัวอย่างเอกสาร Excel"
                    >
                      <Eye size={13} />
                      <span>ดูตัวอย่าง</span>
                    </button>
                    <a
                      href={selectedRepairDetail.excelFile.content}
                      download={selectedRepairDetail.excelFile.name}
                      className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] px-3.5 py-2 rounded-lg transition shadow-md whitespace-nowrap cursor-pointer"
                    >
                      <Upload size={14} className="rotate-180" />
                      ดาวน์โหลดไฟล์แนบ
                    </a>
                    {/* Link Why-Why directly to Kaizen Tab! */}
                    <button
                      type="button"
                      onClick={() => {
                        navigateToKaizen({
                          category: 'WHY_WHY',
                          machineId: selectedRepairDetail.machineId,
                          searchQuery: selectedRepairDetail.excelFile?.name || selectedRepairDetail.symptoms,
                          sourceRepairId: selectedRepairDetail.id
                        });
                        setSelectedRepairDetail(null);
                      }}
                      className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-extrabold text-[11px] px-3.5 py-2 rounded-lg transition shadow-md whitespace-nowrap cursor-pointer active:scale-95"
                      title="เปิดเอกสาร Why-Why นี้ในแถบ Why-Why Analysis ของหน้า Kaizen"
                    >
                      <ExternalLink size={13} />
                      <span>🚀 เปิดใน Why-Why (แถบ Kaizen)</span>
                    </button>
                  </div>
                </div>
              )}

              {/* FA / OPL / Kaizen Attachments & Kaizen Links Card */}
              {(() => {
                const atts = selectedRepairDetail.repairAttachments || [
                  ...(selectedRepairDetail.faFile ? [selectedRepairDetail.faFile] : []),
                  ...(selectedRepairDetail.oplFile ? [selectedRepairDetail.oplFile] : []),
                  ...(selectedRepairDetail.whyWhyFile ? [selectedRepairDetail.whyWhyFile] : []),
                  ...(selectedRepairDetail.kaizenFile ? [selectedRepairDetail.kaizenFile] : [])
                ];
                return (
                  <div className="bg-gradient-to-br from-slate-900/90 to-indigo-950/40 border border-indigo-500/30 p-4 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Paperclip className="text-indigo-400" size={18} />
                        <div>
                          <p className="text-[11px] font-bold text-slate-200">
                            เอกสารวิเคราะห์และปรับปรุง (FA / OPL / Why-Why / Kaizen)
                          </p>
                          <p className="text-[10px] text-slate-400">
                            {atts.length > 0 ? `แนบไว้ทั้งหมด ${atts.length} ไฟล์ พร้อมเชื่อมต่อไปยังหน้า Kaizen` : 'ยังไม่มีไฟล์แนบ สามารถกดเพิ่มได้ทันที'}
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setRepairForQuickAttachment(selectedRepairDetail)}
                        className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] px-3 py-1.5 rounded-lg transition shadow-sm cursor-pointer"
                      >
                        <Plus size={13} />
                        <span>แนบไฟล์เพิ่ม</span>
                      </button>
                    </div>

                    {atts.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {atts.map((att) => (
                          <div
                            key={att.id}
                            className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-xl flex items-center justify-between gap-2"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className={`px-2 py-0.5 rounded text-[9.5px] font-bold font-mono shrink-0 border ${
                                att.category === 'FA'
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                                  : att.category === 'OPL'
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                  : att.category === 'WHY_WHY'
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                  : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                              }`}>
                                {att.category === 'WHY_WHY' ? 'Why-Why' : att.category}
                              </span>
                              <div className="min-w-0">
                                <p className="text-slate-200 font-medium truncate text-[11px]" title={att.name}>
                                  {att.name}
                                </p>
                                <p className="text-[9.5px] text-slate-400 font-mono">
                                  {att.fileType.toUpperCase()} • {att.size || ''}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              {(att.fileType === 'pdf' || att.fileType === 'excel') && (
                                <button
                                  type="button"
                                  onClick={() => setPreviewPDF({
                                    id: att.id,
                                    name: att.name,
                                    content: att.content,
                                    fileType: att.fileType === 'excel' ? 'excel' : 'pdf',
                                    size: att.size,
                                    uploadedAt: att.uploadedAt
                                  })}
                                  className="p-1 text-slate-400 hover:text-cyan-400 hover:bg-slate-900 rounded transition cursor-pointer"
                                  title="เปิดดูตัวอย่างไฟล์"
                                >
                                  <Eye size={13} />
                                </button>
                              )}
                              <a
                                href={att.content}
                                download={att.name}
                                className="p-1 text-slate-400 hover:text-emerald-400 hover:bg-slate-900 rounded transition cursor-pointer"
                                title="ดาวน์โหลดไฟล์"
                              >
                                <Download size={13} />
                              </a>
                              <button
                                type="button"
                                onClick={() => handleNavigateToKaizenProject(att, selectedRepairDetail.machineId)}
                                className="px-2 py-1 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 hover:text-indigo-200 border border-indigo-500/40 rounded text-[10px] font-bold flex items-center gap-1 transition cursor-pointer"
                                title="เชื่อมโยงและเปิดดูในแถบ Kaizen"
                              >
                                <ExternalLink size={10} />
                                <span>ไป Kaizen</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                );
              })()}

              {/* Active CMMS Contextual Knowledge Assistant */}
              <ContextualKnowledgeAssistant
                machineId={selectedRepairDetail.machineId}
                symptoms={selectedRepairDetail.symptoms}
              />

            </div>

            {/* Footer control buttons */}
            <div className="p-5 bg-slate-900/80 border-t border-slate-700/80 flex justify-between items-center shrink-0">
              <button
                type="button"
                id={`detail-delete-btn-${selectedRepairDetail.id}`}
                onClick={() => {
                  const targetId = selectedRepairDetail.id;
                  setSelectedRepairDetail(null);
                  handleDeleteRepair(targetId);
                }}
                className="flex items-center gap-1.5 border border-rose-500/30 hover:bg-rose-600 hover:border-rose-500 hover:text-white text-rose-400 font-bold text-xs px-4 py-2 my-1 rounded-lg transition"
              >
                <Trash2 size={13} />
                ลบบันทึกประวัตินี้
              </button>

              <div className="flex flex-wrap gap-2.5">
                <button
                  type="button"
                  id={`detail-export-single-excel-${selectedRepairDetail.id}`}
                  onClick={() => handleExportSingleToExcel(selectedRepairDetail)}
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-lg transition shadow-md cursor-pointer"
                  title="ดาวน์โหลดใบบันทึกเชิงวิเคราะห์และสรุป Why-Why นี้ออกเป็นไฟล์ Excel (CSV)"
                >
                  <FileSpreadsheet size={13} />
                  ส่งออกใบวิเคราะห์ Excel
                </button>
                <button
                  type="button"
                  id={`detail-edit-btn-${selectedRepairDetail.id}`}
                  onClick={() => {
                    const currentLog = selectedRepairDetail;
                    setSelectedRepairDetail(null);
                    handleEditClick(currentLog);
                  }}
                  className="flex items-center gap-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs px-4.5 py-2 rounded-lg transition shadow-md"
                >
                  <Edit size={13} />
                  แก้ไขประวัติซ่อม
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRepairDetail(null)}
                  className="border border-slate-700 hover:bg-slate-700/90 text-slate-300 text-xs px-4 py-2 rounded-lg transition"
                >
                  ปิดหน้าต่าง
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MACHINE BREAKDOWN IMPORT MODAL */}
      <BreakdownImportModal
        isOpen={showBreakdownImportModal}
        onClose={() => setShowBreakdownImportModal(false)}
        machines={machines}
        technicians={technicians}
        onImportSuccess={(newRepairs, mode) => {
          if (mode === 'replace') {
            setRepairs(newRepairs);
            setSelectedIds(new Set());
            setToastMessage(`เขียนทับประวัติเบรกดาวน์สำเร็จ นำเข้าทั้งหมด ${newRepairs.length} รายการ`);
          } else {
            setRepairs(prev => [...newRepairs, ...prev]);
            setToastMessage(`เพิ่มประวัติเบรกดาวน์สำเร็จ ${newRepairs.length} รายการ`);
          }
          setTimeout(() => setToastMessage(null), 5000);
        }}
      />

      {/* Custom Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-4 animate-in fade-in duration-100">
          <div id="repair-delete-modal" className="bg-slate-900 border border-slate-750 p-6 rounded-2xl max-w-sm w-full space-y-4 shadow-2xl animate-in zoom-in-95 duration-100">
            <div className="flex items-center gap-3 text-rose-500 border-b border-slate-800 pb-3">
              <AlertTriangle size={24} className="text-rose-500 shrink-0" />
              <h3 className="text-sm font-extrabold text-slate-100">🚨 ยืนยันการลบประวัติงานซ่อม</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              คุณต้องการลบบันทึกวิเคราะห์งานซ่อมด่วนนี้ ใช่หรือไม่? ประวัติอาการเกิดเหตุและวิเคราะห์ Why-Why ทั้งหมดจะสูญหายอย่างถาวร
            </p>

            {/* Checkbox to delete linked Work Order */}
            <label className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={deleteLinkedWorkOrder}
                onChange={(e) => setDeleteLinkedWorkOrder(e.target.checked)}
                className="w-4 h-4 rounded text-rose-500 bg-slate-900 border-slate-700 cursor-pointer accent-rose-500 mt-0.5"
              />
              <div>
                <span className="font-bold text-white">ลบใบสั่งงาน Work Order ที่ผูกกับงานซ่อมนี้ด้วย</span>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  ป้องกันใบงานตกค้างในระบบ CMMS (ล้างทั้งใบงานฉุกเฉินและคิวนัดหมายที่ยังไม่เสร็จ)
                </p>
              </div>
            </label>

            <div className="flex gap-2.5 justify-end pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="border border-slate-700 hover:bg-slate-850 text-slate-300 text-xs px-4 py-2 rounded-lg transition cursor-pointer"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                id="btn-confirm-delete-action"
                onClick={() => {
                  const logToDelete = repairs.find(r => r.id === deleteConfirmId);
                  if (logToDelete && logToDelete.usedParts) {
                    let tempSpareParts = [...spareParts];
                    for (const op of logToDelete.usedParts) {
                      tempSpareParts = tempSpareParts.map(sp => {
                        if (sp.id === op.partId) {
                          return { ...sp, quantity: sp.quantity + op.quantity };
                        }
                        return sp;
                      });
                    }
                    setSpareParts(tempSpareParts);
                  }

                  if (deleteLinkedWorkOrder && logToDelete) {
                    const woId = logToDelete.workOrderId || logToDelete.workOrderNo;
                    setWorkOrders(prev => prev.filter(w => {
                      if (w.sourceRefId && w.sourceRefId === logToDelete.id) return false;
                      if (woId && (w.id === woId || w.workOrderNo === woId)) return false;
                      return true;
                    }));
                  }

                  setRepairs(prev => prev.filter(r => r.id !== deleteConfirmId));
                  setDeleteConfirmId(null);
                  showToast(`🗑️ ลบประวัติงานซ่อมเรียบร้อยแล้ว${deleteLinkedWorkOrder ? ' (พร้อมลบใบสั่งงาน WO ที่ผูกอยู่)' : ''}`);
                }}
                className="bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs px-4.5 py-2 rounded-lg transition cursor-pointer active:scale-95"
              >
                ยืนยันลบเด็ดขาด
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Confirmation Modal (ลบประวัติซ่อมแบบเลือกทั้งหมด) */}
      {isBulkDeleteModalOpen && selectedIds.size > 0 && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-4 animate-in fade-in duration-100">
          <div id="repair-bulk-delete-modal" className="bg-slate-900 border border-rose-500/40 p-6 rounded-2xl max-w-md w-full space-y-4 shadow-2xl animate-in zoom-in-95 duration-100">
            <div className="flex items-center gap-3 text-rose-500 border-b border-slate-800 pb-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                <Trash2 size={22} />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-slate-100">🚨 ยืนยันการลบประวัติงานซ่อมแบบกลุ่ม</h3>
                <p className="text-[11px] text-rose-400 font-semibold">ลบทั้งหมด {selectedIds.size} รายการที่เลือก</p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                คุณต้องการลบประวัติบันทึกงานซ่อมที่เลือกไว้จำนวน <strong className="text-rose-400 font-bold">{selectedIds.size} รายการ</strong> ใช่หรือไม่?
              </p>
              <div className="bg-rose-950/30 border border-rose-900/40 rounded-xl p-3 text-[11px] text-rose-200/90 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-rose-300">
                  <AlertTriangle size={13} />
                  <span>คำเตือน: การลบนี้ถาวรและไม่สามารถเรียกคืนได้</span>
                </div>
                <ul className="list-disc list-inside space-y-0.5 text-slate-400 pl-1">
                  <li>ข้อมูลการชำรุด, เวลา MTTR, และผลวิเคราะห์ Why-Why ทั้งหมดจะสูญหายถาวร</li>
                  <li>รายการอะไหล่ที่เคยถูกตัดสต็อกในงานซ่อมเหล่านี้ จะถูกนำกลับคืนเข้าคลังโดยอัตโนมัติ</li>
                </ul>
              </div>

              {/* Preview of items to be deleted */}
              <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1 mt-2">
                {repairs
                  .filter(r => selectedIds.has(r.id))
                  .slice(0, 5)
                  .map(r => (
                    <div key={r.id} className="bg-slate-850 p-2 rounded-lg border border-slate-750 text-[11px] flex justify-between items-center">
                      <div className="truncate mr-2">
                        <span className="font-mono text-cyan-400 font-bold mr-1.5">{r.machineId}</span>
                        <span className="text-slate-300 truncate">{r.symptoms}</span>
                      </div>
                      <span className="text-slate-400 font-mono shrink-0 text-[10px]">{r.date}</span>
                    </div>
                  ))}
                {selectedIds.size > 5 && (
                  <div className="text-center text-[10.5px] text-slate-400 italic py-1">
                    ... และอีก {selectedIds.size - 5} รายการ
                  </div>
                )}
              </div>

              {/* Checkbox to delete linked Work Orders */}
              <label className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 cursor-pointer select-none mt-2">
                <input
                  type="checkbox"
                  checked={deleteLinkedWorkOrder}
                  onChange={(e) => setDeleteLinkedWorkOrder(e.target.checked)}
                  className="w-4 h-4 rounded text-rose-500 bg-slate-900 border-slate-700 cursor-pointer accent-rose-500 mt-0.5"
                />
                <div>
                  <span className="font-bold text-white">ลบใบสั่งงาน Work Order ที่ผูกกับงานซ่อมเหล่านี้ด้วย</span>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    ป้องกันใบงานฉุกเฉินตกค้างในระบบ CMMS เมื่อประวัติงานซ่อมถูกลบ
                  </p>
                </div>
              </label>
            </div>

            <div className="flex gap-2.5 justify-end pt-3 border-t border-slate-800">
              <button
                type="button"
                id="btn-cancel-bulk-delete"
                onClick={() => setIsBulkDeleteModalOpen(false)}
                className="border border-slate-700 hover:bg-slate-850 text-slate-300 text-xs px-4 py-2 rounded-lg transition"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                id="btn-confirm-bulk-delete"
                onClick={handleConfirmBulkDelete}
                className="bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-extrabold text-xs px-5 py-2 rounded-lg transition flex items-center gap-1.5 shadow-lg shadow-rose-600/30"
              >
                <Trash2 size={13} />
                <span>ยืนยันลบทั้งหมด {selectedIds.size} รายการ</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Feedback */}
      {toastMsg && (
        <div className="fixed top-20 right-5 z-[110] bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2.5 animate-in fade-in slide-in-from-top-3">
          <Check className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-medium">{toastMsg}</span>
        </div>
      )}

      {/* Quick Attachment Modal (แนบและจัดการไฟล์ FA / OPL / Kaizen และเชื่อมต่อไปยังแถบ Kaizen) */}
      {repairForQuickAttachment && (
        <div className="fixed inset-0 z-[105] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-100">
          <div className="bg-slate-900 border border-indigo-500/40 p-6 rounded-2xl max-w-xl w-full space-y-4 shadow-2xl animate-in zoom-in-95 duration-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
                  <Paperclip size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-100 flex items-center gap-2">
                    <span>จัดการไฟล์แนบ FA / OPL / Why-Why / Kaizen</span>
                    <span className="font-mono text-cyan-400 bg-slate-800 px-2 py-0.5 rounded text-xs border border-slate-700">
                      {repairForQuickAttachment.machineId}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400 truncate max-w-sm" title={repairForQuickAttachment.symptoms}>
                    {repairForQuickAttachment.symptoms} ({repairForQuickAttachment.date})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRepairForQuickAttachment(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Category tabs */}
            <div className="flex gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
              {(['FA', 'OPL', 'WHY_WHY', 'KAIZEN'] as const).map(cat => {
                const count = (repairForQuickAttachment.repairAttachments || [
                  ...(repairForQuickAttachment.faFile ? [repairForQuickAttachment.faFile] : []),
                  ...(repairForQuickAttachment.oplFile ? [repairForQuickAttachment.oplFile] : []),
                  ...(repairForQuickAttachment.whyWhyFile ? [repairForQuickAttachment.whyWhyFile] : []),
                  ...(repairForQuickAttachment.kaizenFile ? [repairForQuickAttachment.kaizenFile] : [])
                ]).filter(a => a.category === cat).length;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setActiveAttachmentTab(cat)}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeAttachmentTab === cat
                        ? cat === 'FA'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                          : cat === 'OPL'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                          : cat === 'WHY_WHY'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm font-extrabold'
                          : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span>{cat === 'FA' ? '🔍 FA' : cat === 'OPL' ? '💡 OPL' : cat === 'WHY_WHY' ? '❓ Why-Why' : '🚀 Kaizen'}</span>
                    {count > 0 && (
                      <span className="w-4 h-4 rounded-full bg-slate-800 text-slate-200 text-[9px] flex items-center justify-center font-mono font-bold border border-slate-700">
                        {count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Dropzone & Clipboard Paste */}
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOverCategory(activeAttachmentTab); }}
              onDragLeave={() => setDragOverCategory(null)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOverCategory(null);
                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                  Array.from<File>(e.dataTransfer.files).forEach((file: File) => {
                    handleAttachmentUpload(file, activeAttachmentTab, repairForQuickAttachment);
                  });
                }
              }}
              onPaste={(e) => handlePasteEvent(e, activeAttachmentTab, repairForQuickAttachment)}
              tabIndex={0}
              className={`border-2 border-dashed p-4 rounded-xl text-center relative group transition cursor-pointer outline-none ${
                dragOverCategory === activeAttachmentTab
                  ? 'border-indigo-400 bg-indigo-950/50 ring-2 ring-indigo-500/50'
                  : 'border-slate-700 hover:border-indigo-500/60 bg-slate-950/60'
              }`}
            >
              <input
                type="file"
                multiple
                accept=".pdf, .xlsx, .xls, .csv, .doc, .docx, image/*"
                onChange={(e) => {
                  if (e.target.files) {
                    Array.from<File>(e.target.files).forEach((file: File) => {
                      handleAttachmentUpload(file, activeAttachmentTab, repairForQuickAttachment);
                    });
                    e.target.value = '';
                  }
                }}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <div className="flex flex-col items-center justify-center gap-1 pointer-events-none">
                <Upload size={20} className="text-indigo-400 mb-0.5" />
                <p className="text-xs font-semibold text-slate-200">
                  คลิก หรือ ลากวางไฟล์สำหรับ <strong className="text-indigo-300">{activeAttachmentTab === 'WHY_WHY' ? 'Why-Why Analysis' : activeAttachmentTab}</strong>
                </p>
                <p className="text-[10px] text-slate-400">
                  รองรับ PDF, Excel, Word, รูปภาพ หรือกดคลิกแล้วกด <span className="text-amber-400 font-mono">Ctrl+V</span> เพื่อวางไฟล์
                </p>
              </div>
            </div>

            {/* Current Attachments List */}
            {(() => {
              const currentAtts = repairForQuickAttachment.repairAttachments || [
                ...(repairForQuickAttachment.faFile ? [repairForQuickAttachment.faFile] : []),
                ...(repairForQuickAttachment.oplFile ? [repairForQuickAttachment.oplFile] : []),
                ...(repairForQuickAttachment.whyWhyFile ? [repairForQuickAttachment.whyWhyFile] : []),
                ...(repairForQuickAttachment.kaizenFile ? [repairForQuickAttachment.kaizenFile] : [])
              ];
              return (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                    <span>ไฟล์ที่แนบไว้ ({currentAtts.length} ไฟล์):</span>
                    <span className="text-[10.5px] text-indigo-400">ซิงค์ไปยังหน้า Kaizen เรียบร้อย</span>
                  </div>
                  {currentAtts.length > 0 ? (
                    <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                      {currentAtts.map(att => (
                        <div
                          key={att.id}
                          className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-xl flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold font-mono border ${
                              att.category === 'FA'
                                ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                                : att.category === 'OPL'
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                : att.category === 'WHY_WHY'
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                            }`}>
                              {att.category === 'WHY_WHY' ? 'Why-Why' : att.category}
                            </span>
                            <div className="min-w-0">
                              <p className="text-slate-200 font-medium truncate text-[11px]" title={att.name}>
                                {att.name}
                              </p>
                              <p className="text-[9.5px] text-slate-400 font-mono">
                                {att.fileType.toUpperCase()} • {att.size || ''}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {(att.fileType === 'pdf' || att.fileType === 'excel') && (
                              <button
                                type="button"
                                onClick={() => setPreviewPDF({
                                  id: att.id,
                                  name: att.name,
                                  content: att.content,
                                  fileType: att.fileType === 'excel' ? 'excel' : 'pdf',
                                  size: att.size,
                                  uploadedAt: att.uploadedAt
                                })}
                                className="p-1 text-slate-400 hover:text-cyan-400 rounded transition"
                                title="เปิดดูตัวอย่างไฟล์"
                              >
                                <Eye size={13} />
                              </button>
                            )}
                            <a
                              href={att.content}
                              download={att.name}
                              className="p-1 text-slate-400 hover:text-emerald-400 rounded transition"
                              title="ดาวน์โหลดไฟล์"
                            >
                              <Download size={13} />
                            </a>
                            <button
                              type="button"
                              onClick={() => handleNavigateToKaizenProject(att, repairForQuickAttachment.machineId)}
                              className="px-2 py-1 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded text-[10px] font-bold flex items-center gap-1 transition"
                              title="เชื่อมโยงและเปิดดูในแถบ Kaizen"
                            >
                              <ExternalLink size={10} />
                              <span>ไป Kaizen</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveAttachment(att.id, repairForQuickAttachment)}
                              className="p-1 text-slate-400 hover:text-rose-400 rounded transition"
                              title="ลบไฟล์แนบนี้"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-400 italic text-center py-4 bg-slate-950/40 rounded-xl border border-slate-800">
                      ยังไม่มีไฟล์แนบในประวัติงานซ่อมนี้
                    </p>
                  )}
                </div>
              );
            })()}

            <div className="flex justify-end pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setRepairForQuickAttachment(null)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-lg transition"
              >
                ปิดหน้าต่าง
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PDF & Excel Attachment Preview Modal */}
      {previewPDF && (
        <PDFViewerModal
          pdf={previewPDF}
          onClose={() => setPreviewPDF(null)}
        />
      )}

      {/* CMMS Work Order Detail Modal */}
      {isDetailWOModalOpen && selectedDetailWO && (
        <WorkOrderDetailModal
          isOpen={isDetailWOModalOpen}
          workOrder={selectedDetailWO}
          onClose={() => {
            setIsDetailWOModalOpen(false);
            setSelectedDetailWO(null);
          }}
        />
      )}
    </div>
  );
};
