import React, { useState, useMemo } from 'react';
import { Trash2, AlertTriangle, X, Search, ShieldAlert, CheckSquare, Layers, Wrench, CalendarDays, FileText } from 'lucide-react';
import { Machine } from '../../types';
import { getMachineCriticality } from '../../utils/tbmHelper';

interface BulkDeleteMachineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (deleteLinkedPlans: boolean) => void;
  selectedMachines: Machine[];
  affectedPmPlansCount: number;
  affectedRepairsCount: number;
  affectedSchedulesCount: number;
}

export const BulkDeleteMachineModal: React.FC<BulkDeleteMachineModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  selectedMachines,
  affectedPmPlansCount,
  affectedRepairsCount,
  affectedSchedulesCount,
}) => {
  const [deleteLinkedPlans, setDeleteLinkedPlans] = useState<boolean>(true);
  const [searchPreview, setSearchPreview] = useState<string>('');
  const [confirmText, setConfirmText] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Filter preview list
  const filteredPreview = useMemo(() => {
    if (!searchPreview.trim()) return selectedMachines;
    const q = searchPreview.toLowerCase();
    return selectedMachines.filter(
      m => m.id.toLowerCase().includes(q) ||
           m.name.toLowerCase().includes(q) ||
           (m.location && m.location.toLowerCase().includes(q))
    );
  }, [selectedMachines, searchPreview]);

  if (!isOpen) return null;

  const requiresTypingConfirm = selectedMachines.length >= 10;
  const isConfirmDisabled = requiresTypingConfirm && confirmText.trim().toUpperCase() !== 'DELETE';

  const handleExecute = () => {
    setIsSubmitting(true);
    try {
      onConfirm(deleteLinkedPlans);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="bg-slate-900 border border-rose-500/30 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-6">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-rose-950 via-rose-900 to-slate-900 border-b border-rose-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white flex items-center gap-2">
                <span>ยืนยันการลบเครื่องจักรแบบเลือกทั้งหมด</span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-rose-500 text-white">
                  {selectedMachines.length} เครื่อง
                </span>
              </h3>
              <p className="text-xs text-rose-200/80">
                ลบรายการเครื่องจักรที่เลือกออกจากทะเบียนเครื่องจักร (Machine Registry)
              </p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-4 text-xs">
          {/* Danger Warning Alert */}
          <div className="flex items-start gap-3 p-4 bg-rose-950/30 border border-rose-500/30 rounded-xl text-rose-200">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="font-bold text-sm text-rose-300">
                คำเตือน: การลบนี้จะมีผลต่อทะเบียนเครื่องจักรในระบบ
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                คุณกำลังจะลบเครื่องจักรจำนวน <strong className="text-rose-400 font-mono font-bold text-sm">{selectedMachines.length} เครื่อง</strong> ออกจากฐานข้อมูลส่วนกลางและระบบคลาวด์
              </p>
            </div>
          </div>

          {/* Impact Overview Stats */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 flex flex-col justify-between">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                <Layers size={13} className="text-cyan-400" />
                เครื่องจักรที่เลือกลบ
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-xl font-bold font-mono text-rose-400">{selectedMachines.length}</span>
                <span className="text-[10px] text-slate-500">เครื่อง</span>
              </div>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 flex flex-col justify-between">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                <FileText size={13} className="text-amber-400" />
                แผน PM ที่ผูกอยู่
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-xl font-bold font-mono text-amber-400">{affectedPmPlansCount}</span>
                <span className="text-[10px] text-slate-500">แผน</span>
              </div>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 flex flex-col justify-between">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                <Wrench size={13} className="text-indigo-400" />
                ประวัติซ่อม / กิจกรรม
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-xl font-bold font-mono text-indigo-300">{affectedRepairsCount + affectedSchedulesCount}</span>
                <span className="text-[10px] text-slate-500">รายการ</span>
              </div>
            </div>
          </div>

          {/* Cascade Option Checkbox */}
          {affectedPmPlansCount > 0 && (
            <label className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-800/90 border border-amber-500/30 cursor-pointer hover:border-amber-500/50 transition">
              <input 
                type="checkbox"
                checked={deleteLinkedPlans}
                onChange={(e) => setDeleteLinkedPlans(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded text-amber-500 bg-slate-900 border-slate-700 focus:ring-amber-400 cursor-pointer"
              />
              <div className="space-y-0.5">
                <span className="font-bold text-amber-300 block">
                  ลบแผนบำรุงรักษาเชิงป้องกัน (PM Plans) ที่ผูกกับเครื่องจักรเหล่านี้ออกด้วย ({affectedPmPlansCount} แผน)
                </span>
                <span className="text-slate-400 text-[11px] block">
                  หากเลือก จะทำการลบแผน PM ที่ผูกกับเครื่องเหล่านี้ออก เพื่อไม่ให้มีแผนงานค้างในระบบ
                </span>
              </div>
            </label>
          )}

          {/* Machine List Preview */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <span>รายชื่อเครื่องจักรที่จะถูกลบ:</span>
                <span className="text-[11px] font-mono text-cyan-400 bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
                  {filteredPreview.length} / {selectedMachines.length}
                </span>
              </span>
              {selectedMachines.length > 5 && (
                <div className="relative w-44">
                  <Search size={12} className="absolute left-2.5 top-2 text-slate-400" />
                  <input
                    type="text"
                    value={searchPreview}
                    onChange={(e) => setSearchPreview(e.target.value)}
                    placeholder="กรองดูในรายการ..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-7 pr-2 py-1 text-[11px] text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              )}
            </div>

            <div className="max-h-52 overflow-y-auto divide-y divide-slate-800 border border-slate-800 rounded-xl bg-slate-950/60 p-1">
              {filteredPreview.map((m) => {
                const crit = getMachineCriticality(m);
                return (
                  <div key={m.id} className="p-2 flex items-center justify-between gap-2 hover:bg-slate-900/80 rounded-lg transition">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <span className="font-mono font-bold text-cyan-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700/80 shrink-0 text-xs">
                        {m.id}
                      </span>
                      <span className={`text-[9px] font-bold font-mono px-1.5 py-0.2 rounded border uppercase shrink-0 ${crit.badgeClass}`}>
                        Rank {crit.shortLabel}
                      </span>
                      <span className="truncate text-slate-200 font-medium">
                        {m.name}
                      </span>
                    </div>
                    <span className="text-slate-400 text-[11px] truncate max-w-[140px] shrink-0 text-right">
                      {m.location || m.lineGroup || '-'}
                    </span>
                  </div>
                );
              })}
              {filteredPreview.length === 0 && (
                <div className="py-6 text-center text-slate-500">
                  ไม่พบรายการที่ค้นหา
                </div>
              )}
            </div>
          </div>

          {/* Safety type-in confirmation for large batches */}
          {requiresTypingConfirm && (
            <div className="p-3 bg-slate-800/80 border border-slate-700 rounded-xl space-y-1.5">
              <label className="text-slate-300 font-bold flex items-center gap-1.5 text-[11px]">
                <ShieldAlert size={14} className="text-rose-400" />
                เนื่องจากเลือกมากกว่า 10 เครื่อง กรุณาพิมพ์คำว่า <span className="text-rose-400 font-mono font-black">DELETE</span> เพื่อยืนยัน:
              </label>
              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="พิมพ์ DELETE"
                className="w-full bg-slate-900 border border-rose-500/40 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-rose-400"
              />
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl font-medium transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="button"
              onClick={handleExecute}
              disabled={isConfirmDisabled || isSubmitting}
              className={`px-5 py-2.5 rounded-xl font-bold shadow-md transition flex items-center gap-2 cursor-pointer ${
                isConfirmDisabled || isSubmitting
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white shadow-rose-900/30'
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span>
                {isSubmitting ? 'กำลังลบข้อมูล...' : `ยืนยันลบ ${selectedMachines.length} เครื่อง`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
