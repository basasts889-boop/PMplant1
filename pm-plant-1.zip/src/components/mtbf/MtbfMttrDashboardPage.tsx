import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { RoomConfig, RoomMachineConfig } from '../../types/mtbf';
import { OFFICIAL_MTBF_ROOMS, DEFAULT_PRODUCTION_TIME_MONTHLY_2026, DEFAULT_BASELINE_HISTORY } from '../../data/mtbfRooms';
import { calculateMTBFMTTRData, exportMtbfMttrToExcel } from '../../utils/mtbfCalculator';
import { MtbfSumView, DrillDownCellParams } from './MtbfSumView';
import { MtbfRoomView } from './MtbfRoomView';
import { ProductionTimeModal } from './ProductionTimeModal';
import { MachineMappingModal } from './MachineMappingModal';
import { BaselineEditModal } from './BaselineEditModal';
import { BreakdownCasesModal } from './BreakdownCasesModal';
import { BadActorReportView } from './BadActorReportView';
import { 
  BarChart3, Clock, Link2, History, FileSpreadsheet, 
  Filter, Calendar, ChevronRight, Layers, AlertTriangle, ShieldCheck,
  Flame, Calculator, Info, HelpCircle, Award
} from 'lucide-react';

export const MtbfMttrDashboardPage: React.FC = () => {
  const { repairs, machines, navigateToRepairs, settings, setSettings } = useApp();

  // Active view: 'SUM' or room id 'room-1'..'room-8'
  const [activeTab, setActiveTab] = useState<string>('SUM');

  // Rooms & machines configuration state (persisted to localStorage & Firestore settings)
  const [rooms, setRooms] = useState<RoomConfig[]>(() => {
    const isLegacyRooms = (rList: any[]) => {
      return rList.some((r: any) => 
        r.name === 'ห้องซุยข้าว' || 
        r.id === 'room-8' || 
        r.machines?.some((m: any) => m.id === 'FFS01' || m.id === 'RIM01' || m.id === 'ATS01')
      );
    };

    if (settings.mtbfRoomsConfig && Array.isArray(settings.mtbfRoomsConfig) && settings.mtbfRoomsConfig.length > 0) {
      if (!isLegacyRooms(settings.mtbfRoomsConfig)) {
        return settings.mtbfRoomsConfig;
      }
    }
    try {
      const saved = localStorage.getItem('mtbf_custom_rooms_config');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && !isLegacyRooms(parsed)) {
          return parsed;
        }
      }
    } catch {
      // ignore
    }
    // Clean legacy storage
    try {
      localStorage.removeItem('mtbf_custom_rooms_config');
    } catch {
      // ignore
    }
    return OFFICIAL_MTBF_ROOMS;
  });

  // Sync rooms if settings change from cloud
  useEffect(() => {
    if (settings.mtbfRoomsConfig && Array.isArray(settings.mtbfRoomsConfig) && settings.mtbfRoomsConfig.length > 0) {
      const isLegacy = settings.mtbfRoomsConfig.some((r: any) => 
        r.name === 'ห้องซุยข้าว' || 
        r.id === 'room-8' || 
        r.machines?.some((m: any) => m.id === 'FFS01' || m.id === 'RIM01')
      );
      if (!isLegacy) {
        setRooms(settings.mtbfRoomsConfig);
      }
    }
  }, [settings.mtbfRoomsConfig]);

  const handleUpdateRoomMachines = (roomId: string, newMachines: RoomMachineConfig[]) => {
    const updated = rooms.map(r => r.id === roomId ? { ...r, machines: newMachines } : r);
    setRooms(updated);
    try {
      localStorage.setItem('mtbf_custom_rooms_config', JSON.stringify(updated));
    } catch {
      // ignore
    }
    setSettings(prev => ({ ...prev, mtbfRoomsConfig: updated }));
  };

  const handleResetRoomMachines = (roomId: string) => {
    const defaultRoom = OFFICIAL_MTBF_ROOMS.find(r => r.id === roomId);
    if (!defaultRoom) return;
    handleUpdateRoomMachines(roomId, defaultRoom.machines);
  };

  // Year selector (default = 2026)
  const currentActualYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState<number>(2026);

  // Stoppage Type filter:
  // - ALL_BREAKDOWNS: นับเฉพาะ Breakdown (ไม่รวม Minor stoppage และ Adjustment loss ตามคำสั่งและมาตรฐาน TPM/CPRAM)
  // - PARTS_ONLY: นับเฉพาะ Breakdown ที่มีการเปลี่ยนอะไหล่
  const [stoppageFilter, setStoppageFilter] = useState<'ALL_BREAKDOWNS' | 'PARTS_ONLY'>('ALL_BREAKDOWNS');

  // Drilldown cases modal state
  const [activeDrillDown, setActiveDrillDown] = useState<DrillDownCellParams | null>(null);

  // Modals state
  const [showPTModal, setShowPTModal] = useState(false);
  const [showMappingModal, setShowMappingModal] = useState(false);
  const [showBaselineModal, setShowBaselineModal] = useState(false);

  // Production Time State (stored in localStorage)
  const [productionTimes, setProductionTimes] = useState<Record<string, number[]>>(() => {
    try {
      const saved = localStorage.getItem(`mtbf_pt_${selectedYear}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        const hasAllRooms = OFFICIAL_MTBF_ROOMS.every(r => Array.isArray(parsed[r.id]));
        const isLegacyPT = Object.values(parsed).some((arr: any) => 
          Array.isArray(arr) && arr.reduce((a: number, b: number) => a + b, 0) < 500
        );
        if (hasAllRooms && !isLegacyPT) return parsed;
      }
    } catch {
      // ignore
    }
    const def: Record<string, number[]> = {};
    OFFICIAL_MTBF_ROOMS.forEach(r => {
      def[r.id] = [...DEFAULT_PRODUCTION_TIME_MONTHLY_2026];
    });
    return def;
  });

  // MTBF Formula Mode state (Excel Standard: / N vs Statistical: / (N + 1))
  const [mtbfFormulaMode, setMtbfFormulaMode] = useState<'EXCEL_STANDARD' | 'STATISTICAL_PLUS_ONE'>('EXCEL_STANDARD');
  const [showFormulaInfo, setShowFormulaInfo] = useState(false);

  // Ranking Filter state: ค่าเริ่มต้น "เอาเฉพาะ Rank A มาคิด MTBF"
  const [rankingFilter, setRankingFilter] = useState<'A_ONLY' | 'ALL' | 'A_B'>('A_ONLY');

  // Reload PT when year changes
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`mtbf_pt_${selectedYear}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        const hasAllRooms = OFFICIAL_MTBF_ROOMS.every(r => Array.isArray(parsed[r.id]));
        const isLegacyPT = Object.values(parsed).some((arr: any) => 
          Array.isArray(arr) && arr.reduce((a: number, b: number) => a + b, 0) < 500
        );
        if (hasAllRooms && !isLegacyPT) {
          setProductionTimes(parsed);
          return;
        }
      }
    } catch {
      // ignore
    }
    const def: Record<string, number[]> = {};
    OFFICIAL_MTBF_ROOMS.forEach(r => {
      def[r.id] = [...DEFAULT_PRODUCTION_TIME_MONTHLY_2026];
    });
    setProductionTimes(def);
  }, [selectedYear]);

  // Save Production Times handler
  const handleSaveProductionTimes = (updated: Record<string, number[]>) => {
    setProductionTimes(updated);
    try {
      localStorage.setItem(`mtbf_pt_${selectedYear}`, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  // Custom Machine Mappings State (stored in localStorage)
  const [customMappings, setCustomMappings] = useState<Record<string, { roomId: string; machineId: string }>>(() => {
    try {
      const saved = localStorage.getItem('mtbf_machine_mappings');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {};
  });

  const handleSaveMappings = (newMappings: Record<string, { roomId: string; machineId: string }>) => {
    setCustomMappings(newMappings);
    try {
      localStorage.setItem('mtbf_machine_mappings', JSON.stringify(newMappings));
    } catch {
      // ignore
    }
  };

  // Baseline History State (stored in localStorage)
  const [baselineHistory, setBaselineHistory] = useState<typeof DEFAULT_BASELINE_HISTORY>(() => {
    try {
      const saved = localStorage.getItem('mtbf_baseline_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed[2025]?.breakdownMin?.length === OFFICIAL_MTBF_ROOMS.length) {
          return parsed;
        }
      }
    } catch {
      // ignore
    }
    return DEFAULT_BASELINE_HISTORY;
  });

  const handleSaveBaseline = (newBaseline: typeof DEFAULT_BASELINE_HISTORY) => {
    setBaselineHistory(newBaseline);
    try {
      localStorage.setItem('mtbf_baseline_history', JSON.stringify(newBaseline));
    } catch {
      // ignore
    }
  };

  // Run Calculations memoized
  const { roomMetrics, machineMetrics, sumMetrics, unmappedRepairs } = useMemo(() => {
    return calculateMTBFMTTRData({
      year: selectedYear,
      repairs,
      rooms,
      productionTimes,
      customMappings,
      stoppageFilter,
      baselineHistory,
      mtbfFormulaMode,
      rankingFilter
    });
  }, [selectedYear, repairs, rooms, productionTimes, customMappings, stoppageFilter, baselineHistory, mtbfFormulaMode, rankingFilter]);

  const activeRoom = rooms.find(r => r.id === activeTab) || null;
  const activeRoomMetric = roomMetrics.find(r => r.roomId === activeTab) || null;
  const activeRoomMachMetrics = activeRoom ? (machineMetrics[activeRoom.id] || []) : [];

  const handleExportExcel = () => {
    exportMtbfMttrToExcel({
      year: selectedYear,
      rooms,
      roomMetrics,
      sumMetrics,
      activeRoomId: activeTab === 'SUM' ? null : activeTab
    });
  };

  return (
    <div className="space-y-6 select-none" id="mtbf-dashboard-root">
      {/* 1. TOP HEADER & CONTROLS */}
      <div className="bg-[#0b1325]/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl backdrop-blur-xl space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Title & Brand */}
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 text-cyan-400 shadow-inner">
              <BarChart3 size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                  แดชบอร์ด Breakdown เครื่องจักรสะสม
                </h1>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 font-bold border border-cyan-800/40">
                  ระบบวิเคราะห์เวลาหยุดเครื่องจักร (Breakdown Dashboard)
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                คำนวณจากประวัติงานซ่อมบำรุงจริง (Repair Logs) เฉพาะกรณี Breakdown (ไม่นำ Minor stoppage และ Adjustment loss มาคิด MTTR / MTBF)
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Year selector */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs">
              <Calendar size={14} className="text-cyan-400 shrink-0" />
              <span className="text-slate-400 font-medium">ปี:</span>
              <select
                id="select-mtbf-year"
                value={selectedYear}
                onChange={(e) => setSelectedYear(parseInt(e.target.value, 10))}
                className="bg-transparent text-white font-mono font-bold focus:outline-none cursor-pointer"
              >
                <option value={2026} className="bg-slate-900">2026 (ปีปัจจุบัน)</option>
                <option value={2025} className="bg-slate-900">2025</option>
                <option value={2024} className="bg-slate-900">2024</option>
                <option value={2023} className="bg-slate-900">2023</option>
              </select>
            </div>

            {/* Breakdown Filter */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs">
              <Filter size={14} className="text-cyan-400 shrink-0" />
              <span className="text-slate-400 font-medium">เกณฑ์นับ:</span>
              <select
                id="select-stoppage-filter"
                value={stoppageFilter}
                onChange={(e) => setStoppageFilter(e.target.value as any)}
                className="bg-transparent text-white font-medium focus:outline-none cursor-pointer max-w-[210px] truncate"
              >
                <option value="ALL_BREAKDOWNS" className="bg-slate-900">เฉพาะ Breakdown (ไม่รวม Minor/Adjust)</option>
                <option value="PARTS_ONLY" className="bg-slate-900">เฉพาะ Breakdown ที่เปลี่ยนอะไหล่</option>
              </select>
            </div>

            {/* Machine Ranking Filter: ค่าเริ่มต้น เอาเฉพาะ Rank A มาคิด MTBF */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-amber-500/50 text-xs shadow-sm shadow-amber-500/10">
              <Award size={14} className="text-amber-400 shrink-0" />
              <span className="text-slate-400 font-medium">Ranking:</span>
              <select
                id="select-ranking-filter"
                value={rankingFilter}
                onChange={(e) => setRankingFilter(e.target.value as any)}
                className="bg-transparent text-amber-300 font-bold focus:outline-none cursor-pointer max-w-[210px]"
                title="เกณฑ์ Ranking เครื่องจักรสำหรับคำนวณ MTBF (ค่าเริ่มต้น: เอาเฉพาะ Rank A เครื่องวิกฤต)"
              >
                <option value="A_ONLY" className="bg-slate-900 text-amber-300 font-bold">
                  ⭐ เฉพาะ Rank A (เครื่องวิกฤต)
                </option>
                <option value="A_B" className="bg-slate-900 text-slate-300">
                  Rank A + B
                </option>
                <option value="ALL" className="bg-slate-900 text-slate-400">
                  ทุก Ranking (A, B, C)
                </option>
              </select>
            </div>

            {/* MTBF Formula Mode Switcher */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs">
              <Calculator size={14} className="text-emerald-400 shrink-0" />
              <span className="text-slate-400 font-medium">สูตร MTBF:</span>
              <select
                id="select-mtbf-formula"
                value={mtbfFormulaMode}
                onChange={(e) => setMtbfFormulaMode(e.target.value as any)}
                className="bg-transparent text-emerald-300 font-bold focus:outline-none cursor-pointer max-w-[190px]"
                title="สูตรคำนวณ MTBF ใน Excel: หาร N โดยตรง (เมื่อ N=0 ให้เป็นเวลาเดินเครื่องเต็ม) หรือสูตรสถิติ (หาร N+1)"
              >
                <option value="EXCEL_STANDARD" className="bg-slate-900 text-emerald-400">
                  สูตร Excel โรงงาน (หาร N)
                </option>
                <option value="STATISTICAL_PLUS_ONE" className="bg-slate-900 text-slate-300">
                  สูตรสถิติ (หาร N+1)
                </option>
              </select>
              <button
                type="button"
                onClick={() => setShowFormulaInfo(!showFormulaInfo)}
                className="p-1 text-slate-400 hover:text-emerald-300 transition cursor-pointer"
                title="ดูคำอธิบายสูตร Excel และที่มาของ 558 ชั่วโมง"
              >
                <HelpCircle size={14} />
              </button>
            </div>

            {/* Production Time button */}
            <button
              type="button"
              id="btn-open-pt-modal"
              onClick={() => setShowPTModal(true)}
              className="px-3 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              title="ตั้งค่าชั่วโมงการผลิตรายห้องรายเดือน (เช่น มกราคม 558 ชม.)"
            >
              <Clock size={14} className="text-cyan-400" />
              <span>Production Time</span>
            </button>

            {/* Mapping button */}
            <button
              type="button"
              id="btn-open-mapping-modal"
              onClick={() => setShowMappingModal(true)}
              className="px-3 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              title="ตั้งค่าจับคู่เครื่องจักรกับห้อง"
            >
              <Link2 size={14} className="text-cyan-400" />
              <span>Mapping เครื่อง</span>
              {unmappedRepairs.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-slate-950 font-bold text-[10px]">
                  {unmappedRepairs.length}
                </span>
              )}
            </button>

            {/* Baseline button */}
            <button
              type="button"
              id="btn-open-baseline-modal"
              onClick={() => setShowBaselineModal(true)}
              className="px-3 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              title="ตรวจสอบและแก้ไข Baseline ย้อนหลัง 2023-2025"
            >
              <History size={14} className="text-amber-400" />
              <span>Baseline</span>
            </button>

            {/* Export Excel button */}
            <button
              type="button"
              id="btn-export-mtbf-excel"
              onClick={handleExportExcel}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <FileSpreadsheet size={15} />
              <span>Export Excel</span>
            </button>
          </div>
        </div>

        {/* Formula Guide Info Banner */}
        {showFormulaInfo && (
          <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs space-y-2.5 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-300 font-bold">
                <Info size={16} />
                <span>คำอธิบายสูตร Excel, เวลา 558 ชั่วโมง, และเกณฑ์ Ranking:</span>
              </div>
              <button
                type="button"
                onClick={() => setShowFormulaInfo(false)}
                className="text-slate-400 hover:text-white cursor-pointer text-xs"
              >
                ✕ ปิด
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-slate-300 text-[11px] leading-relaxed">
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <p className="font-bold text-cyan-300 mb-1">⏱️ 1. ที่มา Production Time 558 ชม.</p>
                <p>
                  • <b>สูตรคำนวณ:</b> <code className="text-cyan-200 bg-slate-900 px-1 py-0.5 rounded">31 วัน × 18 ชม./วัน = 558 ชม.</code> (โรงงานเดินเครื่อง 18 ชม./วัน หรือ 24 ชม. หักเวลาล้าง/หยุดตามแผน 6 ชม.)
                </p>
                <p className="mt-1">
                  • <b>ทั้งปี 12 เดือน:</b> รวม 365 วัน × 18 ชม. = <b>6,570 ชั่วโมง</b> (ม.ค. 558, ก.พ. 504, มี.ค. 558, เม.ย. 540...)
                </p>
              </div>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <p className="font-bold text-emerald-300 mb-1">📐 2. สูตร MTBF ในไฟล์ Excel</p>
                <p>
                  • <b>สูตรคำนวณ:</b> <code className="text-emerald-200 bg-slate-900 px-1 py-0.5 rounded">=IF(N=0, PT, (PT - (BD/60)) / N)</code>
                </p>
                <p className="mt-1">
                  • <b>ตัวหาร:</b> เมื่อเกิดเบรกดาวน์ $N$ ครั้ง จะหารด้วย $N$ ตรงๆ (เช่น เกิด 1 ครั้ง หาร 1 ไม่ใช่หาร 2) และเมื่อ $N=0$ ค่า MTBF จะเท่ากับเวลาเดินเครื่องทั้งหมด
                </p>
              </div>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-amber-900/40">
                <p className="font-bold text-amber-300 mb-1">⭐ 3. เกณฑ์เฉพาะเครื่องจักร Rank A</p>
                <p>
                  • <b>ตามมาตรฐาน TPM:</b> การวัดค่า MTBF และ MTTR เน้นประเมินที่ <b>เครื่องจักรวิกฤต (Critical Equipment / Bottleneck) Rank A</b> เท่านั้น
                </p>
                <p className="mt-1">
                  • ระบบจึงตั้งค่าเริ่มต้นให้ <b>นำเฉพาะเครื่องจักร Rank A มาคิด MTBF</b> และสามารถเลือกดูเครื่อง Rank อื่นๆ ผ่านตัวเลือก Ranking ด้านบนได้
                </p>
              </div>
            </div>
          </div>
        )}

        {/* 2. NAVIGATION TABS: BAD ACTOR + SUM + 8 ROOMS */}
        <div className="border-t border-slate-800/80 pt-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin" id="mtbf-tabs-nav">
            {/* Bad Actor Report Tab */}
            <button
              type="button"
              id="tab-btn-bad-actor"
              onClick={() => setActiveTab('BAD_ACTOR')}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'BAD_ACTOR'
                  ? 'bg-gradient-to-r from-rose-500 via-red-500 to-amber-500 text-slate-950 shadow-lg shadow-rose-500/25 ring-1 ring-rose-300'
                  : 'bg-slate-900/80 text-rose-300 hover:text-white hover:bg-slate-800 border border-rose-900/40'
              }`}
            >
              <Flame size={16} className={activeTab === 'BAD_ACTOR' ? 'text-slate-950' : 'text-rose-400'} />
              <span>🚨 Bad Actor Report</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                activeTab === 'BAD_ACTOR' ? 'bg-slate-950/20 text-slate-950' : 'bg-rose-950 text-rose-300 border border-rose-800'
              }`}>
                Pareto 80/20
              </span>
            </button>

            {/* SUM Tab */}
            <button
              type="button"
              id="tab-btn-sum"
              onClick={() => setActiveTab('SUM')}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'SUM'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-lg shadow-cyan-500/25 ring-1 ring-cyan-300'
                  : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Layers size={16} />
              <span>SUM (ภาพรวมทุกห้อง)</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                activeTab === 'SUM' ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-cyan-400'
              }`}>
                {rooms.length} ห้อง
              </span>
            </button>

            {/* Room Tabs */}
            {rooms.map((rm, idx) => {
              const isSelected = activeTab === rm.id;
              const rMetric = roomMetrics.find(r => r.roomId === rm.id);
              const bdCount = rMetric ? rMetric.ytd.breakdownCount : 0;

              return (
                <button
                  key={rm.id}
                  id={`tab-btn-${rm.id}`}
                  onClick={() => setActiveTab(rm.id)}
                  className={`px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-lg shadow-cyan-500/25 ring-1 ring-cyan-300'
                      : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <span className="text-[11px] opacity-75 font-mono">0{idx + 1}</span>
                  <span>{rm.name}</span>
                  {bdCount > 0 && (
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-md ${
                      isSelected ? 'bg-slate-950 text-cyan-300 font-bold' : 'bg-slate-800 text-rose-300'
                    }`}>
                      {bdCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Unmapped repairs warning banner (if any) */}
      {unmappedRepairs.length > 0 && (
        <div className="p-3.5 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-xs text-amber-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <AlertTriangle size={16} className="text-amber-400 shrink-0" />
            <span>
              พบประวัติงานซ่อม <strong>{unmappedRepairs.length} รายการ</strong> ที่รหัสเครื่องจักรยังไม่ถูกจับคู่เข้าห้อง
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowMappingModal(true)}
            className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition cursor-pointer whitespace-nowrap"
          >
            เปิดหน้าตั้งค่า Mapping
          </button>
        </div>
      )}

      {/* 3. MAIN CONTENT: BAD ACTOR, SUM OR ROOM VIEW */}
      {activeTab === 'BAD_ACTOR' ? (
        <BadActorReportView
          year={selectedYear}
          rooms={rooms}
          repairs={repairs}
          machines={machines}
        />
      ) : activeTab === 'SUM' ? (
        <MtbfSumView
          year={selectedYear}
          rooms={rooms}
          roomMetrics={roomMetrics}
          sumMetrics={sumMetrics}
          onSelectRoom={(roomId) => setActiveTab(roomId)}
          onDrillDown={(params) => {
            navigateToRepairs({
              targetRepairIds: params.repairIds || [],
              filterTitle: params.title,
              sourcePage: 16,
              isBaseline: params.isBaseline,
              baselineYear: params.baselineYear,
              baselineBDMin: params.baselineBDMin,
              baselineCount: params.baselineCount
            });
          }}
        />
      ) : (
        activeRoom && activeRoomMetric && (
          <MtbfRoomView
            year={selectedYear}
            room={activeRoom}
            roomMetric={activeRoomMetric}
            machinesMetrics={activeRoomMachMetrics}
            allRegisteredMachines={machines}
            repairs={repairs}
            onBackToSum={() => setActiveTab('SUM')}
            onOpenProductionTimeModal={() => setShowPTModal(true)}
            onUpdateRoomMachines={handleUpdateRoomMachines}
            onResetRoomMachines={handleResetRoomMachines}
            onDrillDown={(params) => {
              navigateToRepairs({
                targetRepairIds: params.repairIds || [],
                filterTitle: params.title,
                sourcePage: 16,
                isBaseline: params.isBaseline,
                baselineYear: params.baselineYear,
                baselineBDMin: params.baselineBDMin,
                baselineCount: params.baselineCount
              });
            }}
          />
        )
      )}

      {/* 4. MODALS */}
      {activeDrillDown && (
        <BreakdownCasesModal
          isOpen={Boolean(activeDrillDown)}
          onClose={() => setActiveDrillDown(null)}
          title={activeDrillDown.title}
          scopeLabel={activeDrillDown.scopeLabel}
          timeLabel={activeDrillDown.timeLabel}
          metricLabel={activeDrillDown.metricLabel}
          cellValue={activeDrillDown.cellValue}
          repairIds={activeDrillDown.repairIds}
          allRepairs={repairs}
          machines={machines}
          isBaseline={activeDrillDown.isBaseline}
          baselineYear={activeDrillDown.baselineYear}
          baselineBDMin={activeDrillDown.baselineBDMin}
          baselineCount={activeDrillDown.baselineCount}
          onNavigateToRepairsPage={(targetIds, filterTitle) => {
            navigateToRepairs({
              targetRepairIds: targetIds,
              filterTitle: filterTitle,
              sourcePage: 16
            });
          }}
        />
      )}
      {showPTModal && (
        <ProductionTimeModal
          isOpen={showPTModal}
          onClose={() => setShowPTModal(false)}
          year={selectedYear}
          rooms={rooms}
          productionTimes={productionTimes}
          onSave={handleSaveProductionTimes}
        />
      )}

      {showMappingModal && (
        <MachineMappingModal
          isOpen={showMappingModal}
          onClose={() => setShowMappingModal(false)}
          rooms={rooms}
          repairs={repairs}
          customMappings={customMappings}
          onSaveMappings={handleSaveMappings}
        />
      )}

      {showBaselineModal && (
        <BaselineEditModal
          isOpen={showBaselineModal}
          onClose={() => setShowBaselineModal(false)}
          rooms={rooms}
          baselineHistory={baselineHistory}
          onSaveBaseline={handleSaveBaseline}
        />
      )}
    </div>
  );
};
