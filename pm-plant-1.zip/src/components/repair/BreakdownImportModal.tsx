import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { Machine, RepairLog, StoppageType, detectStoppageType } from '../../types';
import { PLANT_REGISTRY_BREAKDOWNS } from '../../data/plantBreakdowns';
import { 
  X, UploadCloud, FileSpreadsheet, CheckCircle, AlertTriangle, 
  Trash2, Database, Download, RefreshCw, CheckCircle2, ShieldCheck, 
  Clock, Wrench, Sparkles, Filter, ChevronRight, FileText, Search
} from 'lucide-react';

interface BreakdownImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  machines: Machine[];
  technicians: string[];
  onImportSuccess: (importedRepairs: RepairLog[], mode: 'replace' | 'append') => void;
}

export const BreakdownImportModal: React.FC<BreakdownImportModalProps> = ({
  isOpen,
  onClose,
  machines,
  technicians,
  onImportSuccess
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState('');
  const [importMode, setImportMode] = useState<'replace' | 'append'>('replace');
  const [previewLogs, setPreviewLogs] = useState<RepairLog[]>([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStoppage, setFilterStoppage] = useState<'ALL' | 'BREAKDOWN' | 'MINOR_STOPPAGE'>('ALL');

  if (!isOpen) return null;

  // Helper to resolve machine info
  const getMachineInfo = (id: string) => {
    const cleanId = (id || '').trim().toLowerCase();
    return machines.find(m => m.id.trim().toLowerCase() === cleanId) ||
           machines.find(m => m.id.replace(/[-_]/g, '').toLowerCase() === cleanId.replace(/[-_]/g, ''));
  };

  // 1. Load 32 Authentic Plant Breakdowns Preset
  const handleLoadPresetBreakdowns = () => {
    setFileName('ชุดข้อมูลเบรกดาวน์ 32 รายการจริงจากเอกสาร (32 Records)');
    setPreviewLogs([...PLANT_REGISTRY_BREAKDOWNS]);
    setErrorMessage('');
  };

  // 2. Download 32-column Template
  const handleDownloadTemplate = (type: 'xlsx' | 'csv') => {
    const templateData = [
      {
        "ลำดับ": 1,
        "เครื่องจักร": "โถฟีดโรล",
        "ID.Number": "FR1202P",
        "ฝ่าย": "ผลิตเค้ก",
        "RANK": "B",
        "วัน เวลา ที่ได้รับแจ้ง": "12 January 2569 18:30 น.",
        "อาการ": "ฟีดไส้ไม่ออก",
        "ชิ้นส่วน": "มอเตอร์",
        "ปรากฏการณ์/ กระบวนการขัดข้อง": "มอเตอร์ช็อต",
        "ผู้ทำการแก้ไข": "ช่างเซฟ",
        "เวลาเครื่องหยุด (ชั่วโมง : นาที)": "0 วัน 01 ชั่วโมง 00 นาที",
        "เวลาแก้ไขจริง (นาที)": 20,
        "เวลารอคอยอะไหล่ (นาที)": 40,
        "เวลารวม (นาที)": 60,
        "วัน เวลา แก้ไขเสร็จ": "12 January 2569 19:30 น.",
        "BD PF Non": "Breakdown",
        "ปัจจัยการเกิด BD": "Miss Maintenance",
        "BD แยกระบบ": "Electrical",
        "ความรุนแรง": "Hard",
        "สาเหตุ": "มีน้ำมันเกียร์ไหลซึมเข้ามอเตอร์เลยทำให้ช็อต",
        "มาตรการแก้ไข/ ป้องกัน": "ทำการเปลี่ยนมอเตอร์ใหม่",
        "หมายเหตุ": ""
      },
      {
        "ลำดับ": 2,
        "เครื่องจักร": "เครื่องขึ้นรูป Rheon",
        "ID.Number": "RH1501F",
        "ฝ่าย": "ผลิตขนมปัง",
        "RANK": "A",
        "วัน เวลา ที่ได้รับแจ้ง": "12 January 2569 07:30 น.",
        "อาการ": "ชัตเตอร์ไม่ทำงานสะดุด",
        "ชิ้นส่วน": "encoder",
        "ปรากฏการณ์/ กระบวนการขัดข้อง": "encoder สกปรก",
        "ผู้ทำการแก้ไข": "ช่างเฟิส",
        "เวลาเครื่องหยุด (ชั่วโมง : นาที)": "0 วัน 02 ชั่วโมง 00 นาที",
        "เวลาแก้ไขจริง (นาที)": 100,
        "เวลารอคอยอะไหล่ (นาที)": 20,
        "เวลารวม (นาที)": 120,
        "วัน เวลา แก้ไขเสร็จ": "12 January 2569 09:30 น.",
        "BD PF Non": "Breakdown",
        "ปัจจัยการเกิด BD": "Miss Maintenance",
        "BD แยกระบบ": "Electrical",
        "ความรุนแรง": "Hard",
        "สาเหตุ": "encoder ทำงานขัดข้อง",
        "มาตรการแก้ไข/ ป้องกัน": "ถอด encoder ออกทำความสะอาด ประกอบคืน",
        "หมายเหตุ": ""
      },
      {
        "ลำดับ": 3,
        "เครื่องจักร": "เครื่อง Pack Kawashima",
        "ID.Number": "PK1502J",
        "ฝ่าย": "ผลิตขนมปัง",
        "RANK": "A",
        "วัน เวลา ที่ได้รับแจ้ง": "28 January 2569 09:30 น.",
        "อาการ": "Alarm supply 24 vdc",
        "ชิ้นส่วน": "supply 24 vdc",
        "ปรากฏการณ์/ กระบวนการขัดข้อง": "switching 24 vdc ไม่จ่าย out put",
        "ผู้ทำการแก้ไข": "ช่างเทค",
        "เวลาเครื่องหยุด (ชั่วโมง : นาที)": "0 วัน 00 ชั่วโมง 30 นาที",
        "เวลาแก้ไขจริง (นาที)": 10,
        "เวลารอคอยอะไหล่ (นาที)": 20,
        "เวลารวม (นาที)": 30,
        "วัน เวลา แก้ไขเสร็จ": "28 January 2569 10:00 น.",
        "BD PF Non": "Breakdown",
        "ปัจจัยการเกิด BD": "Miss Maintenance",
        "BD แยกระบบ": "Electrical",
        "ความรุนแรง": "Medium",
        "สาเหตุ": "ไดโอดของบอร์ดควบคุม switching 24 vdc ระเบิด",
        "มาตรการแก้ไข/ ป้องกัน": "ทำการเปลี่ยน switching 24 vdc ใหม่",
        "หมายเหตุ": ""
      },
      {
        "ลำดับ": 7,
        "เครื่องจักร": "Blast Chill",
        "ID.Number": "BC2104C",
        "ฝ่าย": "สนับสนุน",
        "RANK": "B",
        "วัน เวลา ที่ได้รับแจ้ง": "20 February 2569 10:30 น.",
        "อาการ": "อุณหภูมิสูง",
        "ชิ้นส่วน": "น้ำยา404",
        "ปรากฏการณ์/ กระบวนการขัดข้อง": "น้ำยาขาด",
        "ผู้ทำการแก้ไข": "ช่างเกื้อ",
        "เวลาเครื่องหยุด (ชั่วโมง : นาที)": "0 วัน 01 ชั่วโมง 50 นาที",
        "เวลาแก้ไขจริง (นาที)": 100,
        "เวลารอคอยอะไหล่ (นาที)": 10,
        "เวลารวม (นาที)": 110,
        "วัน เวลา แก้ไขเสร็จ": "20 February 2569 12:20 น.",
        "BD PF Non": "ขัดข้อง",
        "ปัจจัยการเกิด BD": "Miss Maintenance",
        "BD แยกระบบ": "Refrig & Pipe",
        "ความรุนแรง": "ขัดข้อง",
        "สาเหตุ": "น้ำยาขาด",
        "มาตรการแก้ไข/ ป้องกัน": "ตรวจเช็คน้ำยาทำความเย็นและทำการเติมน้ำยาเพิ่ม",
        "หมายเหตุ": ""
      }
    ];

    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Breakdown_32_Template");
    
    if (type === 'xlsx') {
      XLSX.writeFile(wb, "Machine_Breakdown_32_Template.xlsx");
    } else {
      XLSX.writeFile(wb, "Machine_Breakdown_32_Template.csv", { bookType: 'csv' });
    }
  };

  // Helper for parsing Thai / English datetime with Buddhist era support
  const parseDateTimeWithBuddhistEra = (val: any): { dateStr: string; isoDateTime: string } => {
    if (!val) {
      const today = new Date().toISOString().split('T')[0];
      return { dateStr: today, isoDateTime: `${today}T08:00` };
    }

    if (typeof val === 'number') {
      const dateObj = XLSX.SSF.parse_date_code(val);
      if (dateObj) {
        let y = dateObj.y;
        if (y > 2400) y -= 543;
        const m = String(dateObj.m).padStart(2, '0');
        const d = String(dateObj.d).padStart(2, '0');
        const hh = String(dateObj.H || 8).padStart(2, '0');
        const mm = String(dateObj.M || 0).padStart(2, '0');
        const dStr = `${y}-${m}-${d}`;
        return { dateStr: dStr, isoDateTime: `${dStr}T${hh}:${mm}` };
      }
    }

    const str = String(val).trim();

    const thaiMonths: Record<string, string> = {
      'มกราคม': '01', 'ม.ค.': '01', 'january': '01', 'jan': '01',
      'กุมภาพันธ์': '02', 'ก.พ.': '02', 'february': '02', 'feb': '02',
      'มีนาคม': '03', 'มี.ค.': '03', 'march': '03', 'mar': '03',
      'เมษายน': '04', 'เม.ย.': '04', 'april': '04', 'apr': '04',
      'พฤษภาคม': '05', 'พ.ค.': '05', 'may': '05',
      'มิถุนายน': '06', 'มิ.ย.': '06', 'june': '06', 'jun': '06',
      'กรกฎาคม': '07', 'ก.ค.': '07', 'july': '07', 'jul': '07',
      'สิงหาคม': '08', 'ส.ค.': '08', 'august': '08', 'aug': '08',
      'กันยายน': '09', 'ก.ย.': '09', 'september': '09', 'sep': '09',
      'ตุลาคม': '10', 'ต.ค.': '10', 'october': '10', 'oct': '10',
      'พฤศจิกายน': '11', 'พ.ย.': '11', 'november': '11', 'nov': '11',
      'ธันวาคม': '12', 'ธ.ค.': '12', 'december': '12', 'dec': '12'
    };

    const cleanStr = str.replace(/[น.]/g, '').trim();
    const parts = cleanStr.split(/\s+/);
    if (parts.length >= 3) {
      const day = parts[0].padStart(2, '0');
      const mWord = parts[1].toLowerCase();
      const mNum = thaiMonths[mWord];
      let yNum = parseInt(parts[2], 10);
      if (yNum > 2400) yNum -= 543;

      let time = '08:00';
      if (parts[3] && parts[3].includes(':')) {
        time = parts[3].slice(0, 5);
      }

      if (mNum && !isNaN(yNum) && yNum > 2000) {
        const dStr = `${yNum}-${mNum}-${day}`;
        return { dateStr: dStr, isoDateTime: `${dStr}T${time}` };
      }
    }

    if (/^\d{4}-\d{2}-\d{2}/.test(str)) {
      const dStr = str.slice(0, 10);
      const time = str.length >= 16 ? str.slice(11, 16) : '08:00';
      return { dateStr: dStr, isoDateTime: `${dStr}T${time}` };
    }

    const today = new Date().toISOString().split('T')[0];
    return { dateStr: today, isoDateTime: `${today}T08:00` };
  };

  // Helper for duration
  const parseDurationMinutes = (row: any): number => {
    const rawTot = row['เวลารวม (นาที)'] || row['เวลารวม'] || row['ระยะเวลาหยุดเครื่อง (นาที)'] || row['duration'] || row['Downtime'];
    if (rawTot !== undefined && rawTot !== '' && !isNaN(Number(rawTot))) {
      return Number(rawTot);
    }

    const act = Number(row['เวลาแก้ไขจริง (นาที)'] || row['เวลาแก้ไขจริง'] || 0) || 0;
    const wait = Number(row['เวลารอคอยอะไหล่ (นาที)'] || row['เวลารอคอยอะไหล่'] || 0) || 0;
    if (act + wait > 0) {
      return act + wait;
    }

    const rawStop = String(row['เวลาเครื่องหยุด (ชั่วโมง : นาที)'] || row['เวลาเครื่องหยุด'] || '');
    if (rawStop) {
      const dMatch = rawStop.match(/(\d+)\s*วัน/);
      const hMatch = rawStop.match(/(\d+)\s*ชั่วโมง/);
      const mMatch = rawStop.match(/(\d+)\s*นาที/);
      let totalMins = 0;
      if (dMatch) totalMins += parseInt(dMatch[1], 10) * 24 * 60;
      if (hMatch) totalMins += parseInt(hMatch[1], 10) * 60;
      if (mMatch) totalMins += parseInt(mMatch[1], 10);
      if (totalMins > 0) return totalMins;
    }

    return 60;
  };

  // Helper for Stoppage Type
  const parseStoppageType = (row: any, dur: number): StoppageType => {
    const bdPfNon = String(
      row['BD PF Non'] || row['BD/PF/Non'] || row['stoppageType'] || row['ประเภทการหยุด'] || ''
    ).trim().toLowerCase();
    
    if (bdPfNon.includes('ขัดข้อง') || bdPfNon.includes('minor') || bdPfNon.includes('pf')) {
      return 'MINOR_STOPPAGE';
    }
    if (bdPfNon.includes('breakdown') || bdPfNon.includes('bd')) {
      return 'BREAKDOWN';
    }
    const severity = String(row['ความรุนแรง'] || '').trim().toLowerCase();
    if (severity.includes('ขัดข้อง')) {
      return 'MINOR_STOPPAGE';
    }
    return dur >= 60 ? 'BREAKDOWN' : 'MINOR_STOPPAGE';
  };

  // 3. Process File Upload (Excel, CSV, JSON)
  const processFile = async (file: File) => {
    setIsLoading(true);
    setErrorMessage('');
    setFileName(file.name);

    try {
      const ext = file.name.split('.').pop()?.toLowerCase();

      if (ext === 'json') {
        const text = await file.text();
        const json = JSON.parse(text);
        if (Array.isArray(json)) {
          const parsed = json.map((item, idx) => parseRepairItem(item, idx));
          setPreviewLogs(parsed);
        } else {
          setErrorMessage('รูปแบบไฟล์ JSON ต้องเป็น Array ของรายการเบรกดาวน์');
        }
        setIsLoading(false);
        return;
      }

      // Handle Excel / CSV via XLSX
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: 'array' });
      const sheetName = wb.SheetNames[0];
      if (!sheetName) {
        setErrorMessage('ไม่พบแผ่นงาน (Sheet) ในไฟล์ Excel');
        setIsLoading(false);
        return;
      }

      const ws = wb.Sheets[sheetName];
      const rawRows: any[] = XLSX.utils.sheet_to_json(ws, { defval: '' });

      // Filter out empty rows or rows with #N/A
      const validRows = rawRows.filter(r => {
        const id = String(r['ID.Number'] || r['ID Number'] || r['รหัสเครื่องจักร'] || r['machineId'] || '').trim();
        const name = String(r['เครื่องจักร'] || r['machineName'] || '').trim();
        if (!id && !name) return false;
        if (id.includes('#N/A') || name.includes('#N/A')) return false;
        return true;
      });

      if (validRows.length === 0) {
        setErrorMessage('ไฟล์ไม่มีข้อมูลรายการเบรกดาวน์ที่ถูกต้อง');
        setIsLoading(false);
        return;
      }

      const parsedLogs: RepairLog[] = validRows.map((row, idx) => parseRepairItem(row, idx));
      setPreviewLogs(parsedLogs);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(`เกิดข้อผิดพลาดในการอ่านไฟล์: ${err.message || 'โปรดตรวจสอบความถูกต้องของไฟล์'}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper to parse a single record into RepairLog
  const parseRepairItem = (row: any, idx: number): RepairLog => {
    // 1. Machine ID finding
    const rawMachine = String(
      row['ID.Number'] || row['ID. Number'] || row['ID Number'] || row['รหัสเครื่องจักร'] || 
      row['machineId'] || row['MachineId'] || row['Machine ID'] || row['Asset Code'] || 
      row['รหัสเครื่อง'] || ''
    ).trim();

    let matchedMachineId = rawMachine;
    if (!matchedMachineId) {
      const rawName = String(row['เครื่องจักร'] || row['ชื่อเครื่องจักร'] || row['machineName'] || '').trim().toLowerCase();
      const matchedByName = machines.find(m => 
        m.name.toLowerCase().includes(rawName) || rawName.includes(m.name.toLowerCase())
      );
      matchedMachineId = matchedByName ? matchedByName.id : (machines[idx % machines.length]?.id || 'RH1501F');
    }

    // 2. Dates and times
    const rawStartDate = row['วัน เวลา ที่ได้รับแจ้ง'] || row['วันที่เสีย'] || row['วันที่'] || row['Date'] || row['breakdownTime'];
    const { dateStr, isoDateTime: timeStart } = parseDateTimeWithBuddhistEra(rawStartDate);

    const rawEndDate = row['วัน เวลา แก้ไขเสร็จ'] || row['เวลาซ่อมเสร็จ'] || row['repairDoneTime'];
    const { isoDateTime: timeEnd } = parseDateTimeWithBuddhistEra(rawEndDate);

    // 3. Duration
    const dur = parseDurationMinutes(row);

    // 4. Symptoms, Parts, Phenomenon
    const sym = String(
      row['อาการ'] || row['อาการเสีย / ปัญหาที่พบ'] || row['symptoms'] || 
      row['อาการเสีย'] || row['รายละเอียด'] || 'เครื่องจักรขัดข้องหยุดการทำงาน'
    ).trim();

    const part = String(row['ชิ้นส่วน'] || row['partName'] || row['part'] || '').trim();
    const phenomenon = String(row['ปรากฏการณ์/ กระบวนการขัดข้อง'] || row['ปรากฏการณ์'] || row['กระบวนการขัดข้อง'] || '').trim();

    // 5. Cause & Why-Why
    const cause = String(row['สาเหตุ'] || row['rootCause'] || row['cause'] || '').trim();
    const why1 = String(row['การวิเคราะห์ Why 1'] || row['why1'] || cause || phenomenon || sym).trim();
    const why2 = String(row['การวิเคราะห์ Why 2'] || row['why2'] || phenomenon || part ? `${part} ชำรุดขัดข้อง` : '').trim();
    const why3 = String(row['การวิเคราะห์ Why 3'] || row['why3'] || row['ปัจจัยการเกิด BD'] ? `ปัจจัย: ${row['ปัจจัยการเกิด BD']}` : '').trim();
    const why4 = String(row['การวิเคราะห์ Why 4'] || row['why4'] || '').trim();
    const why5 = String(row['การวิเคราะห์ Why 5'] || row['why5'] || '').trim();

    // 6. Action
    const correctiveAction = String(
      row['มาตรการแก้ไข/ ป้องกัน'] || row['มาตรการแก้ไข'] || row['มาตรการแก้ไขและป้องกัน'] || 
      row['correctiveAction'] || row['การแก้ไข'] || 'ทำการตรวจเช็คและปรับตั้งการทำงานของเครื่องจักร'
    ).trim();

    // 7. Technicians
    const primaryTech = String(
      row['ผู้ทำการแก้ไข'] || row['ช่างผู้ปฏิบัติการ'] || row['technician'] || 
      row['ช่างซ่อม'] || technicians[idx % technicians.length] || 'ช่างเซฟ'
    ).trim();

    // 8. Stoppage Type
    const stoppageType = parseStoppageType(row, dur);

    return {
      id: `bd-imp-${Date.now().toString(36)}-${idx + 1}`,
      type: 'Repair',
      technician: primaryTech,
      technicians: [primaryTech],
      date: dateStr,
      machineId: matchedMachineId,
      breakdownTime: timeStart,
      repairDoneTime: timeEnd,
      symptoms: part ? `${sym} (${part})` : sym,
      why1,
      why2,
      why3,
      why4,
      why5,
      correctiveAction,
      duration: dur,
      status: 'ปิดงาน',
      stoppageType,
      hasPartsReplaced: Boolean(part && part !== '-'),
      usedParts: part ? [
        { partId: `part-imp-${idx + 1}`, partName: part, quantity: 1, pricePerUnit: 0, totalCost: 0 }
      ] : [],
      otherCost: 0
    };
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleConfirmImport = () => {
    if (previewLogs.length === 0) return;
    onImportSuccess(previewLogs, importMode);
    onClose();
  };

  // Stats calculation
  const totalDowntimeMinutes = previewLogs.reduce((sum, r) => sum + (r.duration || 0), 0);
  const totalDowntimeHours = (totalDowntimeMinutes / 60).toFixed(1);
  const uniqueMachines = new Set(previewLogs.map(r => r.machineId));
  const breakdownCount = previewLogs.filter(r => r.stoppageType === 'BREAKDOWN').length;
  const minorCount = previewLogs.filter(r => r.stoppageType === 'MINOR_STOPPAGE').length;
  const rankACount = previewLogs.filter(r => {
    const m = getMachineInfo(r.machineId);
    return m?.ranking === 'A';
  }).length;

  // Filtered Preview Logs
  const filteredLogs = previewLogs.filter(log => {
    if (filterStoppage !== 'ALL' && log.stoppageType !== filterStoppage) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchMach = log.machineId.toLowerCase().includes(q);
      const matchSym = log.symptoms.toLowerCase().includes(q);
      const matchCause = (log.why1 || '').toLowerCase().includes(q);
      return matchMach || matchSym || matchCause;
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-150">
      <div 
        id="breakdown-import-modal-root" 
        className="bg-slate-900 border border-slate-750 rounded-2xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl text-slate-100"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-orange-950/40 border-b border-slate-750 p-5 shrink-0 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/15 border border-orange-500/30 flex items-center justify-center text-orange-400 shrink-0">
              <UploadCloud size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  ระบบนำเข้าเบรกดาวน์เครื่องจักรจาก Excel (32 รายการ)
                </h3>
                <span className="bg-orange-500/15 border border-orange-500/30 text-orange-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  F-Breakdown Form
                </span>
              </div>
              <p className="text-slate-400 text-xs mt-0.5">
                รองรับไฟล์ Excel (.xlsx, .xls, .csv) ตามแบบฟอร์มบันทึกเบรกดาวน์ 32 รายการของโรงงาน
              </p>
            </div>
          </div>
          
          <button 
            type="button" 
            onClick={onClose}
            className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-750 p-2 rounded-xl transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Top Quick Actions Bar */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Quick 1: Load 32 Plant Breakdowns Preset */}
            <div className="bg-slate-850 border border-orange-500/30 rounded-xl p-4 flex flex-col justify-between space-y-3 hover:border-orange-500/60 transition shadow-sm">
              <div>
                <div className="flex items-center gap-2 text-orange-400 font-bold mb-1">
                  <Database size={16} />
                  <span>ข้อมูลเบรกดาวน์ 32 รายการจากเอกสาร</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  นำเข้าชุดข้อมูลเบรกดาวน์และเคสขัดข้อง 32 รายการจริงจากตารางเอกสารโรงงานทันที
                </p>
              </div>
              <button
                type="button"
                id="btn-load-preset-breakdowns"
                onClick={handleLoadPresetBreakdowns}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold py-2.5 px-3 rounded-lg transition shadow-md cursor-pointer active:scale-95"
              >
                <Sparkles size={14} />
                โหลดชุดข้อมูล 32 รายการจริง
              </button>
            </div>

            {/* Quick 2: Download Template */}
            <div className="bg-slate-850 border border-slate-750/80 rounded-xl p-4 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center gap-2 text-cyan-400 font-bold mb-1">
                  <Download size={16} />
                  <span>ดาวน์โหลดเทมเพลต 32 รายการ</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  ดาวน์โหลดไฟล์ Excel พร้อมหัวคอลัมน์มาตรฐานครบ 24 คอลัมน์และข้อมูลตัวอย่าง
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  id="btn-download-breakdown-template-xlsx"
                  onClick={() => handleDownloadTemplate('xlsx')}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 hover:text-white font-semibold py-2 px-2 rounded-lg transition cursor-pointer"
                >
                  <FileSpreadsheet size={13} className="text-emerald-400" />
                  Excel (.xlsx)
                </button>
                <button
                  type="button"
                  id="btn-download-breakdown-template-csv"
                  onClick={() => handleDownloadTemplate('csv')}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 hover:text-white font-semibold py-2 px-2 rounded-lg transition cursor-pointer"
                >
                  <FileText size={13} className="text-blue-400" />
                  CSV (.csv)
                </button>
              </div>
            </div>

            {/* Quick 3: Import Mode Selector */}
            <div className="bg-slate-850 border border-slate-750/80 rounded-xl p-4 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center gap-2 text-emerald-400 font-bold mb-1">
                  <RefreshCw size={16} />
                  <span>โหมดการนำเข้าประวัติ</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  เลือกว่าต้องการเขียนทับประวัติเดิมทั้งหมด หรือเพิ่มต่อท้ายประวัติเดิม
                </p>
              </div>
              <div className="flex bg-slate-900 border border-slate-750 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setImportMode('replace')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    importMode === 'replace'
                      ? 'bg-rose-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  เขียนทับทั้งหมด
                </button>
                <button
                  type="button"
                  onClick={() => setImportMode('append')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    importMode === 'append'
                      ? 'bg-cyan-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  เพิ่มต่อท้าย
                </button>
              </div>
            </div>
          </div>

          {/* Drag & Drop Area */}
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center transition-all ${
              isDragging
                ? 'border-orange-500 bg-orange-500/10 scale-[1.01]'
                : 'border-slate-750 hover:border-slate-600 bg-slate-900/50'
            }`}
          >
            <input
              type="file"
              id="file-breakdown-upload"
              accept=".xlsx,.xls,.csv,.json"
              onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])}
              className="hidden"
            />
            <label htmlFor="file-breakdown-upload" className="cursor-pointer block space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-orange-500/15 border border-orange-500/30 flex items-center justify-center text-orange-400 group-hover:scale-110 transition">
                <FileSpreadsheet size={28} />
              </div>
              <div>
                <p className="font-bold text-sm text-slate-200">
                  {fileName ? (
                    <span className="text-orange-400">📄 {fileName}</span>
                  ) : (
                    <>ลากไฟล์ Excel / CSV มาวางที่นี่ หรือ <span className="text-orange-400 underline underline-offset-4">คลิกเพื่อเลือกไฟล์</span></>
                  )}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  รองรับคอลัมน์: ID.Number, เครื่องจักร, วัน เวลา ที่ได้รับแจ้ง, อาการ, ชิ้นส่วน, เวลาแก้ไขจริง, เวลารวม, BD PF Non, สาเหตุ, มาตรการแก้ไข
                </p>
              </div>
            </label>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="bg-rose-950/40 border border-rose-500/40 text-rose-300 p-3.5 rounded-xl flex items-center gap-2.5">
              <AlertTriangle size={18} className="shrink-0 text-rose-400" />
              <span className="text-xs">{errorMessage}</span>
            </div>
          )}

          {/* Loading Indicator */}
          {isLoading && (
            <div className="text-center py-6 space-y-2">
              <div className="w-7 h-7 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-slate-400 text-xs">กำลังประมวลผลไฟล์และวิเคราะห์คอลัมน์...</p>
            </div>
          )}

          {/* Preview Section */}
          {previewLogs.length > 0 && (
            <div className="space-y-3">
              {/* Stats Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-850 border border-slate-750 p-4 rounded-xl">
                <div className="flex items-center gap-2">
                  <span className="text-base">📊</span>
                  <span className="font-bold text-white text-sm">
                    รายการเบรกดาวน์พร้อมนำเข้า ({previewLogs.length} รายการ)
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <span className="bg-rose-500/10 border border-rose-500/20 text-rose-300 px-2.5 py-1 rounded-lg text-xs font-semibold">
                    🚨 Breakdown: {breakdownCount} งาน
                  </span>
                  <span className="bg-amber-500/10 border border-amber-500/20 text-amber-300 px-2.5 py-1 rounded-lg text-xs font-semibold">
                    ⚠️ ขัดข้อง: {minorCount} งาน
                  </span>
                  <span className="bg-orange-500/10 border border-orange-500/20 text-orange-400 px-2.5 py-1 rounded-lg text-xs font-semibold">
                    ⏱️ เวลารวม: {totalDowntimeMinutes.toLocaleString()} นาที ({totalDowntimeHours} ชม.)
                  </span>
                  <span className="bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 px-2.5 py-1 rounded-lg text-xs font-semibold">
                    🏭 เครื่องจักร: {uniqueMachines.size} เครื่อง (Rank A: {rankACount})
                  </span>
                </div>
              </div>

              {/* Filter and Search in preview */}
              <div className="flex flex-col sm:flex-row gap-2 justify-between items-center">
                <div className="relative w-full sm:w-72">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="ค้นหารหัสเครื่อง, อาการ, สาเหตุ..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div className="flex items-center gap-1.5 self-end sm:self-auto">
                  <button
                    type="button"
                    onClick={() => setFilterStoppage('ALL')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                      filterStoppage === 'ALL'
                        ? 'bg-slate-700 text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    ทั้งหมด ({previewLogs.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterStoppage('BREAKDOWN')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                      filterStoppage === 'BREAKDOWN'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Breakdown ({breakdownCount})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterStoppage('MINOR_STOPPAGE')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                      filterStoppage === 'MINOR_STOPPAGE'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    ขัดข้อง ({minorCount})
                  </button>
                </div>
              </div>

              {/* Table */}
              <div className="border border-slate-750 rounded-xl overflow-hidden bg-slate-950/40">
                <div className="max-h-72 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="sticky top-0 bg-slate-900 border-b border-slate-750 text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
                      <tr>
                        <th className="py-2.5 px-3">ลำดับ</th>
                        <th className="py-2.5 px-3">วันที่ / เวลา</th>
                        <th className="py-2.5 px-3">รหัสเครื่องจักร</th>
                        <th className="py-2.5 px-3">อาการเสีย / ปรากฏการณ์</th>
                        <th className="py-2.5 px-3">สาเหตุ</th>
                        <th className="py-2.5 px-3">มาตรการแก้ไข</th>
                        <th className="py-2.5 px-3">เวลารวม</th>
                        <th className="py-2.5 px-3 text-center">ประเภท</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {filteredLogs.map((log, idx) => {
                        const mach = getMachineInfo(log.machineId);
                        const isBD = log.stoppageType === 'BREAKDOWN';
                        return (
                          <tr key={log.id || idx} className="hover:bg-slate-800/40 transition">
                            <td className="py-2.5 px-3 text-slate-400 font-mono">{idx + 1}</td>
                            <td className="py-2.5 px-3 font-mono text-slate-300 whitespace-nowrap">
                              {log.date} {log.breakdownTime.includes('T') ? log.breakdownTime.split('T')[1] : ''}
                            </td>
                            <td className="py-2.5 px-3 whitespace-nowrap">
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono font-bold text-orange-400">{log.machineId}</span>
                                {mach?.ranking && (
                                  <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                                    mach.ranking === 'A' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                                    mach.ranking === 'B' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                                    'bg-slate-700 text-slate-300'
                                  }`}>
                                    {mach.ranking}
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-slate-400 block truncate max-w-[130px]">
                                {mach?.name || 'เครื่องจักรโรงงาน'}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 max-w-[200px]">
                              <span className="truncate block font-medium text-slate-200" title={log.symptoms}>
                                {log.symptoms}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 max-w-[180px] text-slate-400">
                              <span className="truncate block" title={log.why1 || '-'}>
                                {log.why1 || '-'}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 max-w-[180px] text-slate-400">
                              <span className="truncate block" title={log.correctiveAction || '-'}>
                                {log.correctiveAction || '-'}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-mono font-bold text-slate-300 whitespace-nowrap">
                              {log.duration} นาที
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                                isBD
                                  ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                                  : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              }`}>
                                {isBD ? 'Breakdown' : 'ขัดข้อง'}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-950 border-t border-slate-750 p-4 shrink-0 flex flex-wrap gap-3 justify-between items-center">
          <div className="text-xs text-slate-400">
            {importMode === 'replace' ? (
              <span className="text-amber-400 flex items-center gap-1.5 font-medium">
                ⚠️ โหมด: เขียนทับข้อมูลทั้งหมด (ประวัติงานซ่อมเดิมจะถูกรีเซ็ตแทนที่ด้วยชุด 32 รายการนี้)
              </span>
            ) : (
              <span className="text-cyan-400 flex items-center gap-1.5 font-medium">
                ℹ️ โหมด: เพิ่มต่อท้าย (คงประวัติงานซ่อมเดิมไว้ และเพิ่มข้อมูลชุดนี้เข้าไป)
              </span>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 font-semibold text-xs transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="button"
              id="btn-confirm-breakdown-import"
              onClick={handleConfirmImport}
              disabled={previewLogs.length === 0}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs transition shadow-lg ${
                previewLogs.length > 0
                  ? 'bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 hover:from-orange-400 hover:via-amber-400 hover:to-yellow-400 text-slate-950 cursor-pointer shadow-orange-600/20 active:scale-95'
                  : 'bg-slate-800 text-slate-500 border border-slate-750 cursor-not-allowed'
              }`}
            >
              <CheckCircle size={16} />
              ยืนยันนำเข้าข้อมูล ({previewLogs.length} รายการ)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
