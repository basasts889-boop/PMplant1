import React, { useState, useMemo } from 'react';
import { Trash2, AlertTriangle, X, Search, ShieldAlert, CheckSquare, Layers, Clock, CalendarDays, FileText } from 'lucide-react';
import { PMPlan, Machine } from '../../types';

interface BulkDeletePMPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (deleteLinkedSchedules: boolean) => void;
  selectedPlans: PMPlan[];
  machines: Machine[];
  affectedSchedulesCount: number;
}

export const BulkDeletePMPlanModal: React.FC<BulkDeletePMPlanModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  selectedPlans,
  machines,
  affectedSchedulesCount,
}) => {
  const [deleteLinkedSchedules, setDeleteLinkedSchedules] = useState<boolean>(true);
  const [searchPreview, setSearchPreview] = useState<string>('');
  const [confirmText, setConfirmText] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Machine lookup map
  const machineMap = useMemo(() => {
    const map = new Map<string, Machine>();
    machines.forEach(m => map.set(m.id, m));
    return map;
  }, [machines]);

  // Distinct machines affected
  const distinctMachineIds = useMemo(() => {
    return Array.from(new Set(selectedPlans.map(p => p.machineId)));
  }, [selectedPlans]);

  // Total steps & TTM
  const totalSteps = useMemo(() => {
    return selectedPlans.reduce((sum, p) => sum + (p.steps?.length || 0), 0);
  }, [selectedPlans]);

  const totalTtmMinutes = useMemo(() => {
    return selectedPlans.reduce((sum, p) => sum + (p.ttm || 0), 0);
  }, [selectedPlans]);

  // Filter preview list
  const filteredPreview = useMemo(() => {
    if (!searchPreview.trim()) return selectedPlans;
    const q = searchPreview.toLowerCase();
    return selectedPlans.filter(p => {
      const mach = machineMap.get(p.machineId);
      return p.title.toLowerCase().includes(q) ||
             p.machineId.toLowerCase().includes(q) ||
             (mach && mach.name.toLowerCase().includes(q)) ||
             p.frequency.toLowerCase().includes(q);
    });
  }, [selectedPlans, searchPreview, machineMap]);

  if (!isOpen) return null;

  const requiresTypingConfirm = selectedPlans.length >= 10;
  const isConfirmDisabled = requiresTypingConfirm && confirmText.trim().toUpperCase() !== 'DELETE';

  const handleExecute = () => {
    setIsSubmitting(true);
    try {
      onConfirm(deleteLinkedSchedules);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="bg-slate-900 border border-rose-500/30 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-6">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-rose-950 via-rose-900 to-slate-900 border-b border-rose-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white flex items-center gap-2">
                <span>ยืนยันการลบแผนงาน PM แบบเลือกทั้งหมด</span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-rose-500 text-white">
                  {selectedPlans.length} งาน
                </span>
              </h3>
              <p className="text-xs text-rose-200/80">
                ลบหัวข้องานและขั้นตอนการตรวจเช็ค PM ออกจากระบบบำรุงรักษา
              </p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-4 text-xs">
          {/* Danger Warning Alert */}
          <div className="flex items-start gap-3 p-4 bg-rose-950/30 border border-rose-500/30 rounded-xl text-rose-200">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="font-bold text-sm text-rose-300">
                คำเตือน: การลบนี้จะลบแผนงาน PM ที่เลือกทั้งหมดถาวร
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                ระบบจะลบหัวข้องาน PM เกณฑ์มาตรฐานการตรวจสอบ และขั้นตอนทั้งหมดของงานที่เลือกออกจากฐานข้อมูล 
                หากเคยมีตารางงานที่ยังค้างดำเนินการอยู่ คุณสามารถเลือกให้ระบบล้างตารางที่เชื่อมโยงออกได้ด้านล่าง
              </p>
            </div>
          </div>

          {/* Impact Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center">
              <div className="text-[11px] text-slate-400">งาน PM ที่เลือก</div>
              <div className="text-lg font-bold font-mono text-rose-400 mt-0.5">
                {selectedPlans.length}
              </div>
              <div className="text-[10px] text-slate-500">แผนงาน</div>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center">
              <div className="text-[11px] text-slate-400">เครื่องจักรที่เกี่ยวข้อง</div>
              <div className="text-lg font-bold font-mono text-cyan-400 mt-0.5">
                {distinctMachineIds.length}
              </div>
              <div className="text-[10px] text-slate-500">เครื่อง</div>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center">
              <div className="text-[11px] text-slate-400">ขั้นตอนการเช็ค</div>
              <div className="text-lg font-bold font-mono text-amber-400 mt-0.5">
                {totalSteps}
              </div>
              <div className="text-[10px] text-slate-500">ขั้นตอนย่อย</div>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center">
              <div className="text-[11px] text-slate-400">งานในตารางค้าง</div>
              <div className="text-lg font-bold font-mono text-indigo-400 mt-0.5">
                {affectedSchedulesCount}
              </div>
              <div className="text-[10px] text-slate-500">สเก็ตดูลค้าง</div>
            </div>
          </div>

          {/* Cascade Option: Delete linked pending schedules */}
          {affectedSchedulesCount > 0 && (
            <label className="flex items-start gap-3 p-3.5 bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-xl cursor-pointer transition select-none">
              <input
                type="checkbox"
                checked={deleteLinkedSchedules}
                onChange={(e) => setDeleteLinkedSchedules(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded border-slate-700 text-rose-600 focus:ring-rose-500 focus:ring-offset-slate-900 accent-rose-600"
              />
              <div className="space-y-0.5 text-xs">
                <span className="font-bold text-slate-200 block">
                  ลบงานในตารางซ่อมบำรุง (Schedule) ที่ยังไม่เสร็จสิ้นที่เชื่อมโยงด้วย ({affectedSchedulesCount} งาน)
                </span>
                <span className="text-slate-400 text-[11px] block">
                  หากติ๊กเลือก ระบบจะล้างงาน PM ในปฏิทินที่ยังไม่ได้ทำ (งานที่เสร็จสิ้นแล้วจะยังคงถูกเก็บไว้เป็นประวัติ)
                </span>
              </div>
            </label>
          )}

          {/* Preview List with Search */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300">
                รายการแผนงาน PM ที่จะถูกลบ ({filteredPreview.length}/{selectedPlans.length})
              </span>
              {selectedPlans.length > 5 && (
                <div className="relative w-48">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={searchPreview}
                    onChange={(e) => setSearchPreview(e.target.value)}
                    placeholder="ค้นหาแผน/เครื่อง..."
                    className="w-full pl-8 pr-2 py-1 bg-slate-950 border border-slate-800 rounded-lg text-[11px] text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
              )}
            </div>

            <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 border border-slate-800 rounded-xl p-2 bg-slate-950/50">
              {filteredPreview.length === 0 ? (
                <div className="text-center py-4 text-slate-500 text-xs">
                  ไม่พบรายการที่ตรงกับการค้นหา
                </div>
              ) : (
                filteredPreview.map((plan) => {
                  const mach = machineMap.get(plan.machineId);
                  return (
                    <div 
                      key={plan.id}
                      className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="font-mono font-bold text-cyan-400 bg-cyan-950/40 px-1.5 py-0.5 rounded border border-cyan-800/40 text-[10px] shrink-0">
                          {plan.machineId}
                        </span>
                        <div className="min-w-0">
                          <span className="font-semibold text-slate-200 block truncate text-xs">
                            {plan.title}
                          </span>
                          <span className="text-[10px] text-slate-400 block truncate">
                            {mach?.name || 'เครื่องจักร'} • {plan.steps?.length || 0} ขั้นตอน • {plan.ttm || 0} นาที
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 shrink-0">
                        {plan.frequency}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Safety Confirm for Large Batch (>= 10) */}
          {requiresTypingConfirm && (
            <div className="p-3.5 bg-rose-950/40 border border-rose-500/40 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-rose-300 font-bold text-xs">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span>การลบชุดใหญ่ (จำนวน {selectedPlans.length} แผนงาน)</span>
              </div>
              <p className="text-[11px] text-slate-300">
                เพื่อป้องกันความผิดพลาด กรุณาพิมพ์คำว่า <strong className="text-white font-mono bg-rose-900/60 px-1.5 py-0.5 rounded border border-rose-700">DELETE</strong> เพื่อยืนยัน
              </p>
              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="พิมพ์ DELETE ที่นี่"
                className="w-full px-3 py-1.5 bg-slate-950 border border-rose-500/50 rounded-lg text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/30"
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="text-[11px] text-slate-400">
            เลือกอยู่ <strong className="text-white font-mono">{selectedPlans.length}</strong> แผนงาน
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs transition cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="button"
              onClick={handleExecute}
              disabled={isSubmitting || isConfirmDisabled}
              className={`px-4 py-2 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-lg transition cursor-pointer ${
                isConfirmDisabled
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white shadow-rose-950/60'
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span>
                {isSubmitting ? 'กำลังดำเนินการ...' : `ยืนยันลบ ${selectedPlans.length} แผนงาน`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
